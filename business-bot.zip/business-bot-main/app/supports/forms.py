from django import forms
from django.core.exceptions import ValidationError
from supports.models import SupportMeasure

class SupportMeasureAdminForm(forms.ModelForm):
    """
    Модель формы для создания меры поддержки из админки.
    Добавлена обработка платных мер и цены.
    """

    percent = forms.DecimalField(
        max_value=100,
        min_value=0,
        label="Минимальный уровень надежности",
        help_text="Введите минимальный уровень надежности в процентах (от 0 до 100).",
        decimal_places=2,
    )
    
    price = forms.DecimalField(
        required=False,
        label="Стоимость",
        min_value=0.01,
        max_digits=10,
        decimal_places=2,
        help_text="Обязательно для платных мер. Введите сумму в рублях.",
        widget=forms.NumberInput(attrs={'step': '0.01'})
    )

    class Meta:
        model = SupportMeasure
        fields = "__all__"
        exclude = ['min_trust']
        widgets = {
            'is_paid': forms.CheckboxInput(attrs={'class': 'checkbox'}),
        }

    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instance')
        if instance:
            initial = kwargs.get('initial', {})
            initial['percent'] = float(instance.min_trust) * 100
            initial['price'] = instance.price
            kwargs['initial'] = initial
        super().__init__(*args, **kwargs)

        # Динамически меняем обязательность поля цены
        if self.instance and self.instance.is_paid:
            self.fields['price'].required = True

    def clean(self):
        cleaned_data = super().clean()
        is_paid = cleaned_data.get('is_paid')
        price = cleaned_data.get('price')

        # Валидация для платных мер
        if is_paid and (price is None or price <= 0):
            self.add_error(
                'price', 
                "Для платных мер необходимо указать цену больше нуля"
            )
        
        # Автоматическое обнуление цены для бесплатных мер
        if not is_paid and price:
            cleaned_data['price'] = 0.00

        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        
        # Конвертация процентов
        instance.min_trust = self.cleaned_data['percent'] / 100
        
        # Обработка цены
        if not instance.is_paid:
            instance.price = 0.00
            
        if commit:
            instance.save()
        return instance