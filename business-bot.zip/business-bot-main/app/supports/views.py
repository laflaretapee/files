import os

from asgiref.sync import sync_to_async

from django.http import HttpRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt

from users.decorators import only_post
from users.models import TelegramUser

from supports.models import SupportMeasure, SupportMeasureCategory
from supports.utils import get_recommended_support_measures

from requests_.models import SupportRequest
from requests_.utils import validate_telegram_token


@csrf_exempt
@sync_to_async
@validate_telegram_token
@only_post
def take_support_view(request: HttpRequest):
    """
    Метод для создания заявки на получение меры поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    В теле запроса передаём telegram id пользователя (username: telegram_id) и id
    меры поддержки (support_id: support_id).

    Возвращает ответ в виде JSON. Под ключом "error" указывается True, если произошла ошибка,
    иначе False. Под ключом "message" указывается текст результата запроса. Данное представление
    создаёт объект заявки на получение меры поддержки (Request).
    """

    username = request.POST.get("username")
    support_id = request.POST.get("support_id")
    title = request.POST.get("title")

    if not all([username, support_id]):
        return JsonResponse(
            {
                "error": True, 
                "message": "Переданы не все данные"
            }, 
            status=400
        )

    try:
        user = TelegramUser.objects.get(username=username)
        support = SupportMeasure.objects.get(id=support_id)

        msg = f'Пользователь <a href="tg://user?id={user.username}">{user.full_name}</a> со статусом <i><b>«{user.category}»</b></i> интересуется '\
            f'<i><b>«{support.name}»</b></i> из категории <i><b>«{support.category}»</b></i>.\n\n'\
            f"☎️ Телефон: <a href='tel:{user.phone}'>+{user.phone}</a>\n"\
            f"✉️ Email: <a href='mailto:{user.email}'>{user.email}</a>."

        SupportRequest.objects.create(
            user=user,
            title=title,
            message=msg,
        )
        return JsonResponse(
            {
                "error": False,
                "message": msg,
                "status": 201,
            }
        )
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при создании заявки. " + str(e)},
            status=500,
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_support_view(request: HttpRequest):

    id_ = request.GET.get("id")
    if not id_:
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"}, status=400
        )
    
    try:
        support = SupportMeasure.objects.get(id=id_)
        image_url = None
        pseudo_url = support.image

        if pseudo_url and os.path.exists(pseudo_url.path):
            image_url = support.image.path
        return JsonResponse(
            {
                "error": False,
                "message": "Мера поддержки успешно получена",
                "data": {
                    "name": support.name,
                    "id": support.id,
                    "min_trust": support.min_trust,
                    "category": support.category.name,
                    "category_id": support.category.id,
                    "descr": support.description,
                    "price": support.price,
                    "is_paid": support.is_paid,
                    "image_url": image_url,
                },
            },
            status=200,
        )
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при получении меры. " + str(e)},
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_support_by_category_view(request):
    """
    Возвращает все меры поддержки по заданной категории.
    """
    category_id = request.GET.get("id")
    if not category_id:
        return JsonResponse({"error": True, "message": "Не указан идентификатор категории"}, status=400)
    try:
        category = SupportMeasureCategory.objects.get(id=category_id)
        measures = SupportMeasure.objects.filter(category=category_id)
        data = [{
            "measure_id": measure.id,
            "measure_name": measure.name,
            "measure_descr": measure.description,
            "min_trust": measure.min_trust
        } for measure in measures]
        
        return JsonResponse({
            "error": False,
            "message": "Меры поддержки успешно получены",
            "category_name": category.name,
            "category_description": category.description,
            "data": data
        }, status=200)
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при получении мер по категории. " + str(e)},
        )


def get_nested_categories(parent=None):
    """
    Рекурсивная функция для получения всех категорий с вложенными подкатегориями
    и мерами поддержки.
    """
    try:
        categories = SupportMeasureCategory.objects.filter(parent=parent).exclude(name="Без категории")
        result = []
        
        for category in categories:
            try:
                # Получаем меры поддержки для текущей категории
                measures = SupportMeasure.objects.filter(category=category)
                measures_data = [{
                    "measure_id": measure.id,
                    "measure_name": measure.name,
                    "measure_descr": measure.description,
                    "min_trust": measure.min_trust,
                    "is_paid": measure.is_paid,
                    "price": measure.price
                } for measure in measures]
                
                # Собираем данные о категории
                category_data = {
                    "category_name": category.name,
                    "category_id": category.id,
                    "category_descr": category.description,
                    "parent_id": category.parent.id if category.parent else None,
                    "children": get_nested_categories(parent=category),
                    "measures": measures_data
                }
                result.append(category_data)
            except Exception as e:
                print(f"Error processing category {category.id}: {str(e)}")
                continue
                
        return result
    except Exception as e:
        print(f"Error in get_nested_categories: {str(e)}")
        return []


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_categories_view(request):
    """
    Возвращает все категории в виде вложенного словаря вместе с мерами поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    Опционально можно передать category_id для получения конкретной категории.
    """
    category_id = request.GET.get("category_id")
    
    try:
        if category_id:
            # Если указан ID категории, получаем только эту категорию и её содержимое
            category = SupportMeasureCategory.objects.get(id=category_id)
            
            # Получаем меры поддержки для текущей категории
            measures = SupportMeasure.objects.filter(category=category)
            measures_data = [{
                "measure_id": measure.id,
                "measure_name": measure.name,
                "measure_descr": measure.description,
                "min_trust": measure.min_trust,
                "is_paid": measure.is_paid,
                "price": measure.price
            } for measure in measures]
            
            # Получаем подкатегории
            subcategories = get_nested_categories(parent=category)
            
            data = {
                "category_name": category.name,
                "category_id": category.id,
                "category_descr": category.description,
                "parent_id": category.parent.id if category.parent else None,
                "children": subcategories,
                "measures": measures_data
            }
        else:
            # Если ID не указан, получаем корневые категории
            data = get_nested_categories()
        
        return JsonResponse({
            "error": False,
            "message": "Категории успешно получены",
            "data": data
        }, status=200)
        
    except SupportMeasureCategory.DoesNotExist:
        return JsonResponse({
            "error": True,
            "message": "Категория не найдена"
        }, status=404)
    except Exception as e:
        return JsonResponse({
            "error": True,
            "message": f"Ошибка при получении категорий: {str(e)}"
        }, status=500)


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_category_view(request: HttpRequest):
    """
    Метод для получения конкретной категории мер поддержки вместе с подкатегориями и мерами.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    """
    id_ = request.GET.get("id")
    if not id_:
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"}, 
            status=400
        )

    try:
        category = SupportMeasureCategory.objects.get(id=id_)
        
        # Получаем меры поддержки для текущей категории
        measures = SupportMeasure.objects.filter(category=category)
        measures_data = [{
            "measure_id": measure.id,
            "measure_name": measure.name,
            "measure_descr": measure.description,
            "min_trust": measure.min_trust,
            "is_paid": measure.is_paid,
            "price": measure.price
        } for measure in measures]
        
        return JsonResponse({
            "error": False,
            "message": "Категория успешно получена",
            "data": {
                "category_name": category.name,
                "category_id": category.id,
                "category_descr": category.description,
                "parent_id": category.parent.id if category.parent else None,
                "children": get_nested_categories(parent=category),
                "measures": measures_data
            },
        }, status=200)
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при получении категории. " + str(e)},
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_supports_list_view(request: HttpRequest):
    """
    Метод для получения списка доступных мер поддержки с указанием процента доступности.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN). В теле запроса передаём
    telegram id пользователя (username: telegram_id).

    Возвращает ответ в виде JSON. Под ключом "error" указывается True, если произошла ошибка,
    иначе False. Под ключом "message" указывается текст результата запроса. Под ключом "objects"
    содержатся объекты вида {"support_name": str, "support_id": int, "availability": 87.56}.
    """

    username = request.POST.get("username")
    if not username:
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"}, status=400
        )

    try:
        user = TelegramUser.objects.get(username=username)
        recommended_measures = get_recommended_support_measures(user)
        data = {
            "error": False,
            "message": "Список всех доступных мер успешно получен",
            "objects": recommended_measures,
        }

        return JsonResponse(data, status=200)
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при получении мер поддержки. " + str(e)},
            status=500,
        )
