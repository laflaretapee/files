from django.contrib import admin
from django.utils.html import format_html
from supports.models import SupportMeasure, SupportMeasureCategory
from supports.forms import SupportMeasureAdminForm

@admin.register(SupportMeasure)
class SupportMeasureAdmin(admin.ModelAdmin):
    list_display = [
        "image_edited",
        "name",
        "category",
        "price_display",
        "min_trust_percent",
        "is_paid",
        "short_description",
    ]
    list_filter = [
        "category", 
        "is_paid"
    ]
    search_fields = ("name", "description")
    form = SupportMeasureAdminForm
    list_editable = ("is_paid",)

    fieldsets = (
        (
            "Основные данные",
            {
                "fields": (
                    "image",
                    "name",
                    "description",
                ),
            },
        ),
        (
            "Настройки",
            {
                "fields": (
                    "category",
                    "percent",
                    "is_paid",
                    "price",
                ),
            },
        ),
    )

    def short_description(self, obj):
        return self._truncate_text(obj.description)
    short_description.short_description = "Описание"

    def min_trust_percent(self, obj):
        return f"{float(obj.min_trust):.2%}"
    min_trust_percent.short_description = "Уровень надежности"

    def price_display(self, obj):
        if obj.is_paid:
            return f"{obj.price}₽"
        return "Бесплатно"
    price_display.short_description = "Стоимость"
    price_display.admin_order_field = 'price'

    def image_edited(self, obj):
        if not obj.image:
            return "отсутствует"
        return format_html(f'<img src="{obj.image.url}" width="144" height="96" style="overflow: hidden;object-fit: cover;"/>')
    image_edited.short_description = "Изображение"

    def _truncate_text(self, text, length=50):
        if len(text) > length:
            return f"{text[:length]}..."
        return text

    def get_readonly_fields(self, request, obj=None):
        if obj and not obj.is_paid:
            return ('price',)
        return super().get_readonly_fields(request, obj)

@admin.register(SupportMeasureCategory)
class SupportMeasureCategoryAdmin(admin.ModelAdmin):
    list_display = [
        "name",
        "parent",
        "description",
    ]
    search_fields = ("name", "description")

    def description(self, obj):
        return self._truncate_text(obj.description)
    description.short_description = "Описание"

    def _truncate_text(self, text, length=50):
        if len(text) > length:
            return f"{text[:length]}..."
        return text