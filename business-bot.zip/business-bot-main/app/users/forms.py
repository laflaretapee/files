# forms.py
from django import forms
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from users.models import TelegramUser

class TelegramUserAdminForm(forms.ModelForm):
    password = ReadOnlyPasswordHashField(label="Текущий пароль", required=False, 
                                        help_text="Хеш существующего пароля. Не редактируется напрямую.")
    new_password = forms.CharField(label="Новый пароль", required=False, widget=forms.PasswordInput,
                                  help_text="Введите новый пароль (обязательно для персонала и администраторов)")

    class Meta:
        model = TelegramUser
        fields = "__all__"
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Если это уже персонал или суперпользователь, поле нового пароля не обязательно
        if self.instance.pk and (self.instance.is_staff or self.instance.is_superuser) and self.instance.has_usable_password():
            self.fields['new_password'].help_text = "Оставьте пустым, если не хотите менять пароль"
        
    def clean(self):
        cleaned_data = super().clean()
        is_staff = cleaned_data.get("is_staff", False)
        is_superuser = cleaned_data.get("is_superuser", False)
        new_password = cleaned_data.get("new_password", "")

        # Получаем оригинальные значения, если это существующий пользователь
        if self.instance.pk:
            original_is_staff = self.instance.is_staff
            original_is_superuser = self.instance.is_superuser
            
            # Проверяем становится ли пользователь персоналом или суперпользователем
            becoming_staff_or_superuser = (not original_is_staff and is_staff) or (not original_is_superuser and is_superuser)
            
            # Требуем пароль только если пользователь становится персоналом или администратором
            if becoming_staff_or_superuser and not self.instance.has_usable_password() and not new_password:
                raise forms.ValidationError("❌ Необходимо установить пароль для назначения пользователя персоналом или администратором.")
        elif is_staff or is_superuser:  # Новый пользователь с высокими правами
            if not new_password:
                raise forms.ValidationError("❌ Необходимо установить пароль для нового пользователя с правами персонала или администратора.")

        return cleaned_data
    
    def save(self, commit=True):
        user = super().save(commit=False)
        new_password = self.cleaned_data.get("new_password", "")
        
        if new_password:
            user.set_password(new_password)
            # Сохраняем пароль во временном атрибуте для отправки уведомления
            user._raw_password = new_password
        
        if commit:
            user.save()
        return user