from django.urls import path

from . import views


app_name= "users"

urlpatterns = [
    path("create/", views.create_user_view, name="create"),
    path("profile/", views.profile_user_view, name="profile"),
    path("verify/<uidb64>/<token>/", views.verify_email_view, name="verify"),
]