import os
import asyncio

from functools import wraps

from django.http import JsonResponse
from django.contrib import messages

from users.utils import AsyncHttpRequestor


def validate_telegram_token(func):

    """
    Декоратор для проверки токена Telegram
    """
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        token = request.headers.get("token")
        if not token or token != os.getenv("TELEGRAM_TOKEN"):
            return JsonResponse({"error": True, "message": "Отсутствует токен для запроса"})
        return func(request, *args, **kwargs)
    return wrapper


def async_validate_telegram_token(func):
    """
    Декоратор для проверки токена Telegram
    """
    @wraps(func)
    async def wrapper(request, *args, **kwargs):
        token = request.headers.get("token")
        if not token or token != os.getenv("TELEGRAM_TOKEN"):
            return JsonResponse({"error": True, "message": "Отсутствует токен для запроса"})
        return await func(request, *args, **kwargs)
    return wrapper


async def send_telegram_message(users, message, title=None, request=None):

    """
    Асинхронная функция для отправки сообщений в Telegram.
    Нужно передать список пользователей типа TelegramUser, сообщение и заголовок 
    этого сообщения (необязательно).
    """
    if not users:
        # messages.error(request, "Не удалось найти пользователей для отправки уведомления")
        return
    
    token = os.getenv("TELEGRAM_TOKEN")
    if not token:
        # messages.error(request, "Отсутствует токен для отправки сообщения")
        raise ValueError("Отсутствует токен для отправки сообщения")
    
    obj = AsyncHttpRequestor(f"https://api.telegram.org/")

    tasks = []
    if title:
        message = title + "\n\n"+ message
    
    for user in users:
        tgid = user.username
        if not tgid and not tgid.isdigit():
            continue
        tasks.append(obj.make("post", f"bot{token}/sendMessage", body={"chat_id": tgid, "text": message})) 

    result = await asyncio.gather(*tasks)
    count = 0

    # for res in result:
    #     if res.get("ok") or not res.get("error"):
    #         count += 1
    # messages.info(request, f"Отправлено {count} сообщений из {len(users)}")

