from django.db import models

from users.models import TelegramUser


class SupportRequest(models.Model):
    """
    Модель заявки от пользователя. Она отправляется администратору.
    Содержит заголовок и сообщение, ссылку на модель пользователя и 
    дату отправки.
    """

    user = models.ForeignKey(to=TelegramUser, verbose_name="Пользователь", on_delete=models.PROTECT)
    title = models.CharField(verbose_name="Заголовок", max_length=256)
    message = models.TextField(verbose_name="Сообщение")
    date = models.DateTimeField(verbose_name="Дата", auto_now_add=True)
    is_resolved = models.BooleanField(
        verbose_name="Решена", 
        default=False,
        help_text="Отметьте, если заявка решена"
    )

    def __str__(self):
        return f"Заявка {self.user} [{self.date.strftime('%d.%m.%Y %H:%M')}]"
    
    class Meta:
        db_table = "requests"
        verbose_name = "Заявка"
        verbose_name_plural = "Заявки"


class Notification(models.Model):
    """"
    Модель уведомления. Она отправляется пользователям в телеграм из админки.
    Содержит заголовок и сообщение, ссылку на модель пользователя и 
    дату отправки. При её создании нужно выбрать индивидуальных пользователей 
    или их группу.
    """
    
    targets = models.ManyToManyField(to=TelegramUser, verbose_name="Пользователи", blank=True)
    title = models.CharField(verbose_name="Заголовок", max_length=256)
    message = models.TextField(verbose_name="Сообщение")
    date = models.DateTimeField(verbose_name="Дата", auto_now_add=True)

    def __str__(self):
        return f"Уведомление [{self.date.strftime('%d.%m.%Y %H:%M')}]"
    
    class Meta:
        db_table = "notifications"
        verbose_name = "Новость"
        verbose_name_plural = "Новости"


class Question(models.Model):

    question = models.TextField(verbose_name="Вопрос")
    order = models.PositiveIntegerField(verbose_name="Порядок", unique=True)

    def __str__(self):
        return f"Вопрос [{self.id}]"


    class Meta:
        db_table = "questions"
        verbose_name = "Вопрос"
        verbose_name_plural = "Вопросы"

class Response(models.Model):
    support_request = models.ForeignKey(
        SupportRequest, 
        verbose_name="Заявка", 
        on_delete=models.CASCADE,
        related_name="responses"
    )
    admin = models.ForeignKey(
        TelegramUser, 
        verbose_name="Администратор", 
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    message = models.TextField(verbose_name="Ответ")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Ответ на заявку"
        verbose_name_plural = "Ответы на заявки"

    def __str__(self):
        return f"Ответ на вашу заявку"