import json
import logging
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from yookassa import Webhook, Payment

logger = logging.getLogger(__name__)

@csrf_exempt
def yookassa_webhook(request):
    event = json.loads(request.body)
    
    try:
        # Валидация подписи
        Webhook.validate(request.body, request.headers['Content-Signature'])
        
        payment = Payment.find_one(event['object']['id'])
        
        return JsonResponse({'status': 'ok'})
    
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return JsonResponse({'status': 'error'}, status=400)