import asyncio
import logging
import sys
import os

from pathlib import Path

from aiogram.types import ReplyKeyboardRemove

# Получаем путь к корневой директории проекта (где находится manage.py)
BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Добавляем путь к директории app в PYTHONPATH
sys.path.append(str(BASE_DIR / "app"))

from aiogram import Bot, types, Router, F
from aiogram.filters import CommandStart, StateFilter, CommandObject
from aiogram.fsm.context import FSMContext

from common.common import show_main_menu
from common.states import Register
from common.common import dadata
from common.filters import ChatTypeFilter

from users.utils import AsyncHttpRequestor

from keyboards.keyboards import (
    get_inn_agreement_keyboard,
    get_phone_keyboard,
    get_policy_keyboard,
)


router_register = Router()
router_register.message.filter(ChatTypeFilter(['private']))
router_register.callback_query.filter(ChatTypeFilter(['private']))

obj = AsyncHttpRequestor(os.getenv("BASE_URL"))

headers = {
    "token": os.getenv("TELEGRAM_TOKEN"),
}


@router_register.message(CommandStart(), StateFilter(None))
async def handle_message_command(message: types.Message, command: CommandObject, state: FSMContext, bot: Bot):

    username = str(message.from_user.id)
    await state.update_data(username=str(username))

    headers["username"] = username
    response_profile = await obj.make("get", "users/profile", headers=headers)

    if response_profile["error"]:
        args = command.args
        if args != os.getenv("QR_CODE_CHECK"):
            await message.answer("⚠️ Для получения доступа к боту, Вам необходимо пройти по ссылке или QR-коду!")
            return

    info = await bot.get_me()
    bot_name = info.first_name
    
    response_option = await obj.make("get", "options/get", headers=headers, params={"option": "start_text"})
    option_value = response_option["message"]

    msg = option_value.replace("{{bot}}", bot_name)

    await message.answer(msg, reply_markup=types.ReplyKeyboardRemove())
    await command_start_handler(message, state, bot, response_profile) 


async def command_start_handler(message: types.Message, state: FSMContext, bot: Bot, response = None):
    if not response["error"]:
        await message.answer("✅ Вы уже зарегистрированы!")
        await show_main_menu(message, bot)
        await state.clear()
        return
    await state.set_state(Register.policy)
    await policy_handler(message)
    

@router_register.callback_query(StateFilter(Register.policy), F.data == "policy:")
async def process_full_name(callback: types.CallbackQuery, state: FSMContext):

    response_option = await obj.make("get", "options/get", headers=headers, params={"option": "policy_url"})
    option_value = response_option["message"]

    await callback.message.edit_text(f"✅ Я ознакомлен с <a href='{option_value}'>политикой конфиденциальности!</a>", reply_keyboard_markup=ReplyKeyboardRemove())
    await callback.message.answer("👌 Хорошо, давайте познакомимся! Введите Ваше ФИО:", reply_markup=types.ReplyKeyboardRemove())
    await state.set_state(Register.full_name)


@router_register.message(StateFilter(Register.policy))
async def policy_handler(message: types.Message):

    response_option = await obj.make("get", "options/get", headers=headers, params={"option": "policy_url"})
    option_value = response_option["message"]

    await message.answer(
        f"⚠️ Перед началом регистрации, пожалуйста, ознакомьтесь с нашей <a href='{option_value}'>политикой конфиденциальности!</a>",
        reply_markup=get_policy_keyboard(),
        parse_mode="HTML",
    )


@router_register.message(StateFilter(Register.full_name))
async def process_full_name(message: types.Message, state: FSMContext):
    full_name: str | None = message.text
    await state.update_data(full_name=full_name)
    keyboard = get_phone_keyboard()
    await message.answer(
        "📱 Теперь поделитесь своим номером телефона:",
        reply_markup=keyboard,
    )
    await state.set_state(Register.phone)

    
@router_register.message(StateFilter(Register.phone))
async def process_phone(message: types.Message, state: FSMContext):
    if message.contact is not None:
        phone = message.contact.phone_number
        phone = phone.replace("+", "")
    else:
        phone = message.text.strip()

        if not (phone.startswith("+7") or phone.startswith("8")):
            keyboard = get_phone_keyboard()
            await message.answer(
                "⚠️ Пожалуйста, введите корректный номер телефона:",
                reply_markup=keyboard,
            )
            return

        if phone.startswith("8"):
            phone = "7" + phone[1:]

    headers = {
        "token": os.getenv("TELEGRAM_TOKEN"),
    }

    await state.update_data(phone=phone)
    body = await state.get_data()
    
    response = await obj.make("post", "users/create/", headers=headers, body=body)
    if response["error"]:
        await message.answer("⚠️" + response["message"])
        return
    
    await message.answer("🗒️ Отлично, теперь напишите ИНН компании:")
    await state.set_state(Register.inn)
    

@router_register.message(StateFilter(Register.inn))
async def process_inn(message: types.Message, state: FSMContext):
    inn = message.text.strip()
    if not inn.isdigit() or len(inn) not in [10, 12]:
        await message.answer("⚠️ Пожалуйста, введите корректный ИНН (10/12 цифр)")
        return

    await state.update_data(inn=inn)
    suggestions = dadata.find_by_id(name="party", query=inn)
    cmp = None
    for sug in suggestions:
        if sug["data"]["state"]["status"] == "ACTIVE":
            cmp = sug
            break

    if cmp is None:
        await message.answer("⚠️ По указанному ИНН нет активных компаний, попробуйте ещё раз:")
        return
    
    if cmp['data']['address']['data']['region_with_type'] != "Респ Башкортостан":
        await message.answer("⚠️ По указанному ИНН нет компаний из Республики Башкортостан, попробуйте ещё раз:")
        return


    await message.answer(text=
        f"⚠️ Информация по данному ИНН:\n\n" +
        f"▶️ ИНН: {cmp["data"]["inn"]}\n" +
        f"▶️ Название: {cmp["value"]}\n" +
        f"▶️ Тип: {cmp['data']['opf']['full']}\n" +
        f"▶️ Регион: {cmp['data']['address']['data']['region_with_type']}\n\n" +
        "❓ Приведённые данные верны?",
        reply_markup=get_inn_agreement_keyboard(),
    )

    await state.update_data(title=cmp["value"])
    await state.update_data(type=cmp['data']['opf']['full'])
    await state.set_state(Register.waiting_agreement)


@router_register.callback_query(StateFilter(Register.waiting_agreement), F.data.startswith("inn_agreement:"))
async def process_agreement(callback: types.CallbackQuery, state: FSMContext):
    data = callback.data.split(":")
    if data[1] == "decline":
        await callback.message.edit_text("🗒️ Хорошо, напишите ИНН компании ещё раз:", reply_keyboard_markup=ReplyKeyboardRemove())
        await state.set_state(Register.inn)
        return
    await callback.message.edit_text("🗒️ ИНН подтверждён!", reply_keyboard_markup=ReplyKeyboardRemove())

    await callback.message.answer("✉️ Последний шаг, поделитесь Вашим E-mail:")
    await state.set_state(Register.email)

    
@router_register.message(StateFilter(Register.email))
async def process_email(message: types.Message, state: FSMContext, bot: Bot):
    email = message.text.strip().lower()
    if "@" not in email or "." not in email:
        await message.answer("⚠️ Пожалуйста, введите корректный Email адрес:")
        return
    await state.update_data(email=email)

    headers = {
        "token": os.getenv("TELEGRAM_TOKEN"),
    }
    body = await state.get_data()
    response = await obj.make("post", "users/create/", headers=headers, body=body)
    if response["error"]:
        await message.answer("⚠️ " + response["message"] + " Давайте попробуем ещё раз!")
        return

    await state.clear()
    await message.answer("✅ Регистрация успешно завершена! На указанную почту придёт письмо для подтверждения аккаунта.")
    await asyncio.sleep(1)
    await show_main_menu(message, bot)
