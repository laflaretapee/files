import sys
import os
import asyncio
import logging
import django

from pathlib import Path

# Получаем путь к директории app
BASE_DIR = Path(__file__).resolve().parent.parent
APP_DIR = BASE_DIR / 'app'

# Добавляем путь к директории app в PYTHONPATH
sys.path.append(str(APP_DIR))

# Устанавливаем переменную окружения для Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'app.settings')

from aiogram.client.default import DefaultBotProperties
from aiogram.types import BotCommandScopeAllPrivateChats
from aiogram import Bot, Dispatcher

django.setup()

from dotenv import load_dotenv

# Импортируем router после инициализации Django
from handlers.handlers import router_register
from handlers.support_handlers import support_router
from handlers.choose_supports import router_choose

from common.common import common_router
from common.config import BOT_COMMANDS


logging.basicConfig(level=logging.INFO)
load_dotenv()

bot = Bot(token=os.getenv("TELEGRAM_TOKEN"), default=DefaultBotProperties(parse_mode='HTML'))

dp = Dispatcher()

dp.include_router(router_register)
dp.include_router(support_router)
dp.include_router(router_choose)
dp.include_router(common_router)



async def main():

    await bot.delete_my_commands()
    await bot.set_my_commands(commands=BOT_COMMANDS, scope=BotCommandScopeAllPrivateChats())

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        ...