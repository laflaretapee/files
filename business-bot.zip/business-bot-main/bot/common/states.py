from email import policy
from aiogram.fsm.state import State, StatesGroup

class Register(StatesGroup):
    start = State()
    policy = State()
    full_name = State()
    phone = State()
    email = State()
    inn = State()
    waiting_agreement = State()

class Help(StatesGroup):
    message = State()

class Questions(StatesGroup):
    question = State()
