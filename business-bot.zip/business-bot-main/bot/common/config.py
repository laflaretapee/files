from aiogram.types import BotCommand


BTN_TXT_MENU    = "📱 Меню"
BTN_TXT_CATALOG = "📃 Каталог"
BTN_TXT_PROFILE = "🧑‍🦰 Профиль"
BTN_TXT_SUPPORT = "ℹ️ Поддержка"


CMD_MENU = "menu"
CMD_CATALOG = "catalog"
CMD_PROFILE = "profile"
CMD_SUPPORT = "support"

BOT_COMMANDS = [
    BotCommand(command=CMD_MENU, description="Открыть главное меню"),
    BotCommand(command=CMD_CATALOG, description="Открыть каталог предложений"),
    BotCommand(command=CMD_PROFILE, description="Посмотреть профиль"),
    BotCommand(command=CMD_SUPPORT, description="Помощь и поддержка"),
]