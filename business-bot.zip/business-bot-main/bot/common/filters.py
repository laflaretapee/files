import os
import re

from aiogram.filters import Filter
from aiogram.types import Message, Update

from users.utils import AsyncHttpRequestor


class ChatTypeFilter(Filter):
    def __init__(self, chat_types: list[str]) -> None:
        self.chat_types = chat_types
    async def __call__(self, update: Update) -> bool:
        event = update if isinstance(update, Message) else update.message
        return event.chat.type in self.chat_types


class UserAuthStatusFilter(Filter):
    def __init__(self) -> None:
        self.obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
        self.headers["token"] = os.getenv("TELEGRAM_TOKEN")

    async def __call__(self, update: Update) -> bool:
        username = str(update.from_user.id)
        self.headers["username"] = username
        response = await self.obj.make("get", "users/profile", headers=self.headers)
        if response["error"]:
            return -1  # Ошибка получения данных
        
        # Определяем уровень регистрации
        profile = response["data"]
        if profile.get("username") and profile.get("full_name") and profile.get("phone"):
            if profile.get("inn") and profile.get("title") and profile.get("category") and profile.get("email"):
                if profile.get("email_verified"):
                    if profile.get("role") and profile.get("connection"):
                        return 3  # Полностью заполненный профиль
                    return 2  # Почта подтверждена
                return 1  # Заполнены ИНН, название, категория
            return 0  # Заполнены имя, логин, телефон
        return -1  # Данные отсутствуют
