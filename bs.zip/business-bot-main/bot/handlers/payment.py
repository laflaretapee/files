import os

import uuid

from datetime import datetime, timedelta

from asgiref.sync import sync_to_async

from yookassa import Configuration, Payment, Invoice

from Payment.models import YookassaPayment # type: ignore
from django.utils.timezone import now


Configuration.account_id = os.getenv('YOOKASSA_SHOP_ID')
Configuration.secret_key = os.getenv('YOOKASSA_SECRET_KEY')

async def create_payment(measure, user_id, bot_username, payment_method="card"):
    payment_params = {
        "amount": {
            "value": f"{float(measure['data']['price']):.2f}",
            "currency": "RUB"
        },
        "confirmation": {
            "type": "redirect",
            "return_url": f"https://t.me/{bot_username}"
        },
        "description": f"Покупка: {measure['data']['name']}",
        "payment_method_data": {
            "type": "bank_card" if payment_method == "card" else "sbp"
        },
        "capture": True,
        "metadata": {
            "user_id": user_id,
            "measure_id": measure["data"]["id"],
            "bot_username": bot_username
        }
    }

    payment = Payment.create(payment_params)
    
    await sync_to_async(YookassaPayment.objects.create)(
        payment_id=payment.id,
        user_id=user_id,
        measure_id=measure["data"]["id"],
        amount=float(measure['data']['price']),
        currency='RUB',
        description=f"Покупка: {measure['data']['name']}",
        status=payment.status
    )

    return payment

async def create_invoice(order_data: dict, user_id: str, bot_username: str):
    """Создание платежа через СБП"""
    try:
        idempotence_key = str(uuid.uuid4())
        
        payment_params = {
            "amount": {
                "value": order_data['total_amount'],
                "currency": "RUB"
            },
            "payment_method_data": {
                "type": "sbp"
            },
            "confirmation": {
                "type": "redirect",
                "return_url": f"https://t.me/{bot_username}"
            },
            "description": order_data.get('description', 'Оплата меры поддержки'),
            "capture": True,
            "metadata": {
                "user_id": user_id,
                "bot_username": bot_username,
                "order_id": order_data['order_id']
            }
        }

        # Создание платежа
        payment = Payment.create(payment_params, idempotence_key)

        # Сохранение данных в модель
        payment_record = await sync_to_async(YookassaPayment.objects.create)(
            payment_id=payment.id,
            user_id=user_id,
            amount=float(order_data['total_amount']),
            currency='RUB',
            description=payment.description,
            status=payment.status,
            expires_at=(now() + timedelta(days=3)).isoformat()
        )

        return {
            "success": True,
            "payment_url": payment.confirmation.confirmation_url,
            "payment_id": payment.id,
            "yookassa_id": payment_record.id
        }

    except Exception as e:
        logger.error(f"Ошибка создания платежа: {str(e)}")
        return {
            "success": False,
            "error": str(e)
        }
