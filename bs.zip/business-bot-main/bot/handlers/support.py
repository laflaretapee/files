import os
import asyncio

from logging import getLogger
import stat


from aiogram import Bot, types, Router, F
from aiogram.filters import Command, StateFilter, or_f
from aiogram.fsm.context import FSMContext

from common.config import BTN_TXT_CANCEL, BTN_TXT_SUPPORT, CMD_CANCEL, CMD_SUPPORT
from common.states import Help
from keyboards.keyboards import create_telegram_link, get_cancel_kbrd, get_main_menu_keyboard

from users.utils import AsyncHttpRequestor  # type: ignore


router_choose = Router()


obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
logger = getLogger(__name__)


@router_choose.message(StateFilter("*"), or_f(F.text == BTN_TXT_CANCEL, Command(CMD_CANCEL)))
async def cancel(message: types.Message, state: FSMContext, bot: Bot):
    if state:
        await message.answer("⚠️ Операция была отменена!", reply_markup=get_main_menu_keyboard())
        await state.clear()

# @router_choose.callback_query(StateFilter(None), F.data.startswith("support:measures"))
# async def start_answering(callback: types.Message, state: FSMContext):
#     username = str(callback.from_user.id)
#     headers = {
#         "token": os.getenv("TELEGRAM_TOKEN"),
#         "username": username,
#     }
#     response = await obj.make("get", "requests/get-questions/", headers=headers)
#     if response["error"]:
#         await callback.answer("⚠️ " + response["message"], show_alert=True)
#         return
    
#     questions = response["data"]

#     await state.set_state(Questions.question)
#     await state.update_data({"questions": questions})
#     await callback.message.delete()
#     await callback.message.answer(questions[0]["question_text"], reply_markup=get_cancel_kbrd())
    

# @router_choose.message(StateFilter(Questions.question))
# async def question_answer(message: types.Message, state: FSMContext, bot: Bot):
#     data = await state.get_data()
#     questions = data.get("questions", [])
#     answers = data.get("answers", [])

#     answers.append({"question": questions[0]["question_text"], "answer": message.text})
    
#     # Убираем текущий вопрос из списка
#     questions = questions[1:]

#     if questions:
#         await state.update_data(questions=questions, answers=answers)
#         await message.answer(questions[0]["question_text"])  # Задаем следующий вопрос
#     else:
#         username = str(message.from_user.id)
#         headers = {
#             "token": os.getenv("TELEGRAM_TOKEN"),
#         }
#         body = {
#             "username": username,
#             "answers": str(answers),
#         }
#         response = await obj.make("post", "requests/send-answers/", headers=headers, body=body)
#         await state.clear()
#         if response["error"]:
#             await message.answer("⚠️ " + response["message"])
#             return
            
#         msg = response["data"]["message"]
#         full_name = response["data"]["full_name"]
#         request_id = response["data"]["request_id"]
        
#         try:
#             response_option = await obj.make("get", "options/get", headers=headers, params={"option": "bot_chat_id"})
#             option_value = response_option["message"]


#             await bot.send_message(
#                 chat_id=option_value,
#                 reply_markup=create_telegram_link(username),
#                 text=\
#                 f"🔔 Подбор мер поддержки для пользователя: {full_name}!\n\n{msg}"
#             )
#         except Exception as e:
#             logger.error(e)

#         await message.answer(f"✅ Спасибо за ваши ответы! Заявка отправлена администрации!\n🆔 Номер обращения: {request_id}")
#         await asyncio.sleep(1)
        

# @router_choose.callback_query(StateFilter(None), F.data.startswith("support:service"))

@router_choose.message(StateFilter(None), or_f(F.text == BTN_TXT_SUPPORT, Command(CMD_SUPPORT)))
async def make_help_request(message: types.Message, state: FSMContext):
    await message.reply("💬 Напишите сообщение для службы поддержки:", reply_markup=get_cancel_kbrd())
    await state.set_state(Help.message)


@router_choose.message(StateFilter(Help.message))
async def process_help_request(message: types.Message, state: FSMContext, bot: Bot):
    
    username = str(message.from_user.id)
    msg = message.text

    headers = {
        "token": os.getenv("TELEGRAM_TOKEN"),
    }

    body = {
        "username": username,
        "message": message.text,
    }

    response = await obj.make("post", "requests/help/", headers=headers, body=body)
    
    await state.clear()
    if response["error"]:
        await message.answer("⚠️ " + response["message"])
        return
    
    full_name = response["data"]["full_name"]
    request_id = response["data"]["request_id"]
    
    try:
        response_option = await obj.make("get", "options/get", headers=headers, params={"option": "bot_chat_id"})
        option_value = response_option["message"]


        await bot.send_message(
            chat_id=option_value,
            reply_markup=create_telegram_link(username),
            text=\
            f"🔔 Обращение в службу поддержки от пользователя: {full_name}!\n\n«<b><i>{msg}</i></b>»"
        )
    except Exception as e:
        logger.error(e)

    await message.answer(f"✅ Ваша заявка успешно отправлена!\n🆔 Номер обращения: {request_id}", reply_markup=get_main_menu_keyboard())
    await asyncio.sleep(1)
    await state.clear()
