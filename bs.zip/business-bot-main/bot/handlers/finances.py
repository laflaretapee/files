import os

from aiogram import Bot, Router, F, types
from aiogram.filters import StateFilter, or_f
from aiogram.fsm.context import FSMContext
from aiogram.methods import get_me
from aiogram.utils.keyboard import InlineKeyboardBuilder

from keyboards.keyboards import get_main_menu_keyboard
from users.utils import AsyncHttpRequestor # type: ignore

from common.states import Regulators


finances_router = Router()

obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
headers = {"token": os.getenv("TELEGRAM_TOKEN")}


# @finances_router.callback_query(StateFilter(Regulators.price), F.data.startswith("price:"))
@finances_router.callback_query(StateFilter(Regulators.price), F.data.startswith("price:"))
async def choose_type(callback: types.CallbackQuery, state: FSMContext):
    
    data = callback.data.split(":")
    price = f"{data[1]}:{data[2]}"
    await state.update_data(price=price)

    areas = await obj.make("get", "supports/areas", headers=headers)
    if areas["error"]:
        await callback.message.delete()
        await callback.message.answer("⚠️ Не удалось получить список сфер! Пожалуйста, попробуйте позже!", reply_markup=get_main_menu_keyboard())
        await state.clear()
        return

    builder = InlineKeyboardBuilder()
    for area in areas["data"]:
        builder.row(types.InlineKeyboardButton(text=f"{area['title']}", callback_data=f"type:{area['area_id']}"))
    keyboard = builder.as_markup()

    await callback.message.edit_text("▶️ Отлично! Теперь давайте определимся со сферой поддержки. Выберите сферу:", reply_markup=keyboard)
    await state.set_state(Regulators.types)


@finances_router.callback_query(StateFilter(Regulators.types), F.data.startswith("type:"))
async def measures_view(callback: types.CallbackQuery, state: FSMContext):
    user_data = await state.get_data()
    price = user_data.get('price').split(":")

    area_id = callback.data.split(":")[1]
    measures = await obj.make(
        "get",
        "supports/get-supports-by-area/",
        headers=headers,
        params={"area_id": area_id},
    )

    builder = InlineKeyboardBuilder()

    if not measures["error"]:
        filtered_measures = measures["data"]
        if price:
            price_threshold = float(price[1])
            tmp = []
            for measure in measures["data"]:
                price_ = float(measure.get('price', 0))
                if (price_ >= 0 and 
                    (price_ <= price_threshold and price[0] == "<") or 
                    (price_ >= price_threshold and price[0] == ">")):
                    tmp.append(measure)
            filtered_measures = tmp

        for measure in filtered_measures:
            measure_price = float(measure.get("price", 0.0))
            builder.add(
                types.InlineKeyboardButton(
                    text=f"{measure['measure_name']} {f'(Бесплатно)' if measure_price == 0.0 else f'({measure_price} ₽)'}",
                    callback_data=f"measure_{measure['measure_id']}_{user_data.get('price')}_{area_id}_search",
                )
            )

        await callback.message.delete()
        if not filtered_measures:
            await callback.message.answer("⚠️ Нет мер поддержки, соответствующих выбранному фильтру!", reply_markup=get_main_menu_keyboard())
            await state.clear()
            return

        await callback.message.answer("✅ Поиск завершен!", reply_markup=get_main_menu_keyboard())
        await callback.message.answer(
            "🔮 Спасибо за ваши ответы! Вот что мне удалось найти по вашим запросам:", 
            reply_markup=builder.adjust(1).as_markup()
        )
    else:
        await callback.answer("⚠️ Не удалось получить список мер поддержки!")
    await state.clear()



@finances_router.callback_query(StateFilter(None), F.data.startswith("search:"))
async def measures_view(callback: types.CallbackQuery, state: FSMContext):

    data = callback.data.split(":")
    area_id = data[3]
    price_raw = f"{data[1]}:{data[2]}"
    price=price_raw.split(":")
    measures = await obj.make(
        "get",
        "supports/get-supports-by-area/",
        headers=headers,
        params={"area_id": area_id},
    )

    builder = InlineKeyboardBuilder()

    if not measures["error"]:
        filtered_measures = measures["data"]
        if price:
            price_threshold = float(price[1])
            tmp = []
            for measure in measures["data"]:
                price_ = float(measure.get('price', 0))
                if (price_ >= 0 and 
                    (price_ <= price_threshold and price[0] == "<") or 
                    (price_ >= price_threshold and price[0] == ">")):
                    tmp.append(measure)
            filtered_measures = tmp

        for measure in filtered_measures:
            measure_price = float(measure.get("price", 0.0))
            builder.add(
                types.InlineKeyboardButton(
                    text=f"{measure['measure_name']} {f'(Бесплатно)' if measure_price == 0.0 else f'({measure_price} ₽)'}",
                    callback_data=f"measure_{measure['measure_id']}_{price_raw}_{area_id}_search",
                )
            )

        if not filtered_measures:
            await callback.answer(
                "⚠️ Нет мер поддержки, соответствующих выбранному фильтру.",
                show_alert=True
            )
            await state.clear()
            return
        
        await callback.message.edit_text(
            "🔮 Спасибо за ваши ответы! Вот что мне удалось найти по вашим предпочтениям:", 
            reply_markup=builder.adjust(1).as_markup()
        )
    else:
        await callback.answer("⚠️ Не удалось получить список мер поддержки!")
    await state.clear()