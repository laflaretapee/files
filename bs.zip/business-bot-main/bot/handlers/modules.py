import os
from unicodedata import category

from aiogram import Bot, Router, F, types
from aiogram.filters import StateFilter, or_f
from aiogram.fsm.context import FSMContext
from aiogram.methods import get_me
from aiogram.utils.keyboard import InlineKeyboardBuilder

from keyboards.keyboards import get_cancel_kbrd, get_main_menu_keyboard
from users.utils import AsyncHttpRequestor  # type: ignore

from common.states import RegulatorsMods


modules_router = Router()

obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
headers = {"token": os.getenv("TELEGRAM_TOKEN")}


@modules_router.callback_query(F.data.startswith("mod_category_"))
async def process_category_modules_selection(
    callback: types.CallbackQuery, state: FSMContext
):
    """Обработчик выбора категории"""
    username = str(callback.from_user.id)
    headers["username"] = username
    response = await obj.make("get", "/filters/get-directions-filters", headers=headers)
    category_id = callback.data.split("_")[2]

    if response["error"]:
        await callback.message.answer("⚠️ " + response["message"])
        return

    await callback.message.delete()
    await state.set_state(RegulatorsMods.dirs)
    await state.update_data({"category_id": category_id})
    await callback.message.answer(
        "📊 Поиск по платным модулям...", reply_markup=get_cancel_kbrd()
    )
    builder = InlineKeyboardBuilder()
    for dir_ in response["data"]:
        builder.row(
            types.InlineKeyboardButton(
                text=f"{dir_["title"]}",
                callback_data=f"direction:{dir_['direction_id']}",
            )
        )
    keyboard = builder.as_markup()
    await callback.message.answer(
        "🏹 Какое направление из перечисленных Вас интересует? ", reply_markup=keyboard
    )


@modules_router.callback_query(
    StateFilter(RegulatorsMods.dirs), F.data.startswith("direction:")
)
async def process_direction_modules_selection(
    callback: types.CallbackQuery, state: FSMContext
):
    data = callback.data.split(":")
    direction_id = data[1]
    await state.update_data(direction_id=direction_id)

    temp = await state.get_data()
    category_id = temp.get("category_id")

    response = await obj.make(
        "get", "/supports/category", headers=headers, params={"id": category_id}
    )
    if response["error"]:
        await callback.message.answer("⚠️ " + response["message"])
        return
    builder = InlineKeyboardBuilder()

    def construct_keyboard(category):
        for cat in category["children"]:
            builder.row(
                types.InlineKeyboardButton(
                    text=f"{cat["category_name"]}",
                    callback_data=f"cat:{cat['category_id']}:{direction_id}",
                )
            )
            if cat.get("children", None):
                construct_keyboard(cat)

    construct_keyboard(response["data"])
    keyboard = builder.as_markup()
    await state.set_state(RegulatorsMods.cats)
    await callback.message.edit_text(
        "🛒 Хорошо, а теперь давайте выберем категорию: ", reply_markup=keyboard
    )


@modules_router.callback_query(
    StateFilter(RegulatorsMods.cats), F.data.startswith("cat:")
)
async def process_direction_modules_selection(
    callback: types.CallbackQuery, state: FSMContext
):
    data = callback.data.split(":")
    category_id = data[1]
    direction_id = data[2]

    response = await obj.make(
        "get",
        "/filters/get-measures-dirandcat",
        headers=headers,
        params={"category_id": category_id, "direction_id": direction_id},
    )
    await callback.message.delete()
    if not response["error"]:
        builder = InlineKeyboardBuilder()
        for measure in response["data"]:
            measure_price = float(measure.get("price", 0.0))
            builder.row(
                types.InlineKeyboardButton(
                    text=f"{measure['measure_name']} {f'(Бесплатно)' if measure_price == 0.0 else f'({measure_price} ₽)'}",
                    callback_data=f"measure_{measure['measure_id']}_{category_id}_{direction_id}_modules",
                )
            )
        await callback.message.answer("✅ Поиск завершен!", reply_markup=get_main_menu_keyboard())
        await callback.message.answer(
            "🔮 Спасибо за ваши ответы! Вот что мне удалось найти по вашим предпочтениям:",
            reply_markup=builder.adjust(1).as_markup(),
        )
    else:
        await callback.message.answer("⚠️ Нет мер поддержки, соответствующих выбранному фильтру!", reply_markup=get_main_menu_keyboard())
    await state.clear()


@modules_router.callback_query(
    StateFilter(None), F.data.startswith("modules:")
)
async def process_direction_modules_selection(
    callback: types.CallbackQuery, state: FSMContext
):
    data = callback.data.split(":")
    category_id = data[1]
    direction_id = data[2]

    response = await obj.make(
        "get",
        "/filters/get-measures-dirandcat",
        headers=headers,
        params={"category_id": category_id, "direction_id": direction_id},
    )
    await callback.message.delete()
    if not response["error"]:
        builder = InlineKeyboardBuilder()
        for measure in response["data"]:
            measure_price = float(measure.get("price", 0.0))
            builder.row(
                types.InlineKeyboardButton(
                    text=f"{measure['measure_name']} {f'(Бесплатно)' if measure_price == 0.0 else f'({measure_price} ₽)'}",
                    callback_data=f"measure_{measure['measure_id']}_{category_id}_{direction_id}_modules",
                )
            )
        await callback.message.answer(
            "🔮 Спасибо за ваши ответы! Вот что мне удалось найти по вашим предпочтениям:",
            reply_markup=builder.adjust(1).as_markup(),
        )
    else:
        await callback.message.answer("⚠️ Нет мер поддержки, соответствующих выбранному фильтру!", reply_markup=get_main_menu_keyboard())
    await state.clear()