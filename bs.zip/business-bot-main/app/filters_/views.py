from unicodedata import category
from asgiref.sync import sync_to_async

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from supports.models import SupportMeasure
from filters_.models import DirectionsFilter, MoneyAmountFilter
from requests_.utils import validate_telegram_token
from requests_.utils import validate_telegram_token


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_money_filters_view(request):
    """
    Возвращает все категории в виде вложенного словаря вместе с мерами поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    Опционально можно передать category_id для получения конкретной категории.
    """
    try:
        money = MoneyAmountFilter.objects.all()

        data = [
            {
                "money_id": mon.id,
                "type": mon.type_srt,
                "value": mon.value,
            }
            for mon in money
        ]

        if not data:
            raise ValueError("Отсутствуют денежные суммы!")

        return JsonResponse(
            {"error": False, "message": "Денежные суммы успешно получены", "data": data},
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"Ошибка при получении денежных сумм: {str(e)}"},
            status=500,
        )

@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_directions_filters_view(request):
    """
    Возвращает все категории в виде вложенного словаря вместе с мерами поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    Опционально можно передать category_id для получения конкретной категории.
    """
    try:
        dirs = DirectionsFilter.objects.all().exclude(name="Без направления")

        data = [
            {
                "direction_id": direction.id,
                "title": direction.name,
            }
            for direction in dirs
        ]

        if not data:
            raise ValueError("Направления не найдены!")

        return JsonResponse(
            {"error": False, "message": "Направления успешно получены", "data": data},
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"Ошибка при получении направлений: {str(e)}"},
            status=500,
        )
    
@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_measures_by_dirandcat_view(request):
    category_id = request.GET.get("category_id")
    direction_id = request.GET.get("direction_id")

    if not category_id or not direction_id:
        return JsonResponse({"error": True, "message": "Переданы не все данные"}, status=400)
    
    try:
        measures = SupportMeasure.objects.filter(category=category_id, direction=direction_id)

        data = [
            {
                "measure_id": measure.id,
                "measure_name": measure.name,
                "measure_descr": measure.description,
                "min_trust": measure.min_trust,
                "price": measure.price,
            }
            for measure in measures
        ]

        if not data:
            raise ValueError("Меры поддержки не найдены!")

        return JsonResponse(
            {"error": False, "message": "Меры поддержки успешно получены", "data": data},
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"Ошибка при получении мер поддержки: {str(e)}"},
            status=500,
        )