from django.urls import path

from . import views

app_name= "filters"

urlpatterns = [
    path("get-money-filters/", views.get_money_filters_view, name="get-money-filters"),
    path("get-directions-filters/", views.get_directions_filters_view, name="get-directions-filters"),
    path("get-measures-dirandcat/", views.get_measures_by_dirandcat_view, name="get-measures-dirandcat"),
]
