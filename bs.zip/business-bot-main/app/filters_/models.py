from django.core.validators import MinValueValidator
from django.db import models

# Create your models here.

class MoneyAmountFilter(models.Model):

    class MoneyChoices(models.TextChoices):
        LOWER_THAN = "<", "Меньше чем"
        HIGHER_THAN = ">", "Больше чем"

    value = models.DecimalField(verbose_name="Значение", max_digits=10, decimal_places=2, default=0.00,
        validators=[
            MinValueValidator(0.00)
        ])
    type_srt = models.CharField(verbose_name="Тип", max_length=10, choices=MoneyChoices)

    def __str__(self):
        return f"{self.type_srt} {self.value}"

    class Meta:
        db_table = "support_measure_money_amounts"
        verbose_name = "Денежная сумма"
        verbose_name_plural = "Денежные суммы"


class DirectionsFilter(models.Model):
    name = models.CharField(
        verbose_name="Направление", max_length=128, unique=True
    )
   
    @classmethod
    def get_default_direction(cls):
        obj, _ = DirectionsFilter.objects.get_or_create(name="Без направления")
        return obj.id

    def __str__(self):
        return self.name

    class Meta:
        db_table = "support_measure_directions"
        verbose_name = "Направление"
        verbose_name_plural = "Направления"