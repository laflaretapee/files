from django.contrib import admin

from filters_.models import DirectionsFilter, MoneyAmountFilter

# Register your models here.


@admin.register(DirectionsFilter)
class DirectionsFilterAdmin(admin.ModelAdmin):
    list_display = ["name"]

@admin.register(MoneyAmountFilter)
class MoneyAmountFilterAdmin(admin.ModelAdmin):
    list_display = ["value", "type_srt"]