from django import forms

from requests_.models import Notification


class NotificationAdminForm(forms.ModelForm):
    """
    Модель формы для создания уведомления из админки.
    """

    send_to_all = forms.BooleanField(
        required=False,
        label="Отправить всем пользователям",
        help_text= \
        "Если включено, уведомление будет отправлено всем пользователям, "\
        "и выбор индивидуальных пользователей будет проигнорирован.",
    )

    def clean(self):
        cleaned_data = super().clean()
        send_to_all = cleaned_data.get("send_to_all")
        targets = cleaned_data.get("targets")

        if not send_to_all and not targets:
            raise forms.ValidationError(
                "Необходимо выбрать пользователей или установить флаг 'Отправить всем пользователям'."
            )
        return cleaned_data

    class Meta:
        model = Notification
        fields = "__all__"
