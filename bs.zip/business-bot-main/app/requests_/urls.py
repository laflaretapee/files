from django.urls import path

from . import views

app_name= "requests"

urlpatterns = [
    path("help/", views.make_help_view, name="help"),
    # path("get-questions/", views.get_questions_view, name="questions"),
    # path("send-answers/", views.send_answers_view, name="questions"),
]