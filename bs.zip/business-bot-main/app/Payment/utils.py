import os
from yookassa import Configuration, Payment
from django.conf import settings
from models import Payment as PaymentModel

# Настройка YooKassa
Configuration.account_id = settings.YOOKASSA_ACCOUNT_ID
Configuration.secret_key = settings.YOOKASSA_SECRET_KEY

def save_payment(payment_id):
    try:
        yk_payment = Payment.find_one(payment_id)
        PaymentModel.objects.update_or_create(
            payment_id=yk_payment.id,
            defaults={
                'user_id': yk_payment.metadata.get('user_id'),  # Предполагается, что user_id передается в metadata
                'amount': yk_payment.amount.value,
                'currency': yk_payment.amount.currency,
                'status': yk_payment.status,
            }
        )
    except Exception as e:
        print(f"Ошибка при сохранении платежа: {e}")