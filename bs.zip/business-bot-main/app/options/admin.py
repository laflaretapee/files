from django.contrib import admin
from django.forms import Textarea
from django.db import models

from options.models import Option


@admin.register(Option)
class OptionAdmin(admin.ModelAdmin):

    list_display = (
        "id", 
        "category", 
        "value"
    )
    list_editable = ("value",)
    readonly_fields = ["category"]

    formfield_overrides = {
        models.TextField: {'widget': Textarea(attrs={'rows': 1, 'cols': 96})},
    }

    fieldsets = (
        (
            "Основная информация",
            {
                "fields": ("category", "value"),
            },
        ),
    )

    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
