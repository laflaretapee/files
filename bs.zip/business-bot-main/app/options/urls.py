from django.urls import path

from . import views


app_name= "options"

urlpatterns = [
    path("get/", views.get_option_view, name="get-option"),
]