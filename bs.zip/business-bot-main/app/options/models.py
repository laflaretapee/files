import os
from django.db import models


class Option(models.Model):

    class OptionCategories(models.TextChoices):
        
        START_TEXT = "start_text", "Стартовый текст"
        MENU_TEXT = "menu_text", "Текст главного меню"
        CATALOG_TEXT = "catalog_text", "Текст каталога"
        
        MODULES_ID = "modules_id", "ID категории с модулями"
        PERSONAL_URL = "personal_data_handling_url", "Ссылка на политику обработки персональных данных"
        POLICY_URL = "policy_url", "Ссылка на политику конфиденциальности"
        BOT_CHAT_ID = "bot_chat_id", "ID чата с ботом"
        BOT_URL = "bot_url", "Фрагмент ссылки на бота"
        
        # BX24_VACUUM = "bx24_vacuum", "ID воронки в CRM Битрикс24"
        # BX24_USER_ID = "bx24_user_id", "ID пользователя в CRM Битрикс24"
        # BX24_WEBHOOK_URL = "bx24_webhook_url", "URL вебхука в CRM Битрикс24"
        # BX24_WEBHOOK_KEY = "bx24_webhook_key", "URL ключа вебхука в CRM Битрикс24"

    value = models.TextField(verbose_name="Значение")
    category = models.CharField(verbose_name="Настройка", max_length=128, unique=True, choices=OptionCategories)

    def __str__(self) -> str:
        return self.get_category_display()

    class Meta:
        db_table = "options"
        verbose_name = "Параметр"
        verbose_name_plural = "Параметры"
