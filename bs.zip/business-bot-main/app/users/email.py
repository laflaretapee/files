import os

from django.core.mail import send_mail
from django.urls import reverse
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import PasswordResetTokenGenerator


email_verification_token = PasswordResetTokenGenerator()

def send_verification_email(user, request, email):
    """
    Функция для отправки писем на электронную почту 
    пользователя.Для её подтверждения.
    """
    
    if user.email_verified:
        return 2

    token = email_verification_token.make_token(user)
    uid = urlsafe_base64_encode(force_bytes(user.pk))

    verification_url = request.build_absolute_uri(
        reverse('users:verify', kwargs={'uidb64': uid, 'token': token})
    )

    subject = "Подтверждение электронной почты"
    message = \
        f"Здравствуйте, {user.full_name}!\n\n"\
        f"Перейдите по ссылке, чтобы подтвердить вашу почту:\n{verification_url}"
    
    return send_mail(subject, message, os.getenv("SMTP_EMAIL"), [email])
