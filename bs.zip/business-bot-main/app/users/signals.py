from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver

@receiver(post_save, sender=User)
def check_staff_status(sender, instance, **kwargs):
    if instance.is_staff:
        if not instance.has_usable_password():
            raise ValueError("Невозможно установить статус персонала без пароля!")
        else:
            print(f"Пользователь {instance.username} стал персоналом.")
