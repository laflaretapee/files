import os

from aiogram.filters import Filter
from aiogram.types import Message, Update

from users.utils import AsyncHttpRequestor  # type: ignore


class ChatTypeFilter(Filter):
    def __init__(self, chat_types: list[str]) -> None:
        self.chat_types = chat_types
    async def __call__(self, update: Update) -> bool:
        event = update if isinstance(update, Message) else update.message
        return event.chat.type in self.chat_types


class UserAuthStatusFilter(Filter):
    def __init__(self) -> None:
        self.obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
        self.headers = {}
        self.headers["token"] = os.getenv("TELEGRAM_TOKEN")

    async def __call__(self, update: Update) -> bool:
        
        username = str(update.from_user.id)
        self.headers["username"] = username
        response = await self.obj.make("get", "users/profile", headers=self.headers)
        if response["error"]:
            return False
        
        profile = response["data"]
        for key, value in list(profile.items())[:-2]:
            if not value:
                return False
        return True
