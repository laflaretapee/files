import os
import aiohttp

from logging import getLogger

from aiogram import types, Router, F, Bot
from aiogram.filters import Command, StateFilter, or_f
from aiogram.types import (
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from keyboards.keyboards import create_telegram_link

from common.config import BTN_TXT_CATALOG, CMD_CATALOG

from users.utils import AsyncHttpRequestor  # type: ignore

from .payment import create_payment


support_router = Router()
support_router.message.filter(StateFilter(None))
support_router.callback_query.filter(StateFilter(None))


obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
headers = {
    "token": os.getenv("TELEGRAM_TOKEN"),
}

logger = getLogger(__name__)


def get_categories_keyboard() -> InlineKeyboardMarkup:
    """Создает клавиатуру с категориями мер поддержки"""
    builder = InlineKeyboardBuilder()
    builder.add(
        InlineKeyboardButton(
            text="📋 Просмотр мер поддержки", callback_data="view_measures"
        )
    )
    return builder.as_markup()


async def get_category_keyboard(parent_id: int = None) -> InlineKeyboardMarkup:
    """Создает клавиатуру со списком категорий для заданного родителя"""
    builder = InlineKeyboardBuilder()
    categories = await obj.make("get", "supports/categories/", headers=headers)

    if not categories["error"]:
        # Функция для рекурсивного поиска категории по ID
        def find_category(categories_list, target_id):
            for category in categories_list:
                if category["category_id"] == target_id:
                    return category
                if category["children"]:
                    result = find_category(category["children"], target_id)
                    if result:
                        return result
            return None

        # Определяем, какие категории показывать
        if parent_id is None:
            # Показываем корневые категории
            categories_to_show = categories["data"]
        else:
            # Находим родительскую категорию и показываем её детей
            parent_category = find_category(categories["data"], parent_id)
            categories_to_show = parent_category["children"] if parent_category else []

        # Добавляем кнопки для категорий
        for category in categories_to_show:
            text = category["category_name"]
            # Добавляем индикатор наличия подкатегорий
            if category["children"]:
                text += " 📁"
            builder.add(
                InlineKeyboardButton(
                    text=text, callback_data=f"category_{category['category_id']}"
                )
            )

        # Добавляем кнопку "Назад", если мы не в корневом меню
        if parent_id is not None:
            # Находим ID родительской категории родителя (для кнопки "Назад")
            def find_parent_id(categories_list, child_id):
                for category in categories_list:
                    for child in category["children"]:
                        if child["category_id"] == child_id:
                            return category["category_id"]
                    result = find_parent_id(category["children"], child_id)
                    if result:
                        return result
                return None

            parent_of_parent = find_parent_id(categories["data"], parent_id)
            if parent_of_parent:
                back_data = f"category_{parent_of_parent}"
            else:
                back_data = "back_to_root"

            builder.add(InlineKeyboardButton(text="◀️ Назад", callback_data=back_data))

    builder.adjust(1)
    return builder.as_markup()


@support_router.message(
    StateFilter(None), or_f(F.text == BTN_TXT_CATALOG, Command(CMD_CATALOG))
)
@support_router.callback_query(F.data == "view_measures")
async def cmd_measures(update: types.Message):
    """Обработчик команды /measures"""
    message = update if isinstance(update, Message) else update.message
    keyboard = get_categories_keyboard()

    keyboard = await get_category_keyboard()
    empty = str(keyboard).find("[]")
    if empty != -1:
        await message.answer(
            "⚠️ На данный момент категории отсутствуют!",
        )
        return

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "catalog_text"}
    )
    option_value = response_option["message"]
    await message.answer(option_value, reply_markup=keyboard, parse_mode="HTML")


@support_router.callback_query(F.data.startswith("category_"))
async def process_category_selection(callback: types.CallbackQuery):
    """Обработчик выбора категории"""
    category_id = int(callback.data.split("_")[1])

    # Получаем информацию о категории
    category_data = await obj.make(
        "get", "supports/category", headers=headers, params={"id": category_id}
    )

    if category_data["error"]:
        await callback.answer("Ошибка при получении категории", show_alert=True)
        return

    # Получаем меры поддержки для этой категории
    measures = await obj.make(
        "get",
        "supports/get-supports-by-category/",
        headers=headers,
        params={"id": category_id},
    )
    # Создаем клавиатуру
    builder = InlineKeyboardBuilder()

    # Добавляем подкатегории, если они есть
    if category_data["data"]["children"]:
        for child in category_data["data"]["children"]:
            text = child["category_name"]
            builder.add(
                InlineKeyboardButton(
                    text=text, callback_data=f"category_{child['category_id']}"
                )
            )

    if not category_data["data"]["children"] and not measures["data"]:
        await callback.answer(
            "⚠️ На данный момент меры поддержки отсутствуют!", show_alert=True
        )
        return

    # Добавляем меры поддержки текущей категории
    if not measures["error"]:
        for measure in measures["data"]:
            builder.add(
                InlineKeyboardButton(
                    text=f"{measure['measure_name']} \n{f"(Доступно Вам на {float(measure['min_trust']) * 100}%)" if measure['min_trust'] else ''}",
                    callback_data=f"measure_{measure['measure_id']}",
                )
            )

    # Добавляем кнопку "Назад"
    # Находим ID родительской категории
    parent_id = category_data["data"]["parent_id"]
    if parent_id:
        back_data = f"category_{parent_id}"
    else:
        back_data = "back_to_root"

    builder.add(InlineKeyboardButton(text="◀️ Назад", callback_data=back_data))

    builder.adjust(1)

    # Формируем текст сообщения
    text = f"📁 <b>Категория:\n  └{category_data['data']['category_name']}</b>\n"
    if category_data["data"]["category_descr"]:
        text += f"\n{category_data['data']['category_descr']}\n"

    # Добавляем заголовки секций, если есть соответствующий контент
    sections = []
    empty = 0

    if category_data["data"]["children"]:
        sections.append("\n📂 Подкатегории:")
    else:
        empty += 1
    if not measures["error"] and measures["data"]:
        sections.append("\n📄 Меры поддержки в текущей категории:")
    else:
        empty += 1

    if empty != 2:
        text += "".join(sections)
    else:
        text = "⚠️ На данный момент категории отсутствуют!"

    await callback.message.delete()
    await callback.message.answer(
        text, reply_markup=builder.as_markup(), parse_mode="HTML"
    )
    await callback.answer()


@support_router.callback_query(F.data.startswith("measure_"))
async def process_measure_selection(callback: types.CallbackQuery):
    """Обработчик выбора меры поддержки"""
    measure_id = int(callback.data.split("_")[1])
    measure_data = await obj.make(
        "get", "supports/get-support/", headers=headers, params={"id": measure_id}
    )

    if measure_data["error"]:
        await callback.answer(
            "Ошибка при получении данных о мере поддержки", show_alert=True
        )
        return

    await show_measure_info(callback.message, measure_data["data"], with_image=True)
    await callback.answer()


async def show_measure_info(
    message: types.Message, measure_data: dict, with_image: bool = True
):
    """
    Отображает информацию о мере поддержки

    Args:
        message: Сообщение для редактирования
        measure_data: Данные о мере поддержки
        with_image: Флаг отображения с картинкой
    """
    builder = InlineKeyboardBuilder()

    price = float(measure_data["price"])
    is_paid = price > 0
    btn_text = "🛒 Купить" if is_paid else "📥 Получить"
    callback_action = f"{'buy' if is_paid else 'get'}_measure_{measure_data['id']}"
    builder.row(InlineKeyboardButton(text=btn_text, callback_data=callback_action))

    # Кнопка "Назад"
    builder.row(
        InlineKeyboardButton(
            text="◀️ Назад к категории",
            callback_data=f"category_{measure_data['category_id']}",
        )
    )

    text = (
        f"📋 {measure_data['name']}\n\n"
        f"{measure_data['descr']}\n\n"
        f"🏷 Категория:\n  └{measure_data['category']}"
    )
    if is_paid:
        text += f"\n\n💰 Стоимость: {measure_data['price']}₽"

    keyboard = builder.as_markup()

    # Если нужно показать изображение
    if with_image and measure_data.get("image_url"):
        image_file = FSInputFile(measure_data["image_url"])

        try:
            await message.delete()
        except Exception as e:
            logger.warning(f"Не удалось удалить сообщение: {e}")

        await message.answer_photo(
            photo=image_file, caption=text, reply_markup=keyboard, parse_mode="HTML"
        )
    else:
        try:
            await message.edit_text(text=text, reply_markup=keyboard, parse_mode="HTML")
        except Exception as e:
            logger.warning(f"Ошибка редактирования текста: {e}")
            await message.delete()
            await message.answer(text=text, reply_markup=keyboard, parse_mode="HTML")


@support_router.callback_query(F.data.startswith("get_measure_"))
async def process_get_measure(callback: types.CallbackQuery, bot: Bot):
    """Обработчик запроса на получение меры поддержки"""
    try:
        measure_id = int(callback.data.split("_")[2])
        measure_data = await obj.make(
            "get", "supports/get-support/", headers=headers, params={"id": measure_id}
        )

        userid = callback.from_user.id

        body = {
            "username": userid,
            "support_id": measure_data["data"]["id"],
            "title": "Получение меры поддержки",
        }

        result = await obj.make(
            "post", "supports/take-support/", headers=headers, body=body
        )
        if result["error"]:
            await callback.answer(f"❌ {result['message']}", show_alert=True)
            return

        gratitude = result.get("gratitude", "")
        await callback.answer(
            f"✅ Ваша заявка успешно отправлена! {gratitude if gratitude else ""}",
            show_alert=True,
        )

        response_option = await obj.make(
            "get", "options/get", headers=headers, params={"option": "bot_chat_id"}
        )
        option_value = response_option["message"]
        msg = result["message"]

        try:
            await bot.send_message(
                chat_id=option_value,
                reply_markup=create_telegram_link(userid),
                text=f"🔔 Приобретение меры поддержки!\n\n{msg}",
            )
        except Exception as e:
            logger.error(e)

    except Exception as e:
        logger.error(f"Ошибка при обработке запроса на получение меры: {e}")
        await callback.answer(
            f"❌ Произошла непредвиденная ошибка. {e}", show_alert=True
        )


@support_router.callback_query(F.data == "back_to_categories")
async def process_back_to_categories(callback: types.CallbackQuery):
    """Обработчик возврата к списку категорий"""
    keyboard = await get_category_keyboard()
    empty = str(keyboard).find("[]")
    if empty != -1:
        await callback.message.edit_text(
            "⚠️ На данный момент категории отсутствуют!",
        )
        return

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "catalog_text"}
    )
    option_value = response_option["message"]

    await callback.message.edit_text(option_value, reply_markup=keyboard)
    await callback.answer()


@support_router.callback_query(F.data.startswith("buy_measure_"))
async def handle_purchase(callback: types.CallbackQuery, bot: Bot):

    measure_id = int(callback.data.split("_")[-1])
    measure = await obj.make(
        "get", "supports/get-support/", headers=headers, params={"id": measure_id}
    )
    if measure["error"]:
        await callback.answer(
            "⚠️ Произошла ошибка при получении меры поддержки! Пожалуйста, попробуйте позже.",
            show_alert=True,
        )
        return

    username = str(callback.from_user.id)
    headers["username"] = username
    response = await obj.make("get", "users/profile", headers=headers)

    if response["error"]:
        await callback.answer(
            "⚠️ Произошла ошибка при проверке пользователя! Пожалуйста, попробуйте позже.",
            show_alert=True,
        )
        return

    user = response["data"]
    if not user["email_verified"]:
        verify = await obj.make("post", "users/send-verify/", headers=headers)
        if verify["error"]:
            await callback.answer(
                f"⚠️ Почта пользователя не подтверждена и произошла ошибка при отправке письма на почту {user['email']}.! Пожалуйста, попробуйте позже или свяжитесь со службой поддержки.",
                show_alert=True,
            )
            return
        await callback.answer(
            f"⚠️ Почта пользователя не подтверждена! Пожалуйста, перейдите по ссылке в письме, которое было отправлено Вам на почту {user['email']}.",
            show_alert=True,
        )
        return

    body = {
        "username": username,
        "support_id": measure_id,
        "title": "Приобретение меры поддержки",
    }

    result = await obj.make(
        "post", "supports/take-support/", headers=headers, body=body
    )
    if result["error"]:
        await callback.answer(f"⚠️ {result}", show_alert=True)
        return

    bot_username = (await bot.get_me()).username
    payment = await create_payment(measure, username, bot_username)

    # Отправляем кнопку для оплаты
    markup = InlineKeyboardBuilder()
    markup.add(
        InlineKeyboardButton(
            text="💳 Оплатить", url=payment.confirmation.confirmation_url
        )
    )
    markup.add(
        InlineKeyboardButton(text="◀️ Назад", callback_data=f"measure_{measure_id}")
    )

    payment_text = (
        f"<b><i>💰 Оплата меры поддержки:</i></b>\n\n"
        f"📚 Название: {measure['data']['name']}\n"
        f"🧮 Сумма: {measure['data']['price']}₽\n\n"
        "⤵️ Нажмите кнопку ниже для перехода к оплате..."
    )

    # Проверяем, содержит ли сообщение картинку
    has_photo = callback.message.photo is not None and len(callback.message.photo) > 0

    try:
        if has_photo:
            # Если сообщение с фото, редактируем подпись
            await callback.message.edit_caption(
                caption=payment_text, reply_markup=markup.as_markup(), parse_mode="HTML"
            )
        else:
            # Если сообщение без фото, редактируем текст
            await callback.message.edit_text(
                text=payment_text, reply_markup=markup.as_markup(), parse_mode="HTML"
            )
    except Exception as e:
        logger.warning(f"Ошибка при редактировании сообщения: {e}")

        # В случае ошибки - удаляем текущее сообщение и отправляем новое
        try:
            await callback.message.delete()
        except Exception as delete_error:
            logger.warning(f"Не удалось удалить сообщение: {delete_error}")

        await callback.message.answer(
            text=payment_text, reply_markup=markup.as_markup(), parse_mode="HTML"
        )

    await callback.answer()


@support_router.callback_query(F.data == "back_to_root")
async def process_back_to_root(callback: types.CallbackQuery):
    """Обработчик возврата к корневым категориям"""
    keyboard = await get_category_keyboard()
    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "catalog_text"}
    )
    option_value = response_option["message"]

    await callback.message.edit_text(option_value, reply_markup=keyboard)
    await callback.answer()
