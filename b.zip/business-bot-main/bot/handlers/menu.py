from aiogram import Router

from common.filters import ChatTypeFilter, UserAuthStatusFilter

from handlers.services import support_router
from handlers.support import router_choose
from handlers.common import common_router

menu_router = Router()
menu_router.message.filter(ChatTypeFilter(['private']), UserAuthStatusFilter())
menu_router.callback_query.filter(ChatTypeFilter(['private']), UserAuthStatusFilter())

menu_router.include_router(support_router)
menu_router.include_router(router_choose)
menu_router.include_router(common_router)