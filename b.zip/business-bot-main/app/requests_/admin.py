import logging

from asgiref.sync import async_to_sync

from django.contrib import admin
from django import forms
from django.utils.html import format_html
from django.urls import reverse

from requests_.models import Notification, SupportRequest, Question, Response
from requests_.forms import NotificationAdminForm
from requests_.utils import send_telegram_message

from users.models import TelegramUser

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = [
        "question",
        "order",
    ]

# В admin.py добавьте:
class ResponseInline(admin.StackedInline):
    model = Response
    extra = 1
    fields = ("message",)
    readonly_fields = ("admin", "created_at")

    def has_change_permission(self, request, obj = ...):
        return False


@admin.register(SupportRequest)
class RequestAdmin(admin.ModelAdmin):
    list_display = [
        "user",
        "title",
        "message_html",
        "date",
        "is_resolved",
        "view_responses"
    ]

    readonly_fields = ["user", "title", "message_html", "date"]

    list_editable = ["is_resolved"]

    fieldsets = (
        (
            "Основная информация",
            {
                "fields": ("user", "title", "message_html", "date"),
            },
        ),
    )

    def message_html(self, obj):
        if obj.message is None:
            return "отсутствует"
        elif obj.title == "Подбор мер поддержки":
            return obj.message
        obj.message = obj.message.replace("\n", "<br>")
        return format_html(obj.message)
    message_html.short_description = "Сообщение"

    def has_delete_permission(self, request, obj = ...):
        return True

    def has_add_permission(self, request):
        return False
    
    # def mark_as_resolved(self, request, queryset):
    #     queryset.update(is_resolved=True)
    #     self.message_user(request, "Заявки помечены как решенные")
    # mark_as_resolved.short_description = "Пометить как решенные"
    
    def view_responses(self, obj):
        url = reverse("admin:requests__response_changelist") + f"?support_request__id={obj.id}"
        return format_html(f'<a href="{url}" class="button">Ответы</a>')
    view_responses.short_description = "Ответы"

    inlines = [ResponseInline]

    # actions = ["mark_as_resolved"]
    # def get_readonly_fields(self, request, obj=None):
    #     return self.readonly_fields + ["is_resolved"]
    
    def save_formset(self, request, form, formset, change):
        """
        Переопределяем метод save_formset для обработки инлайн-формы Response.
        Этот метод вызывается когда сохраняется инлайн-форма (в нашем случае ResponseInline).
        """
        instances = formset.save(commit=False)
        for instance in instances:
            # Проверяем, что это объект Response
            if isinstance(instance, Response):
                # Устанавливаем администратора
                instance.admin = request.user
                instance.save()
                
                # Отправляем сообщение пользователю через Telegram
                message = f"📣 Сотрудник службы поддержки: {request.user.username}\n🆔 ID обращения: {instance.support_request_id}\n\n{instance.message}"
                try:
                    async_to_sync(send_telegram_message)([instance.support_request.user], message)
                except Exception as e:
                    logger.error(f"telegram message: {e}")
                    

        # Удаление отмеченных объектов и сохранение ManyToMany
        for obj in formset.deleted_objects:
            obj.delete()
        formset.save_m2m()


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = [
        "title",
        "message",
        "date",
    ]

    form = NotificationAdminForm

    fieldsets = (
        (
            "Основная информация",
            {
                "fields": ("title", "message"),
            },
        ),
        (
            "Кому придёт уведомление",
            {
                "fields": ("targets", "send_to_all"),
            },
        ),
    )

    def send_to_all(self, obj):
        return "Да" if obj.send_to_all else "Нет"

    send_to_all.short_description = "Отправить всем пользователям"

    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj = ...):
        return True
    
    def save_model(self, request, obj, form, change):
        """
        Функция, вызываемая после нажатия кнопки сохранить.
        Производит проверку и выборку пользователей,
        которым нужно отправить уведомление.

        """
        # Сначала сохраняем модель
        super().save_model(request, obj, form, change)

        # Получаем список пользователей
        send_to_all = form.cleaned_data.get("send_to_all")
        if send_to_all:
            users = list(TelegramUser.objects.filter(username__regex=r"^\d+$"))
        else:
            # Сохраняем связи many-to-many перед получением списка пользователей
            form.save_m2m()
            users = list(obj.targets.all())

        try:
            async_to_sync(send_telegram_message)(users, obj.message, f"🔔 {obj.title}")
        except Exception as e:
            logger.error(f"ERROR telegram message: {e}")

@admin.register(Response)
class ResponseAdmin(admin.ModelAdmin):
    list_display = ["support_request", "admin", "created_at"]
    search_fields = ["message"]
    readonly_fields = ["admin", "created_at"]
    actions = ["send_response_to_user"]

    fieldsets = (
        (
            "Основная информация",
            {
                "fields": ("support_request", "message"),
            },
        ),
    )

    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj = ...):
        return False
    def has_delete_permission(self, request, obj = ...):
        return True

    def send_response_to_user(self, request, queryset):
        for response in queryset:
            user = response.support_request.user
            support_request_id = response.support_request.id
            message = f"📣 Сотрудник службы поддержки: {user.username}\n🆔 ID обращения: {support_request_id}\n\n{response.message}"

            try:            
                async_to_sync(send_telegram_message)([user], message)
            except Exception as e:
                logger.error(f"ERROR telegram message: {e}")
            
        self.message_user(request, f"Ответы отправлены {len(queryset)} пользователям")

    send_response_to_user.short_description = "Отправить ответ пользователю"

    def save_model(self, request, obj, form, change):
        obj.admin = request.user
        user = request.user
        support_request_id = obj.support_request.id
        super().save_model(request, obj, form, change)
        # Автоматическая отправка при сохранении
        message = f"📣 Сотрудник службы поддержки: {user.username}\n🆔 ID обращения: {support_request_id}\n\n{obj.message}"
        try:
            async_to_sync(send_telegram_message)([obj.support_request.user], message)
        except Exception as e:
                logger.error(f"ERROR telegram message: {e}")