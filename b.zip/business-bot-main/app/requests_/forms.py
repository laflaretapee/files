from django import forms

from requests_.models import Notification


class NotificationAdminForm(forms.ModelForm):
    """
    Модель формы для создания уведомления из админки.
    """

    send_to_all = forms.BooleanField(
        required=False,
        label="Отправить всем пользователям",
        help_text= \
        "Если включено, уведомление будет отправлено всем пользователям, "\
        "и выбор индивидуальных пользователей будет проигнорирован.",
    )

    class Meta:
        model = Notification
        fields = "__all__"
