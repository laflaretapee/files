import asyncio
import os
import logging

from functools import wraps
import re

from django.http import JsonResponse

from users.utils import AsyncHttpRequestor


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

obj = AsyncHttpRequestor(f"https://api.telegram.org/")


def validate_telegram_token(func):

    """
    Декоратор для проверки токена Telegram
    """
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        token = request.headers.get("token")
        if not token or token != os.getenv("TELEGRAM_TOKEN"):
            return JsonResponse({"error": True, "message": "Отсутствует токен для запроса"})
        return func(request, *args, **kwargs)
    return wrapper


def async_validate_telegram_token(func):
    """
    Декоратор для проверки токена Telegram
    """
    @wraps(func)
    async def wrapper(request, *args, **kwargs):
        token = request.headers.get("token")
        if not token or token != os.getenv("TELEGRAM_TOKEN"):
            return JsonResponse({"error": True, "message": "Отсутствует токен для запроса"})
        return await func(request, *args, **kwargs)
    return wrapper


async def send_telegram_message(users, message, title=None, chat_id=None):
    """
    Асинхронная функция для отправки сообщений в Telegram.
    Нужно передать список пользователей типа TelegramUser, сообщение и заголовок 
    этого сообщения (необязательно).
    """
    if not users:
        logger.error("Нет пользователей для отправки сообщений: {0}".format(users))
        return

    token = os.getenv("TELEGRAM_TOKEN")
    if not token:
        logger.error("Отсутствует токен для отправки сообщения: {0}".format(token))
        raise ValueError("Отсутствует токен для отправки сообщения")
    
    obj = AsyncHttpRequestor(f"https://api.telegram.org/")
    message = f"{title}\n\n{message}" if title else message
    
    if chat_id:
        response = await obj.make("post", f"bot{token}/sendMessage", body={"chat_id": chat_id, "text": message, "parse_mode": "HTML"})
        return
    
    tasks = []
    for user in users:
        tgid = user.username
        if not tgid and not tgid.isdigit():
            logger.debug(f"error: [{tgid}]")
            continue
        logger.debug(f"bot sent message to [{tgid}]:\n\n{message}\n")
        tasks.append(obj.make("post", f"bot{token}/sendMessage", body={"chat_id": tgid, "text": message, "parse_mode": "HTML"})) 
    result = await asyncio.gather(*tasks)


def remove_emojis(data):
    emoji = re.compile("["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
        u"\U00002500-\U00002BEF"  # chinese char
        u"\U00002702-\U000027B0"
        u"\U000024C2-\U0001F251"
        u"\U0001f926-\U0001f937"
        u"\U00010000-\U0010ffff"
        u"\u2640-\u2642" 
        u"\u2600-\u2B55"
        u"\u200d"
        u"\u23cf"
        u"\u23e9"
        u"\u231a"
        u"\ufe0f"  # dingbats
        u"\u3030"
                      "]+", re.UNICODE)
    return re.sub(emoji, '', data)