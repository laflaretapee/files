
from supports.models import SupportMeasure
from users.models import TelegramUser


def get_recommended_support_measures(user: TelegramUser):
    """
    Функция для вычисления рекомендованных мер поддержки
    с учетом процента доступности для конкретного пользователя.
    
    Принимает в качестве аргумента объект TelegramUser. И возвращает
    список словарей с информацией о доступности меры, её id и названии.
    """
    supports = SupportMeasure.objects.all()
    recommended = []

    for support in supports:
        if support.min_trust > 0:
            availability = min(user.trust / support.min_trust * 100, 100)
        else:
            availability = 100

        if availability > 0:
            recommended.append({
                "support_name": support.name,
                "support_id": support.id,
                "availability": round(availability, 2)
            })

    return recommended