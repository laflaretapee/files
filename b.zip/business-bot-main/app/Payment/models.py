from django.db import models

class YookassaPayment(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Ожидает оплаты'),
        ('succeeded', 'Успешно'),
        ('canceled', 'Отменен'),
    ]

    payment_id = models.CharField("ID платежа", max_length=255, unique=True)
    user_id = models.CharField("ID пользователя", max_length=255)
    measure_id = models.CharField("ID измерения", max_length=255)
    amount = models.DecimalField("Сумма", max_digits=10, decimal_places=2)
    currency = models.CharField("Валюта", max_length=3, default='RUB')
    description = models.TextField("Описание")
    status = models.CharField("Статус", max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField("Создан", auto_now_add=True)
    updated_at = models.DateTimeField("Обновлен", auto_now=True)

    class Meta:
        verbose_name = "Платеж"  # Название в единственном числе
        verbose_name_plural = "Платежи"  # Название во множественном числе

    def __str__(self):
        return f"Платеж {self.payment_id}"