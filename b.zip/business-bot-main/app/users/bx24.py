import os
import json
import logging

from requests_.utils import remove_emojis

from users.utils import AsyncHttpRequestor


headers = {"Content-Type": "application/json"}
headers_tg = {"token": os.getenv("TELEGRAM_TOKEN")}

database_obj = AsyncHttpRequestor(os.getenv("BASE_URL"))

obj = AsyncHttpRequestor(
    f"https://{os.getenv('WEBHOOK_URL')}.bitrix24.ru/rest/{os.getenv('BX_USER_ID')}/{os.getenv('WEBHOOK_KEY')}/"
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


async def bx24_create_company(title, inn, category, update_data=None):

    data = {
        "ID": update_data if update_data else "",
        "FIELDS": {
            "OPENED": "Y",
            "ASSIGNED_BY_ID": os.getenv("BX_USER_ID"),
            "TITLE": title,
            "UF_CRM_INN": inn,
            "UF_CRM_TYPECMP": category,
        }
    }
    method = "crm.company.add"
    if update_data is not None:
        method = "crm.company.update"
    
    data = json.dumps(data)
    response = await obj.make("post", method, body=data, headers=headers)
    return response if update_data is None else {"result": update_data}


async def bx24_create_contact(
    company_id,
    username,
    name,
    last_name,
    second_name,
    phone,
    email,
    role,
    connection,
    update_data=None,
):

    data = {
        "ID": update_data if update_data else "",
        "FIELDS": {
            "NAME": name,
            "SECOND_NAME": second_name,
            "LAST_NAME": last_name,
            "POST": role,
            "COMPANY_ID": company_id,
            "UF_CRM_TGID": username,
            "COMMENTS": connection,
            "PHONE": [{"VALUE": f"+{phone}", "VALUE_TYPE": "WORK"}],
            "EMAIL": [{"VALUE": email, "VALUE_TYPE": "MAILING"}],
        },
    }

    method = "crm.contact.add"
    if update_data is not None:
        method = "crm.contact.update"

    data = json.dumps(data)
    response = await obj.make("post", method, body=data, headers=headers)
    return response if update_data is None else {"result": update_data}


async def bx24_create_deal(title, category, vacuum, company_id, contact_id, additional=None):

    category_ = remove_emojis(category)
    title_ = remove_emojis(title)

    data = {
        "FIELDS": {
            "TITLE": title_,
            "TYPE_ID": "COMPLEX",
            "UF_CRM_CATEGORY": category_,
            "CATEGORY_ID": vacuum,
            "COMPANY_ID": company_id,
            "CONTACT_IDS": [contact_id],
        }
    }

    data["FIELDS"].update(additional if additional else {})
    method = "crm.deal.add"

    data = json.dumps(data)
    response = await obj.make("post", method, body=data, headers=headers)
    return response


async def bx24_create_or_update_company(data: dict):

    company_id = data["bx24_company_id"]
    company = await bx24_create_company(
        data["title"], data["inn"], data["category"], company_id
    )
    if company.get("error", None) is not None:
        return -1
    return company["result"]


async def bx24_create_or_update_contact(data):

    contact_id = data["bx24_contact_id"]
    company_id = data["bx24_company_id"]
    contact = await bx24_create_contact(
        company_id,
        data["username"],
        data["name"],
        data["last_name"],
        data["second_name"],
        data["phone"],
        data["email"],
        data["role"],
        data["connection"],
        contact_id,
    )
    if contact.get("error", None) is not None:
        return -1
    return contact["result"]


async def bx24_request(user, category, title, vacuum=0, additional=None):

    if not isinstance(user, dict):
        headers_tg.update({"username": str(user.username)})
        response = await database_obj.make("get", "users/profile/", headers=headers_tg)
        if response["error"]:
            return -1
        user = response["data"]

    last_name, name, second_name = user["full_name"].split(" ")
    user.update({"second_name": second_name, "name": name, "last_name": last_name})

    company_id = user["company"]["bx24_company_id"]
    contact_id = user["bx24_contact_id"]
    deal = await bx24_create_deal(title, category, vacuum, company_id, contact_id, additional)
    if deal.get("error", None) is not None:
        return -1
    return deal
