import os
from asgiref.sync import async_to_sync

from django.contrib import admin
from django.forms import ValidationError

from requests_.utils import send_telegram_message

from users.models import TelegramUser, Company
from users.forms import TelegramUserAdminForm


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):

    empty_value_display = "---"
    readonly_fields = ["inn", "created_at"]

    list_display = [
        "title",
        "inn",
        "category",
        "trust",
        "bx24_company_id",
        "created_at",
    ]

    fieldsets = [
        (
            "Основная информация",
            {
                "fields": [
                    "inn",
                    "created_at",
                    "title",
                    "category",
                    "trust",
                    "bx24_company_id",
                ]
            },
        ),
    ]

    def has_delete_permission(self, request, obj=None):
        return True

    def has_add_permission(self, request):
        return False


@admin.register(TelegramUser)
class TelegramUserAdmin(admin.ModelAdmin):

    empty_value_display = "---"
    form = TelegramUserAdminForm
    readonly_fields = ["username"]

    list_display = [
        "username_desc",
        "full_name",
        "role",
        "company",
        "bx24_contact_id",
        "phone",
        "email",
        "email_verified",
        "is_staff",
        "date_joined",
    ]

    fieldsets = [
        (
            "Основная информация",
            {
                "fields": [
                    "username",
                    "full_name",
                    "company",
                ]
            },
        ),
        (
            "Дополнительная информация",
            {
                "fields": [
                    "role",
                    "bx24_contact_id",
                ]
            },
        ),
        (
            "Связь",
            {
                "fields": [
                    "connection",
                    "phone",
                    "email",
                ]
            },
        ),
        (
            "Разрешения",
            {
                "fields": [
                    "groups",
                    "new_password",
                    "is_staff",
                    "is_superuser",
                ]
            },
        ),
    ]

    def has_delete_permission(self, request, obj=None):
        return True

    def has_add_permission(self, request):
        return False

    def username_desc(self, obj):
        return obj.username
    username_desc.short_description = "Телеграм ID"

    def save_model(self, request, obj, form, change):
        if not change:
            super().save_model(request, obj, form, change)
            return

        original_obj = TelegramUser.objects.get(pk=obj.pk)
        changes = []
        
        # Получаем пароль из формы, если он был изменен
        raw_password = form.cleaned_data.get('new_password')

        # Проверяем изменение email
        if original_obj.email != obj.email:
            changes.append(f"email изменен с {original_obj.email or 'не указан'} на {obj.email or 'не указан'}")

        # Проверяем изменения статусов
        is_status_changed = (
            original_obj.is_staff != obj.is_staff
            or original_obj.is_superuser != obj.is_superuser
            or original_obj.is_active != obj.is_active
        )
        
        # Проверяем становится ли пользователь персоналом или суперпользователем
        becoming_staff_or_superuser = (not original_obj.is_staff and obj.is_staff) or (not original_obj.is_superuser and obj.is_superuser)
        
        # Проверка на наличие пароля только если пользователь становится персоналом или администратором
        if becoming_staff_or_superuser:
            if not obj.has_usable_password() and not raw_password:
                raise ValidationError(
                    "Для назначения пользователя персоналом или администратором необходимо установить пароль."
                )
        
        # Записываем изменения статусов
        if original_obj.is_staff != obj.is_staff:
            status = (
                "◀️добавлен в персонал" if obj.is_staff else "◀️ удален из персонала"
            )
            changes.append(status)
        if original_obj.is_superuser != obj.is_superuser:
            status = (
                "◀️ назначен администратором"
                if obj.is_superuser
                else "◀️ снят с роли администратора"
            )
            changes.append(status)
        if original_obj.is_active != obj.is_active:
            status = (
                "◀️ профиль активирован" if obj.is_active else "◀️ профиль деактивирован"
            )
            changes.append(status)

        # Устанавливаем пароль, если он предоставлен
        if raw_password:
            obj.set_password(raw_password)
            obj._raw_password = raw_password  # Для отправки пользователю
            changes.append("◀️ пароль был изменен")

        super().save_model(request, obj, form, change)

        if changes:
            changes_str = '\n'.join(changes)
            user_message = changes_str
            
            # Если пароль был изменен, отправляем его пользователю
            if raw_password:
                user_message += \
                    f"\n\nЛогин: {original_obj.username}"\
                    f"\nПароль: {raw_password}"\
                    f"\nАдминка: {os.getenv('BASE_URL')}admin/"
                user_message
            
            async_to_sync(send_telegram_message)(
                users=[obj],
                message=user_message,
                title="⚠️ Изменение данных пользователя",
            )