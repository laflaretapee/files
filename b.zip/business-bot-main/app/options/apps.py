from django.apps import AppConfig


class OptionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'options'
    verbose_name="Настройки бота"
