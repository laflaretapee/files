import asyncio
from httpx import head
from app.users.utils import AsyncHttpRequestor

obj = AsyncHttpRequestor("http://127.0.0.1:8000/")

headers = {
    "token": "7244957309:AAHZrvVSKJBINbT5-qSesz46MVroUwVxXsY",
}

body = {
    "object":{
        "id":"2f6df021-000f-5000-b000-147355875d72",
        "status":"succeeded",
    }
}

import json
body = json.dumps(body)
asyncio.run(obj.make("post", "yookassa-webhook/", headers=headers, body=body))