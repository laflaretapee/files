from django import forms

from supports.models import SupportMeasure, SupportMeasureCategory

class SupportMeasureAdminForm(forms.ModelForm):
    """
    Модель формы для создания меры поддержки из админки.
    Добавлена обработка платных мер и цены.
    """

    price = forms.DecimalField(
        required=False,
        label="Стоимость",
        min_value=0.00,
        max_digits=10,
        decimal_places=2,
        help_text="Обязательно для платных мер. Введите сумму в рублях.",
        widget=forms.NumberInput(attrs={'step': '0.01'})
    )

    class Meta:
        model = SupportMeasure
        fields = "__all__"
        exclude = ['min_trust']

    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instance')
        if instance:
            initial = kwargs.get('initial', {})
            initial['price'] = instance.price
            kwargs['initial'] = initial
        super().__init__(*args, **kwargs)


    def save(self, commit=True):
        instance = super().save(commit=False)
        if instance.price == 0.00 and instance.item:
            instance.item = ""
        if instance.category_id == None:
            instance.category_id = SupportMeasureCategory().get_default_category()
        if commit:
            instance.save()
        return instance
    