from filters_.models import Area, MoneyAmountFilter
from options.models import Option
from supports.models import SupportMeasure, SupportMeasureCategory


def get_nested_categories(parent=None):
    """
    Рекурсивная функция для получения всех категорий с вложенными подкатегориями
    и мерами поддержки.
    """
    try:
        categories = SupportMeasureCategory.objects.filter(parent=parent).exclude(
            name="Без категории"
        )
        result = []
        opt1 = Option.objects.filter(category="modules_id").first()
        opt2 = Option.objects.filter(category="finances_id").first()
        opt3 = Option.objects.filter(category="parties_id").first()
        opt4 = Option.objects.filter(category="loyalty_id").first()

        for category in categories:
            try:
                # Получаем меры поддержки для текущей категории
                measures = SupportMeasure.objects.filter(category=category, visible=True)
                measures_data = [
                    {
                        "measure_id": measure.id,
                        "measure_name": measure.name,
                        "measure_descr": measure.description,
                        "min_trust": measure.min_trust,
                        "price": measure.price,
                        "area_id": measure.area.id if measure.area else Area.get_default_area(),
                        "money_id": measure.money.id if measure.money else MoneyAmountFilter.get_default_money_filter(),
                        "additional_url": measure.additional_url,
                    }
                    for measure in measures
                ]

                # Собираем данные о категории
                category_data = {
                    "category_name": category.name,
                    "category_id": category.id,
                    "category_descr": category.description,
                    "parent_id": category.parent.id if category.parent else None,
                    "children": get_nested_categories(category),
                    "measures": measures_data,
                }

                category_data.update({"for_modules": True}) if opt1 and int(opt1.value) == category.id else ...
                category_data.update({"for_finances": True}) if opt2 and int(opt2.value) == category.id else ...
                category_data.update({"for_parties": True}) if opt3 and int(opt3.value) == category.id else ...
                category_data.update({"for_loyalties": True}) if opt4 and int(opt4.value) == category.id else ...


                result.append(category_data)
            except Exception as e:
                print(f"Error processing category {category.id}: {str(e)}")
                continue

        return result
    except Exception as e:
        print(f"Error in get_nested_categories: {str(e)}")
        return []
    
def get_measures_list(measures: list):
    return [
        {
            "measure_id": measure.id,
            "measure_name": measure.name,
            "measure_descr": measure.description,
            "min_trust": measure.min_trust,
            "price": measure.price,
            "area_id": measure.area.id if measure.area else Area.get_default_area(),
            "money_id": measure.money.id if measure.money else MoneyAmountFilter.get_default_money_filter(),
            "additional_url": measure.additional_url,
        }
        for measure in measures
    ]