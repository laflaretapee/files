from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from filters_.models import DirectionsFilter, MoneyAmountFilter, Area

class SupportMeasureCategory(models.Model):
    """
    Категория мер поддержки. Содержит название категории.
    """

    parent = models.ForeignKey(
        verbose_name="Родительская категория",
        to="self",
        blank=True,
        null=True,
        related_name="children",
        on_delete=models.CASCADE,
    )
    name = models.CharField(
        verbose_name="Название категории", max_length=128, unique=True
    )
    description = models.TextField(verbose_name="Описание категории", blank=True)

    @classmethod
    def get_default_category(cls):
        obj, _ = SupportMeasureCategory.objects.get_or_create(name="Без категории")
        return obj.id

    def __str__(self):
        return self.name

    class Meta:
        db_table = "support_measure_categories"
        verbose_name = "Категория"
        verbose_name_plural = "Категории"


class SupportMeasure(models.Model):
    """
    Мера поддержки. Каждая мера поддержки связана с определенной категорией.
    Содержит название, категорию, описание, минимальный уровень надежности компании
    и признак платности меры.
    """

    image = models.ImageField(
        verbose_name="Изображение", 
        blank=True, 
        null=True, 
        upload_to="supports/"
    )
    gratitude = models.TextField(
        verbose_name="Благодарность за приобретение", 
        blank=True, 
        null=True,
        help_text="Благодарственное сообщение, которое будет показано клиенту после оставления заявки или приобретения меры."
    )
    name = models.CharField(
        verbose_name="Название меры", 
        max_length=128, 
        unique=True
    )
    money = models.ForeignKey(
        to=MoneyAmountFilter,
        verbose_name="Денежный регулятор",
        on_delete=models.SET_DEFAULT,
        default=MoneyAmountFilter.get_default_money_filter,
        blank=True,
        null=True
    )
    visible = models.BooleanField(
        verbose_name="Видна ли мера",
        default=True
    )
    additional_url = models.URLField(
        verbose_name="Ссылка для раздела финансирование бизнеса",
        blank=True,
        null=True
    )
    category = models.ForeignKey(
        to=SupportMeasureCategory,
        verbose_name="Категория",
        on_delete=models.SET_DEFAULT,
        default=SupportMeasureCategory.get_default_category,
        blank=True,
    )
    area = models.ForeignKey(
        to=Area,
        verbose_name="Регулятор по сфере",
        on_delete=models.SET_DEFAULT,
        default=Area.get_default_area,
        blank=True,
        null=True
    )
    direction = models.ForeignKey(
        to=DirectionsFilter,
        verbose_name="Направление",
        on_delete=models.SET_DEFAULT,
        default=DirectionsFilter.get_default_direction,
        blank=True,
        null=True
    )
    description = models.TextField(verbose_name="Описание меры")
    min_trust = models.DecimalField(
        verbose_name="Уровень надежности",
        max_digits=5,
        decimal_places=2,
        default=0.00,
        validators=[
            MaxValueValidator(100.00),
            MinValueValidator(0.00)
        ]
    )
    price = models.DecimalField(
        verbose_name="Стоимость",
        max_digits=10,
        decimal_places=2,
        default=0.00,
        validators=[MinValueValidator(0.00)],
        help_text="Цена для платных мер поддержки. Укажите 0, если мера бесплатная.",
    )
    item = models.TextField(
        verbose_name="Ссылка на курс/меру/товар",
        blank=True,
        null=True,
        help_text="Можно указать для платных мер поддержки. Представляет из себя информацию, которая будет выслана на почту клиента после подтверждения оплаты.",
    )
    action = models.CharField(
        verbose_name="Действие",
        max_length=128,
        blank=True,
        null=True,
        help_text="Описание действия, которое осуществляет клиент. Полезно для наглядности при отправки сообщений в общий чат админов. Например если мера поддержки представляет из себя мероприятие, то здесь можно написать «оставил заявку на участие» (если мера бесплатная) или «хочет приобрести билет» (если мера платная) и т.д.",
    )
    
    def save(self, *args, **kwargs):
        try:
            if float(self.price) < 0:
                self.price = 0.00
        except Exception:
            self.price = 0.00
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "support_measures"
        verbose_name = "Мера поддержки"
        verbose_name_plural = "Меры поддержки"
