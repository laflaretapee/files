from django.contrib import admin
from django.utils.html import format_html

from supports.models import SupportMeasure, SupportMeasureCategory
from supports.forms import SupportMeasureAdminForm


@admin.register(SupportMeasure)
class SupportMeasureAdmin(admin.ModelAdmin):
    list_display = [
        "id",
        "name",
        "image_edited",
        "category",
        "price_display",
        "short_description",
        "visible",
        "area",
        "direction",
        "money",
    ]
    list_filter = [
        "category", 
    ]
    list_display_links = ["name"]
    search_fields = ("name", "description")
    form = SupportMeasureAdminForm
    actions = ["make_visible", "make_invisible"]

    fieldsets = (
        (
            "Основные данные",
            {
                "fields": (
                    "image",
                    "name",
                    "category",
                    "description",
                    "visible",
                ),
            },
        ),
        (
            "Модули обучения, мероприятия, программы лояльности",
            {
                "fields": (
                    "direction",
                    "item",
                    "price",
                    "action",
                    "gratitude",
                ),
            },
        ),
        (
            "Финансирование бизнеса",
            {
                "fields": (
                    "money",
                    "area",
                    "additional_url",
                ),
            },
        ),
    )

    @admin.action(description="Пометить как видимые")
    def make_visible(self, request, queryset):
        queryset.update(visible=True)
        self.message_user(request, "Объекты помечены как видимые")
    
    @admin.action(description="Пометить как невидимые")
    def make_invisible(self, request, queryset):
        queryset.update(visible=False)
        self.message_user(request, "Объекты помечены как невидимые")

    def short_description(self, obj):
        return self._truncate_text(obj.description)
    short_description.short_description = "Описание"

    def price_display(self, obj):
        if float(obj.price) > 0:
            return f"{obj.price}₽"
        return "Бесплатно"
    price_display.short_description = "Стоимость"
    price_display.admin_order_field = 'price'

    def image_edited(self, obj):
        if not obj.image:
            return "отсутствует"
        return format_html(f'<img src="{obj.image.url}" width="144" height="96" style="overflow: hidden;object-fit: cover;"/>')
    image_edited.short_description = "Изображение"

    def _truncate_text(self, text, length=50):
        if len(text) > length:
            return f"{text[:length]}..."
        return text


@admin.register(SupportMeasureCategory)
class SupportMeasureCategoryAdmin(admin.ModelAdmin):

    list_display = [
        "id",
        "name",
        "parent",
        "description",
    ]

    search_fields = ("name", "description")
    list_display_links = ["name"]

    def description(self, obj):
        return self._truncate_text(obj.description)
    description.short_description = "Описание"

    def _truncate_text(self, text, length=50):
        if len(text) > length:
            return f"{text[:length]}..."
        return text
