import os
import logging

from asgiref.sync import sync_to_async, async_to_sync

from django.http import HttpRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt

from supports.utils import get_measures_list, get_nested_categories
from users.bx24 import bx24_request
from users.decorators import only_post
from users.models import TelegramUser

from filters_.models import Area, DirectionsFilter, MoneyAmountFilter
from supports.models import SupportMeasure, SupportMeasureCategory

from options.models import Option

from requests_.models import SupportRequest
from requests_.utils import validate_telegram_token


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


@csrf_exempt
@sync_to_async
@validate_telegram_token
@only_post
def take_support_view(request: HttpRequest):
    username = request.POST.get("username")
    support_id = request.POST.get("support_id")
    title = request.POST.get("title")

    if not all([username, support_id]):
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"}, status=400
        )

    try:
        user = TelegramUser.objects.get(username=username)
        support = SupportMeasure.objects.get(id=support_id)
        paid = (
            {"CURRENCY": "RUB", "OPPORTUNITY": float(support.price)}
            if support.price > 0.00
            else None
        )

        # Проверка существующих заявок
        try:
            request = SupportRequest.objects.get(
                user=user, 
                support=support, 
                is_resolved=False, 
                support__price=0.00
            )
            return JsonResponse({
                "error": True,
                "message": "Вы уже подали заявку на данную меру поддержки!"
            }, status=400)
        except SupportRequest.DoesNotExist:
            pass

        # Инициализация result перед использованием
        result = None  # <-- Важное исправление
        
        if not paid:
            result = async_to_sync(bx24_request)(
                user, 
                support.category.name, 
                support.name, 
                os.getenv("VACUUM")
            )
            if result == -1:
                logging.error("Ошибка при создании сделки в Битрикс24!")

        msg = (
            f'Клиент <a href="tg://user?id={user.username}">{user.full_name}</a> из '
            f'<i><b>«{user.company.title if user.company else "компания не найдена"}»</b></i> '
            f'{"интересуется" if not support.action else support.action} '
            f'<i><b>«{support.name}»</b></i> из категории <i><b>«{support.category}»</b></i>.\n\n'
            f"☎️ Телефон: <a href='tel:{user.phone}'>+{user.phone}</a>\n"
            f"✉️ Email: <a href='mailto:{user.email}'>{user.email}</a>."
        )

        request = SupportRequest.objects.create(
            user=user, 
            title=title, 
            message=msg, 
            support=support
        )

        return JsonResponse({
            "error": False,
            "message": msg,
            "gratitude": support.gratitude,
            "data":{
                "request_id": request.id,
            }
        }, status=201)

    except Exception as e:
        logging.error(f"Ошибка при создании заявки: {str(e)}")
        return JsonResponse({
            "error": True, 
            "message": f"Ошибка при создании заявки: {str(e)}"
        }, status=500)


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_support_view(request: HttpRequest):

    id_ = request.GET.get("id")
    if not id_:
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"}, status=400
        )

    try:
        support = SupportMeasure.objects.get(id=id_, visible=True)
        image_url = None
        pseudo_url = support.image

        support_category_id = support.category.id if support.category else SupportMeasureCategory.get_default_category()

        opt = Option.objects.get(category="finances_id")

        if pseudo_url and os.path.exists(pseudo_url.path):
            image_url = support.image.path

        return JsonResponse(
            {
                "error": False,
                "message": "Мера поддержки успешно получена",
                "data": {
                    "name": support.name,
                    "id": support.id,
                    "min_trust": support.min_trust,
                    "category": support.category.name,
                    "category_id": support_category_id,
                    "descr": support.description,
                    "price": support.price,
                    "image_url": image_url,
                    "area_id": support.area.id if support.area else Area.get_default_area(),
                    "money_id": support.money.id if support.money else MoneyAmountFilter.get_default_money_filter(),
                    "additional_url": support.additional_url,
                    "finances": int(support_category_id) == int(opt.value)
                },
            },
            status=200,
        )
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при получении меры. " + str(e)},
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_support_by_area_view(request):
    """
    Возвращает все меры поддержки по заданной категории.
    """
    area_id = request.GET.get("area_id")
    price_id = request.GET.get("price_id")
    if not all ([area_id, price_id]):
        return JsonResponse(
            {"error": True, "message": "Не указаны обязательные параметры"}, status=400
        )
    try:
        area = Area.objects.get(id=area_id)
        money = MoneyAmountFilter.objects.get(id=price_id)
        measures = SupportMeasure.objects.filter(area=area_id, money=price_id, visible=True)
        data = [
            {
                "measure_id": measure.id,
                "measure_name": measure.name,
                "category_id": measure.category.id if  measure.category else SupportMeasureCategory.get_default_category(),
                "category_name": measure.category.name if measure.category else "Без категории",
                "measure_descr": measure.description,
                "min_trust": measure.min_trust,
                "price": measure.price,
                "area_id": measure.area.id if measure.area else Area.get_default_area(),
                "area_name": measure.area.name if measure.area else "Без сферы",
                "money_id": measure.money.id if measure.money else MoneyAmountFilter.get_default_money_filter(),
                "money_value": str(measure.money),
                "direction_id": measure.direction.id if measure.direction else DirectionsFilter.get_default_direction(),
                "direction_name": measure.direction.name if measure.direction else "Без направления",
                "additional_url": measure.additional_url,
            }
            for measure in measures
        ]

        if not data:
            raise ValueError("Меры не найдены!")

        return JsonResponse(
            {
                "error": False,
                "message": "Меры поддержки успешно получены",
                "area_name": area.name,
                "money_name": str(money),
                "data": data,
            },
            status=200,
        )
    except Exception as e:
        return JsonResponse(
            {
                "error": True,
                "message": "Ошибка при получении мер по сфере. " + str(e),
            },
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_support_by_category_view(request):
    """
    Возвращает все меры поддержки по заданной категории.
    """
    category_id = request.GET.get("id")
    if not category_id:
        return JsonResponse(
            {"error": True, "message": "Не указан идентификатор категории"}, status=400
        )
    try:
        category = SupportMeasureCategory.objects.get(id=category_id)
        measures = SupportMeasure.objects.filter(category=category_id,visible=True)
        data = [
            {
                "measure_id": measure.id,
                "measure_name": measure.name,
                "measure_descr": measure.description,
                "min_trust": measure.min_trust,
                "price": measure.price,
                "area_id": measure.area.id if measure.area else Area.get_default_area(),
                "money_id": measure.money.id if measure.money else MoneyAmountFilter.get_default_money_filter(),
                "additional_url": measure.additional_url,
            }
            for measure in measures
        ]

        return JsonResponse(
            {
                "error": False,
                "message": "Меры поддержки успешно получены",
                "category_name": category.name,
                "category_description": category.description,
                "data": data,
            },
            status=200,
        )
    except Exception as e:
        return JsonResponse(
            {
                "error": True,
                "message": "Ошибка при получении мер по категории. " + str(e),
            },
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_categories_view(request):
    """Возвращает все категории в виде вложенного словаря вместе с мерами поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    Опционально можно передать category_id для получения конкретной категории.
    """
    category_id = request.GET.get("category_id")

    data = {
        "category_name": "",
        "category_id": "",
        "category_descr": "",
        "parent_id": None,
        "children": [],
        "measures": [],
    }

    try:
        if category_id:
            category = SupportMeasureCategory.objects.get(id=category_id)
            measures = SupportMeasure.objects.filter(category=category, visible=True)

            measures = get_measures_list(measures)
            subcategories = get_nested_categories(parent=category)

            data["children"].extend(subcategories)  
            data["measures"].extend(measures)
            data["category_name"] = category.name
            data["category_id"] = category.id
            data["category_descr"] = category.description

            if category.parent:
                data["parent_id"] = category.parent.id

        else:
            subcategories = get_nested_categories(None)
            data["children"].extend(subcategories)

        if not any((data["children"], data["measures"])):
            raise ValueError(
                "В данной категории отсутствуют подкатегории и меры поддержики. "+
                "Возможно текущая категория находится в разработке..."
            )

        return JsonResponse(
            {
                "error": False, 
                "message": "Категории успешно получены", 
                "data": data
            },
            status=200,
        )

    except SupportMeasureCategory.DoesNotExist:
        return JsonResponse(
            {"error": True, "message": "Категория не найдена"}, status=404
        )
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"{str(e)}"},
            status=500,
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_areas_view(request):
    """
    Возвращает все категории в виде вложенного словаря вместе с мерами поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    Опционально можно передать category_id для получения конкретной категории.
    """
    try:
        areas = Area.objects.all().exclude(name="Без сферы")

        data = [
            {
                "area_id": area.id,
                "title": area.name,
                "measures": [
                    {
                        "measure_id": measure.id, 
                        "measure_name": measure.name, 
                        "additional_url": measure.additional_url,
                    } for measure in SupportMeasure.objects.filter(area=area.id,visible=True)],
            }
            for area in areas
        ]

        if not data:
            raise ValueError("Сферы не найдены!")

        return JsonResponse(
            {"error": False, "message": "Сферы успешно получены", "data": data},
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"Ошибка при получении сфер: {str(e)}"},
            status=500,
        )
