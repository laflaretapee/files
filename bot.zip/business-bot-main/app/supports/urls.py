from django.urls import path

from . import views

app_name= "supports"

urlpatterns = [
    path("take-support/", views.take_support_view, name="take-support"),
    path("get-support/", views.get_support_view, name="get-support"),

    path("get-supports-by-category/", views.get_support_by_category_view, name="get-supports-by-category"),
    path("get-supports-by-area/", views.get_support_by_area_view, name="get-supports-by-area"),

    path("categories/", views.get_categories_view, name="categories"),

    path("areas/", views.get_areas_view, name="get_areas"),
]
