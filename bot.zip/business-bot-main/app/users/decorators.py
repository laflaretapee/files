from functools import wraps

from django.http import JsonResponse

def only_post(func):
    """
    Декоратор для проверки метода запроса.
    """
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        if request.method != "POST":
            return JsonResponse(
                {"error": True, "message": "only POST method allowed"}
            )
        return func(request, *args, **kwargs)
    return wrapper


def async_only_post(func):
    """
    Декоратор для проверки метода запроса.
    """
    @wraps(func)
    async def wrapper(request, *args, **kwargs):
        if request.method != "POST":
            return JsonResponse(
                {"error": True, "message": "Метод запроса должен быть POST"}
            )
        return await func(request, *args, **kwargs)
    return wrapper
