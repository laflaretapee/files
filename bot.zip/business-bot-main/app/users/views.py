import os

from asgiref.sync import sync_to_async

from django.http import HttpRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.http import urlsafe_base64_decode
from django.shortcuts import get_object_or_404, render
from django.utils.html import format_html

from users.decorators import only_post
from users.email import send_verification_email, email_verification_token
from users.models import TelegramUser, Company

from requests_.utils import validate_telegram_token


def verify_email_view(request, uidb64, token):
    """
    Представление для проверки подтверждения электронной почты пользователем.
    После перехода по ссылке, ему будет отображен соответствущий ответ в виде HTML-страницы
    с последующим перенаправлением на бота.
    """
    bot_url_app = os.getenv("BOT_URL_APP")
    context = {
        "bot_url_app": bot_url_app,
    }
    
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = get_object_or_404(TelegramUser, pk=uid)
        if user.email_verified:
            context["error"] = True
            context["message"] = "Email уже подтверждён"
            return render(request, "verify_email.html", context)
    except (TypeError, ValueError, OverflowError, TelegramUser.DoesNotExist) as e:
        context["error"] = True
        context["message"] = "Неверная или устаревшая ссылка подтверждения. " + str(e)
        return render(request, "verify_email.html", context)
        
    if email_verification_token.check_token(user, token):
        user.email_verified = True
        user.save()
        context["error"] = False
        context["message"] = format_html("Email успешно подтверждён! Можете вернуться в <a href='https://t.me/bizness_help_bot'>телеграм бота для завершения регистрации! (Ссылка)</a>")
        return render(request, "verify_email.html", context)
    else:
        context["error"] = True
        context["message"] = "Неверная или устаревшая ссылка подтверждения"
        return render(request, "verify_email.html", context)


@csrf_exempt
@sync_to_async
@validate_telegram_token
@only_post
def create_user_view(request: HttpRequest):
    """
    Представление для создания пользователя.

    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN). В теле запроса передаём
    telegram id пользователя (username: telegram_id), ФИО (full_name: full_name), телефон
    phone (phone:phone) и почту (email: email). После добавления в БД пользователь получает
    письмо на указанную почту для её подтверждения.

    Возвращает JSON ответ где под ключом "error" указывается True, если произошла ошибка,
    иначе False. Под ключом "message" указывается текст результата запроса.
    """

    username = request.POST.get("username")
    full_name = request.POST.get("full_name")
    title = request.POST.get("title")
    role = request.POST.get("role")
    phone = request.POST.get("phone")
    email = request.POST.get("email", "")
    inn = request.POST.get("inn")
    type_ = request.POST.get("type")
    address = request.POST.get("address")
    connection = request.POST.get("connection")

    if not username:
        return JsonResponse(
            {
                "error": True,
                "message": "Переданы не все данные для регистрации пользователя!",
            },
            status=400,
        )

    try:
        company = None
        if inn:
            company, _ = Company.objects.get_or_create(
                inn=inn,
                defaults={
                    "title": title,
                    "category": type_,
                    "address": address,
                }
            )
        user, _ = TelegramUser.objects.update_or_create(
            username=username,
            defaults={
                "role": role,
                "company": company,
                "connection": connection,
                "full_name": full_name,
                "phone": phone,
                "email": email,
            },
        )
        try:
            if email:
                msg = send_verification_email(user, request, email)
                if not msg:
                    raise ValueError("Не получилось отправить письмо на указанный адрес!")
        except Exception as e:
            return JsonResponse(
                {
                    "error": True,
                    "message": "Ошибка при отправке письма. "
                    + str(e),
                },
                status=500,
            )

        return JsonResponse(
            {
                "error": False,
                "message": "Аккаунт создан",
                "data": user.get_full_information(),
            },
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {
                "error": True,
                "message": "Ошибка при регистрации пользователя. " + str(e),
            },
            status=500,
        )


@csrf_exempt
@sync_to_async
@validate_telegram_token
@only_post
def send_verification_email_view(request: HttpRequest):
    """
    Представление для отправки письма на почту пользователя.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN) и username.

    Возвращает JSON ответ где под ключом "error" указывается True, если произошла ошибка,
    иначе False. Под ключом "message" указывается текст результата запроса.
    """
    username = request.headers.get("username")
    if not username:
        return JsonResponse(
            {
                "error": True,
                "message": "Переданы не все данные для отправки письма",
            },
            status=400,
        )

    try:
        user = TelegramUser.objects.get(username=username)
        if not send_verification_email(user, request, user.email):
            raise ValueError("Не получилось отправить письмо на указанный адрес!")

        return JsonResponse(
            {
                "error": False,
                "message": "Письмо отправлено",
            },
            status=200,
        )
    
    except Exception as e:
            return JsonResponse(
                {
                    "error": True,
                    "message": "Ошибка при отправке письма. "
                    + str(e),
                },
                status=500,
            )

@csrf_exempt
@sync_to_async
@validate_telegram_token
def profile_user_view(request: HttpRequest):
    """
    Представление для получения профиля пользователя.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN) и username.

    Возвращает JSON ответ где под ключом "error" указывается True, если произошла ошибка,
    иначе False. Под ключом "message" указывается текст результата запроса.

    """

    username = request.headers.get("username")
    try:
        user = TelegramUser.objects.get(username=username)
        return JsonResponse(
            {
                "error": False,
                "message": "Профиль пользователя",
                "data": user.get_full_information(),
            },
            status=200,
        )
    except TelegramUser.DoesNotExist:
        return JsonResponse(
            {
                "error": True, 
                "message": "Пользователь с таким именем не найден"
            },
            status=404,
        )
