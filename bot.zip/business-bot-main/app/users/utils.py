import aiohttp
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

class AsyncHttpRequestor:
    """Класс для осуществления асинхронных HTTP-запросов"""

    def __init__(self, url):
        """
        При создании объекта нужно передать базовый URL домена
        """
        self.url = url
        self.method = None

    def get_url(self, action):
        return self.url + action

    async def __resolve_method(self, method, session):
        """
        Проверка того, какой метод должен быть использован
        """
        if method not in ["get", "post"]:
            raise ValueError("Invalid method name")
        match method:
            case "post":
                self.method = session.post
            case "get":
                self.method = session.get

    async def make(self, method, action, *, body=None, headers=None, params=None):
        """
        Функция непосредственно осуществляющая запросы.

        method - метод запроса 'post' или 'get'
        action - непосредственно часть url от базового домена по которой осуществляется запрос
        body - тело запроса
        headers - заголовки
        params - query параметры
        """
        try:
            async with aiohttp.ClientSession() as session:
                await self.__resolve_method(method, session)
                logger.debug("{0} [{1}]\n".format(method, self.get_url(action)))
                logger.debug("headers: {0}\n".format(headers))
                logger.debug("body:{0}\n".format(body))
                logger.debug("params: {0}\n".format(params))
                async with self.method(url=(self.url+action), data=body, headers=headers, params=params) as response:
                    resp = await response.json()
                    if not resp.get("ok", True):
                        raise Exception("Ошибка отправки запроса")
                    logger.debug("response: {0}\n".format(resp))
                    return resp
        except Exception as e:
            logger.debug("response: {0}\n".format(e))
            return {"error": True, "message": str(e)}
