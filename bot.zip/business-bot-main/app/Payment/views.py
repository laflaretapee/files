import os
import json
import logging

from asgiref.sync import async_to_sync

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail

from requests_.models import SupportRequest
from requests_.utils import send_telegram_message

from supports.models import SupportMeasure

from options.models import Option

from users.decorators import only_post
from users.models import TelegramUser
from users.bx24 import bx24_request

from Payment.models import YookassaPayment

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


@only_post
@csrf_exempt
def yookassa_webhook(request):
    """
    Вебхук Yookassa
    """

    event_data = json.loads(request.body)
    payment_data = event_data.get("object", {})
    payment_id = payment_data.get("id", None)
    status = payment_data.get("status", None)

    try:
        if not status and status not in ["canceled", "succeeded", "pending"]:
            raise ValueError("Не удалось получить статус платежа!")

        payment = YookassaPayment.objects.get(payment_id=payment_id)
        payment.status = status
        payment.save()

        user_id = payment.user_id
        user = TelegramUser.objects.get(username=payment.user_id)
        support = SupportMeasure.objects.get(id=payment.measure_id)

        match status:
            case "canceled":
                reason = payment_data.get("cancellation_details", {}).get(
                    "reason", "Неизвестно"
                )
                message = (
                    f"❌ <i><b>Платеж отменен!</b></i>\n\n"
                    f"🆔 Идентификатор платежа: {payment_id}\n"
                    f"💰 Сумма: {payment.amount}\n"
                    f"❗ Причина: {reason}"
                )

            case "pending":
                message = (
                    f"⚠️ <i><b>Платеж в обработке...</b></i>\n\n"
                    f"🆔 Идентификатор платежа: {payment_id}\n"
                    f"💰 Сумма: {payment.amount}\n"
                    f"⏳ Пожалуйста, подождите завершения транзакции."
                )

            case "succeeded":

                result = None
                try:
                    if support.item:
                        result = send_mail(
                            f"Покупка {support.name}",
                            f"Здравствуйте, {user.full_name}! Ваш приобретённый товар:\n\n{support.item}.\n\n{support.gratitude}",
                            os.getenv("SMTP_EMAIL"),
                            [user.email],
                        )
                except Exception as e:
                    logger.error(f"ERROR send mail: {e}")

                message = (
                    ("✅ <i><b>Платеж прошёл успешно!</b></i>\n\n" + support.gratitude + "\n\n" if support.gratitude else "") +
                    ("⚠️Внимание! Возникла ошибка при отправке письма на почту! Свяжитесь с техподдержкой и мы всё перепроверим!\n\n" if not result and support.item else "") +
                    f"🆔 Идентификатор платежа: {payment_id}\n" +
                    f"💰 Сумма: {payment.amount}"
                )


                message_to_admins = (
                    f'Клиент <a href="tg://user?id={user.username}">{user.full_name}</a> из <i><b>«{user.company.title if user.company else "компания не найдена"}»</b></i>'
                    f' {"приобрел" if not support.action else support.action} '
                    f"<i><b>«{support.name}»</b></i> из категории <i><b>«{support.category}»</b></i>.\n\n"
                    f"🆔 ИД платежа: {payment_id}\n"
                    f"💰 Сумма: {payment.amount}\n\n"
                    f"☎️ Телефон: <a href='tel:{user.phone}'>+{user.phone}</a>\n"
                    f"✉️ Email: <a href='mailto:{user.email}'>{user.email}</a>."
                )

                try:
                    chat_id = Option.objects.get(category="bot_chat_id")
                    async_to_sync(send_telegram_message)([user], message_to_admins, None, chat_id.value)
                except Exception as e:
                    logger.error(f"{e}")

                SupportRequest.objects.create(
                    user=user,
                    title="Приобретение меры поддержки",
                    message=message,
                    support=support,
                    is_resolved=True,
                )

                paid = {"CURRENCY": "RUB", "OPPORTUNITY": float(payment.amount)}
                result = async_to_sync(bx24_request)(
                    user.get_full_information(),
                    support.name,
                    support.category.name,
                    os.getenv("VACUUM"),
                    paid,
                )

        async_to_sync(send_telegram_message)([user], message)
        return JsonResponse(
            {"error": False, "message": ""}, status=200
        )

    except Exception as e:
        logger.error("Ошибка: {0}".format(e))
        return JsonResponse({"error": False, "message": f"{e}"}, status=500)
