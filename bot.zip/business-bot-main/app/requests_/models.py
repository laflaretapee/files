from django.db import models
from django.utils.timezone import localtime

from users.models import TelegramUser


class Transition(models.Model):

    user = models.ForeignKey(
        to=TelegramUser,
        verbose_name="Пользователь",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    support = models.ForeignKey(
        to="supports.SupportMeasure",
        verbose_name="Мера поддержки",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )

    timestamp = models.DateTimeField(verbose_name="Дата и время", auto_now_add=True)
    url = models.URLField(verbose_name="Ссылка")

    def __str__(self):
        local_datetime = localtime(self.timestamp)
        return f"{self.user} [{local_datetime.strftime('%d.%m.%Y %H:%M')}] {self.url}"

    class Meta:
        db_table = "transitions"
        verbose_name = "Переход по ссылке"
        verbose_name_plural = "Переходы по ссылкам"


class SupportRequest(models.Model):
    """
    Модель заявки от пользователя. Она отправляется администратору.
    Содержит заголовок и сообщение, ссылку на модель пользователя и
    дату отправки.
    """

    user = models.ForeignKey(
        to=TelegramUser, verbose_name="Пользователь", on_delete=models.SET_NULL, null=True
    )
    support = models.ForeignKey(
        to="supports.SupportMeasure",
        verbose_name="Мера поддержки",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    title = models.CharField(verbose_name="Заголовок", max_length=256)
    message = models.TextField(verbose_name="Сообщение")
    date = models.DateTimeField(verbose_name="Дата", auto_now_add=True)
    is_resolved = models.BooleanField(
        verbose_name="Решена",
        default=False,
        help_text="Отметьте, если заявка решена. Пока не помечено, пользователь не может приобрести/оставить заявку для этой меры поддержки.",
    )

    def __str__(self):
        local_datetime = localtime(self.date)
        return f"Заявка {self.user} [{local_datetime.strftime('%d.%m.%Y %H:%M')}]"

    class Meta:
        db_table = "requests"
        verbose_name = "Заявка"
        verbose_name_plural = "Заявки"


class Notification(models.Model):
    """ "
    Модель уведомления. Она отправляется пользователям в телеграм из админки.
    Содержит заголовок и сообщение, ссылку на модель пользователя и
    дату отправки. При её создании нужно выбрать индивидуальных пользователей
    или их группу.
    """

    targets = models.ManyToManyField(
        to=TelegramUser, verbose_name="Пользователи", blank=True
    )
    image = models.ImageField(
        verbose_name="Изображение", 
        blank=True, 
        null=True, 
        upload_to="news/"
    )
    title = models.CharField(verbose_name="Заголовок", max_length=256)
    message = models.TextField(verbose_name="Сообщение")
    date = models.DateTimeField(verbose_name="Дата", auto_now_add=True)

    def __str__(self):
        local_datetime = localtime(self.date)
        return f"Уведомление [{local_datetime.strftime('%d.%m.%Y %H:%M')}]"

    class Meta:
        db_table = "notifications"
        verbose_name = "Новость"
        verbose_name_plural = "Новости"


class Response(models.Model):
    support_request = models.ForeignKey(
        SupportRequest,
        verbose_name="Заявка",
        on_delete=models.CASCADE,
        related_name="responses",
    )
    admin = models.ForeignKey(
        TelegramUser,
        verbose_name="Администратор",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    message = models.TextField(verbose_name="Ответ")
    created_at = models.DateTimeField(verbose_name="Дата ответа", auto_now_add=True)

    class Meta:
        verbose_name = "Ответ на заявку"
        verbose_name_plural = "Ответы на заявки"

    def __str__(self):
        return f"[Ответ] {self.support_request}"
