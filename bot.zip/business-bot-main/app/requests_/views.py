from asgiref.sync import sync_to_async

from django.http import HttpRequest, HttpResponseNotFound, HttpResponseRedirect, JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt

from supports.models import SupportMeasure
from users.decorators import only_post
from users.models import TelegramUser

from requests_.models import SupportRequest, Transition
from requests_.utils import validate_telegram_token


@csrf_exempt
@sync_to_async
@validate_telegram_token
@only_post
def make_help_view(request: HttpRequest):
    """
    Представление для создания заявки в службу поддержки от пользователя.

    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN). В теле запроса передаём
    telegram id пользователя (username: telegram_id) и сообщение (message: message).

    Возвращает JSON ответ где под ключом "error" указывается True, если произошла ошибка,
    иначе False. Под ключом "message" указывается текст результата запроса.
    """

    username = request.POST.get("username")
    message = request.POST.get("message")

    if not all([username, message]):
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"},
            status=400,
        )

    try:
        user = TelegramUser.objects.get(username=username)
        try:
            request = SupportRequest.objects.get(
                user=user,
                support=None,
                is_resolved=False,
            )
            return JsonResponse(
                {
                    "error": True,
                    "message": "Ваша заявка уже находится в обработке! Пожалуйста, сначала дождитесь ответа на неё!",
                    "data": {
                        "request_id": request.id,
                        "full_name": user.full_name,
                    },
                },
                status=400,
            )
        except SupportRequest.DoesNotExist:
            pass

        request = SupportRequest.objects.create(
            user=user, title="Заявка в службу поддержки", message=message
        )
        return JsonResponse(
            {
                "error": False,
                "message": "Заявка отправлена в службу поддержки",
                "data": {
                    "request_id": request.id,
                    "full_name": user.full_name,
                },
            },
            status=202,
        )
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при создании заявки. " + str(e)},
            status=500,
        )


@csrf_exempt
@sync_to_async
def transition_view(request: HttpRequest):

    try:
        support_id = request.GET.get("support_id")
        user_id = request.GET.get("user_id")

        if not all([support_id, user_id]):
            return JsonResponse(
                {"error": True, "message": "Переданы не все данные"},
                status=404,
            )
        
        user = get_object_or_404(TelegramUser, username=user_id)
        support = get_object_or_404(SupportMeasure, id=support_id)
        url = support.additional_url
        Transition.objects.create(user=user, support=support, url=url)
        return HttpResponseRedirect(url)
    except Exception as e:
        return HttpResponseNotFound("Возникла ошибка при переадресации")
