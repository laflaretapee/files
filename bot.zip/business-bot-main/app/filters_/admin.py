from django.contrib import admin, messages
from django.db.models import ProtectedError
from pydantic import ValidationError

from filters_.models import DirectionsFilter, MoneyAmountFilter, Area

# Register your models here.

@admin.register(Area)
class AreaAdmin(admin.ModelAdmin):

    list_display = [
        "id", "name",
    ]
    list_filter = [
        "id", "name",
    ]
    list_display_links = ["name"]
    search_fields = ("name",)

    def delete_model(self, request, obj):
        if obj.id == Area.get_default_area():
            messages.error(request, f"Нельзя удалить базовую сферу [ID = {obj.id}] пока есть относящиеся к ней сущности")
            return
        return super().delete_model(request, obj)
    
    def delete_queryset(self, request, queryset):
        default_area_id = Area.get_default_area()
        if default_area_id in queryset.values_list("id", flat=True):
            messages.error(request, f"Нельзя удалить базовую сферу [ID = {default_area_id}] пока есть относящиеся к ней сущности")
            queryset = queryset.exclude(id=default_area_id)
        super().delete_queryset(request, queryset)


@admin.register(DirectionsFilter)
class DirectionsFilterAdmin(admin.ModelAdmin):

    list_display = ["id", "name"]
    list_display_links = ["name"]

    def delete_model(self, request, obj):
        if obj.id == DirectionsFilter.get_default_direction():
            messages.error(request, f"Нельзя удалить базовое направление [ID = {obj.id}] пока есть относящиеся к нему сущности")
            return
        return super().delete_model(request, obj)
    
    def delete_queryset(self, request, queryset):
        default_direction_id = DirectionsFilter.get_default_direction()
        if default_direction_id in queryset.values_list("id", flat=True):
            messages.error(request, f"Нельзя удалить базовое направление [ID = {default_direction_id}] пока есть относящиеся к нему сущности")
            queryset = queryset.exclude(id=default_direction_id)
        super().delete_queryset(request, queryset)

@admin.register(MoneyAmountFilter)
class MoneyAmountFilterAdmin(admin.ModelAdmin):
    
    list_display = ["id", "value", "type_srt"]
    list_display_links = ["value"]

    def delete_model(self, request, obj):
        if obj.id == MoneyAmountFilter.get_default_money_filter():
            messages.error(request, f"Нельзя удалить базовый денежный регулятор [ID = {obj.id}] пока есть относящиеся к нему сущности")
            return
        return super().delete_model(request, obj)
    
    def delete_queryset(self, request, queryset):
        default_money_filter_id = MoneyAmountFilter.get_default_money_filter()
        if default_money_filter_id in queryset.values_list("id", flat=True):
            messages.error(request, f"Нельзя удалить базовый денежный регулятор [ID = {default_money_filter_id}] пока есть относящиеся к нему сущности")
            queryset = queryset.exclude(id=default_money_filter_id)
        super().delete_queryset(request, queryset)
