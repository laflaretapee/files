from django.core.validators import MinValueValidator
from django.db import models

# Create your models here.

class Area(models.Model):
    name = models.CharField(
        verbose_name="Название сферы", max_length=128, unique=True
    )
    @classmethod
    def get_default_area(cls):
        obj, _ = Area.objects.get_or_create(name="Без сферы")
        return obj.id

    def __str__(self):
        return self.name

    class Meta:
        db_table = "support_measure_areas"
        verbose_name = "Сфера"
        verbose_name_plural = "Сферы"

class MoneyAmountFilter(models.Model):

    class MoneyChoices(models.TextChoices):
        LOWER_THAN = "<", "до"
        HIGHER_THAN = ">", "более"
        EQUAL = "=", "равно"

    value = models.DecimalField(verbose_name="Значение", max_digits=10, decimal_places=2, default=0.00,
        validators=[
            MinValueValidator(0.00)
        ])
    type_srt = models.CharField(verbose_name="Тип", max_length=10, choices=MoneyChoices, default=MoneyChoices.HIGHER_THAN)

    @classmethod
    def get_default_money_filter(cls):
        obj, _ = MoneyAmountFilter.objects.get_or_create(value=0.00, type_srt=cls.MoneyChoices.HIGHER_THAN)
        return obj.id

    def __str__(self):
        return f"{self.get_type_srt_display()} {self.value} ₽"

    class Meta:
        unique_together = ('value','type_srt',)
        db_table = "support_measure_money_amounts"
        verbose_name = "Денежная сумма"
        verbose_name_plural = "Денежные суммы"


class DirectionsFilter(models.Model):
    name = models.CharField(
        verbose_name="Направление", max_length=128, unique=True
    )
   
    @classmethod
    def get_default_direction(cls):
        obj, _ = DirectionsFilter.objects.get_or_create(name="Без направления")
        return obj.id

    def __str__(self):
        return self.name

    class Meta:
        db_table = "support_measure_directions"
        verbose_name = "Направление"
        verbose_name_plural = "Направления"
