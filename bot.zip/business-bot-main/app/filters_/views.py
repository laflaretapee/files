from unicodedata import category
from asgiref.sync import sync_to_async

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from supports.models import SupportMeasure, SupportMeasureCategory
from filters_.models import Area, DirectionsFilter, MoneyAmountFilter
from requests_.utils import validate_telegram_token
from requests_.utils import validate_telegram_token


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_money_filters_view(request):
    """
    Возвращает все категории в виде вложенного словаря вместе с мерами поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    Опционально можно передать category_id для получения конкретной категории.
    """
    try:
        money = MoneyAmountFilter.objects.all().exclude(value=0.00, type_srt=MoneyAmountFilter.MoneyChoices.HIGHER_THAN)

        data = [
            {
                "money_id": mon.id,
                "type": mon.type_srt,
                "value": mon.value,
            }
            for mon in money
        ]

        if not data:
            raise ValueError("Отсутствуют денежные суммы!")

        return JsonResponse(
            {"error": False, "message": "Денежные суммы успешно получены", "data": data},
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"Ошибка при получении денежных сумм: {str(e)}"},
            status=500,
        )

@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_directions_filters_view(request):
    """
    Возвращает все категории в виде вложенного словаря вместе с мерами поддержки.
    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN).
    Опционально можно передать category_id для получения конкретной категории.
    """
    try:
        dirs = DirectionsFilter.objects.all().exclude(name="Без направления")

        data = [
            {
                "direction_id": direction.id,
                "title": direction.name,
            }
            for direction in dirs
        ]

        if not data:
            raise ValueError("Направления не найдены!")

        return JsonResponse(
            {"error": False, "message": "Направления успешно получены", "data": data},
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"Ошибка при получении направлений! {str(e)}"},
            status=500,
        )
    
@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_measures_by_dirandcat_view(request):
    category_id = request.GET.get("category_id")
    direction_id = request.GET.get("direction_id")

    if not all((category_id, direction_id)):
        return JsonResponse({"error": True, "message": "Переданы не все данные"}, status=400)
    
    try:
        measures = SupportMeasure.objects.filter(category=category_id, direction=direction_id, visible=True)

        data = [
            {
                "measure_id": measure.id,
                "measure_name": measure.name,
                "category_id": measure.category.id if measure.category else SupportMeasureCategory.get_default_category(),
                "category_name": measure.category.name if measure.category else "Без категории",
                "measure_descr": measure.description,
                "min_trust": measure.min_trust,
                "price": measure.price,
                "area_id": measure.area.id if measure.area else Area.get_default_area(),
                "area_name": measure.area.name if measure.area else "Без сферы",
                "money_id": measure.money.get_default_money_filter(),
                "money_value": str(measure.money),
                "direction_id": measure.direction.id if measure.direction else DirectionsFilter.get_default_direction(),
                "direction_name": measure.direction.name if measure.direction else "Без направления",
                "additional_url": measure.additional_url,
            }
            for measure in measures
        ]

        if not data:
            raise ValueError("Меры поддержки не найдены!")

        return JsonResponse(
            {"error": False, "message": "Меры поддержки успешно получены", "data": data},
            status=200,
        )

    except Exception as e:
        return JsonResponse(
            {"error": True, "message": f"Нет мер поддержки, соответствующих выбранному фильтру!"},
            status=500,
        )
