"""Служебные функции для уменьшения объёма handler'ов"""

import re

from common.config import dadata

def search_company_by_inn(inn) -> dict | None:
    suggestions = dadata.find_by_id(name="party", query=inn)
    company = None
    for suggestion in suggestions:
        if suggestion["data"]["state"]["status"] == "ACTIVE":
            company = suggestion
            break
    return company

def parse_result(company):
    inn = company["data"]["inn"]
    title = company["value"]
    type_ = company["data"]["opf"]["full"]
    region = company["data"]["address"]["data"]["region_with_type"]
    address = company["data"]["address"]["unrestricted_value"]
    return {
        "inn": inn,
        "title": title,
        "type": type_,
        "region": region,
        "address": address,
    }

def is_invalid_email(email):
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return not re.match(pattern, email)

def is_invalid_fio(fio):
    pattern = "^[А-ЯЁ][а-яё]+ [А-ЯЁ][а-яё]+ [А-ЯЁ][а-яё]+$"
    return not re.match(pattern, fio)

def is_invalid_inn(inn):
    return not inn.isdigit() or len(inn) not in [10, 12]

def format_phone_number(phone):
    """Форматирует телефонный номер в стандартный вид 7 *** *** ** **"""
    
    if not phone:
        return None
    digits_only = "".join(char for char in phone if char.isdigit())
    if len(digits_only) < 10:
        return None
    if len(digits_only) == 10:
        return "7" + digits_only
    elif len(digits_only) == 11:
        if digits_only.startswith("8"):
            return "7" + digits_only[1:]
        elif digits_only.startswith("7"):
            return digits_only
        else:
            return digits_only
    else:
        return digits_only
    

def get_profile_text(user):
    """Возвращает строку, содержащую данные из 
    переданного словаря - профиля пользователя
    """
    
    return (\
        f"👤 <u><b>Профиль пользователя:</b></u>\n\n"\
        
        "⚙️ <b>Основная информация:</b>\n\n"\
        
        f"🆔 ID: {user['username'] or '❌ Не указано'}\n"\
        f"📝 ФИО: {user['full_name'] or '❌ Не указано'}\n"\
        f"👔 Должность: {user['role'] or '❌ Не указано'}\n\n"\
        
        "☎️ <b>Связь:</b>\n\n"\
        
        f"🔗 Способ связи: {user['connection'] or '❌ Не указано'}\n"\
        f"📱 Телефон: +{user['phone'] or '❌ Не указано'}\n"\
        f"📧 Email: {user['email'] or '❌ Не указано'}\n"\
        f"✉️ Подтверждён: {'✅ Да' if user['email_verified'] else '❌ Нет'}\n\n"\
        
        "🏢 <b>Компания:</b>\n\n"\
        
        f"🏷 Название: {user['company']['title'] or '❌ Не указано'}\n"\
        f"▶️ ИНН: {user['company']['inn'] or '❌ Не указано'}\n"\
        f"🗺️ Адрес: {user['company']['address'] or '❌ Не указано'}\n"\
        f"📊 Категория: {user['company']['category'] or '❌ Не указано'}\n\n"\
        "⚠️ Не забывайте, что вы всегда можете обратиться в службу поддержки и изменить свои данные, если возникла ошибка!")


def get_prefix(child):
    prefix = ""
    if child.get('for_modules', None)is not None:
        prefix = "mod:"
    elif child.get('for_finances', None) is not None: 
        prefix = "fin:"
    return prefix

def find_category(categories_list, target_id):
    for category in categories_list:
        if category["category_id"] == target_id:
            return category
        if category["children"]:
            result = find_category(category["children"], target_id)
            if result:
                return result
    return None
    
def find_parent_id(categories_list, child_id):
    for category in categories_list:
        for child in category["children"]:
            if child["category_id"] == child_id:
                return category["category_id"]
        result = find_parent_id(category["children"], child_id)
        if result:
            return result
    return None


def parse_measure_page_callback_data(measure_data, data):
    callback_data = f"cat:{measure_data['category_id']}"
    if data[-1] == "finances":
        money_id = data[2]
        area_id = data[3]
        callback_data = f"type:{area_id}:{money_id}"
    elif data[-1] == "modules":
        category_id = data[2]
        direction_id = data[3]
        root_category_id = data[4]
        callback_data = f"searchcategory:{category_id}:{direction_id}:{root_category_id}"
    
    if measure_data.get('image_url', None) is not None:
        callback_data = f"{callback_data}:i"

    return callback_data