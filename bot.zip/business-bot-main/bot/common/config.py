"""Общие конфигурационные данные"""

import os

from aiogram.types import BotCommand

from users.utils import AsyncHttpRequestor  # type: ignore

from dadata import Dadata

dadata = Dadata(os.getenv("DADATA_TOKEN"))

requestor_base_url = AsyncHttpRequestor(os.getenv("BASE_URL"))

requestor_base_headers = {
    "token": os.getenv("TELEGRAM_TOKEN"),
}

BTN_TXT_CATALOG = "📃 Меню"
BTN_TXT_PROFILE = "🧑‍🦰 Профиль"
BTN_TXT_FINANCE = "💼 Финансирование бизнеса"
BTN_TXT_SUPPORT = "ℹ️ Служба поддержки"
BTN_TXT_CANCEL = "❌ Отменить"
BTN_LOYALTY_SUPPORT = "💫 Программы лояльности"
BTN_BUSINESS_SUPPORT = "🤝 Поддержка бизнеса"
BTN_KNOWLEDGE_FOR_BUSINESS = "🗞️ Знание для бизнеса"
BTN_BUSINESS_PARTIES = "🎊 Мероприятия для бизнеса"

CMD_START = "start"
CMD_CATALOG = "menu"
CMD_PROFILE = "profile"
CMD_FINANCE = "finance"
CMD_SUPPORT = "support"
CMD_CANCEL = "cancel"

SLT_CONN = {
    "whatsapp": "WhatsApp",
    "telegram": "Telegram",
    "email": "Email",
    "all": "все виды связи",
}


BOT_COMMANDS = [
    BotCommand(command=CMD_START, description="Запустить Бота"),
    BotCommand(command=CMD_CATALOG, description="Открыть каталог предложений"),
    BotCommand(command=CMD_FINANCE, description="Подобрать меру поддержки по финансированию бизнеса"),
    BotCommand(command=CMD_PROFILE, description="Посмотреть профиль"),
    BotCommand(command=CMD_SUPPORT, description="Помощь и поддержка"),
    BotCommand(command=CMD_CANCEL, description="Отменить операцию"),
]