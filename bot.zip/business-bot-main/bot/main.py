import sys
import os
import asyncio
import logging
import django

from pathlib import Path

# Получаем путь к директории app
BASE_DIR = Path(__file__).resolve().parent.parent
APP_DIR = BASE_DIR / 'app'

# Добавляем путь к директории app в PYTHONPATH
sys.path.append(str(APP_DIR))

# Устанавливаем переменную окружения для Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'app.settings')

from aiogram.client.default import DefaultBotProperties
from aiogram.types import BotCommandScopeAllPrivateChats
from aiogram import Bot, Dispatcher

django.setup()

from dotenv import load_dotenv

from handlers.menu import menu_router
from handlers.register import router_register
from common.config import BOT_COMMANDS

logging.basicConfig(level=logging.INFO)
load_dotenv()

bot = Bot(token=os.getenv("TELEGRAM_TOKEN"), default=DefaultBotProperties(parse_mode='HTML'))

dp = Dispatcher()
dp.include_router(menu_router)
dp.include_router(router_register)


async def main():

    await bot.delete_my_commands()
    await bot.set_my_commands(commands=BOT_COMMANDS, scope=BotCommandScopeAllPrivateChats())

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        ...