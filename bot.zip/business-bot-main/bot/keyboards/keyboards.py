import os
from aiogram import types
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils import keyboard
from aiogram.utils.keyboard import InlineKeyboardBuilder

from common.utils import get_prefix
from common.config import BTN_BUSINESS_PARTIES, BTN_BUSINESS_SUPPORT, BTN_KNOWLEDGE_FOR_BUSINESS, BTN_LOYALTY_SUPPORT, BTN_TXT_FINANCE, BTN_TXT_CATALOG, BTN_TXT_PROFILE, BTN_TXT_SUPPORT, BTN_TXT_CANCEL, SLT_CONN


def get_cancel_kbrd():
    return types.ReplyKeyboardMarkup(
        keyboard=[
            [
                types.KeyboardButton(text=BTN_TXT_CANCEL),
            ],
        ],
        resize_keyboard=True,
    )


def get_connections():
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
        [
            types.InlineKeyboardButton(
                text="📲 " + SLT_CONN["telegram"],
                callback_data="connect:telegram"
            ),
        ],
        [
            types.InlineKeyboardButton(
                text="📲 " + SLT_CONN["whatsapp"],
                callback_data="connect:whatsapp"
            ),
        ],
        [
            types.InlineKeyboardButton(
                text="📲 " + SLT_CONN["email"],
                callback_data="connect:email"
            ),
        ],
        [
            types.InlineKeyboardButton(
                text="⏺ " + SLT_CONN["all"],
                callback_data="connect:all"
            ),
        ],
    ],
    resize_keyboard=True,
    one_time_keyboard=True,
    )


def get_phone_keyboard() -> types.ReplyKeyboardMarkup:
    """Клавиатура для отправки контакта"""
    return types.ReplyKeyboardMarkup(
        keyboard=[
            [types.KeyboardButton(text="☎️ Отправить", request_contact=True)]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def get_directions_kbrd(directions, category_id):
    builder = InlineKeyboardBuilder()
    for direction in directions:
        builder.row(
            types.InlineKeyboardButton(
                text=f"{direction['title']}",
                callback_data=f"dir:{direction['direction_id']}:{category_id}",
            )
        )
    
    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data=f"all:"))
    keyboard = builder.adjust(1).as_markup()
    return keyboard


def get_business_choice_kbrd():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="💼 Финансовые меры поддержки", callback_data="fin:")],
            [types.InlineKeyboardButton(text="📦 Иные меры поддержки", callback_data="all:")],
        ]
    )


async def get_included_categories_and_measures_kbrd(category: list[dict]) -> InlineKeyboardMarkup:
    """Создает клавиатуру со списком категорий для заданного родителя"""

    builder = InlineKeyboardBuilder()
    parent_id = int(category["parent_id"]) if category["parent_id"] is not None else 0 
    subcategories = category["children"]
    measures = category["measures"]
    back_callback_data = "business:"

    for category_ in subcategories:
        text = category_["category_name"]
        prefix = get_prefix(category_)
        str_ = f"{prefix}cat:{category_['category_id']}"
        builder.add(types.InlineKeyboardButton(text=text, callback_data=str_))

    for measure in measures:
        text = measure["measure_name"]
        id_ = measure['measure_id']
        str_ = f"measure:{id_}"
        builder.add(types.InlineKeyboardButton(text=text, callback_data=str_))

    if parent_id != 0:
        back_callback_data = f"cat:{parent_id}"
    elif category["category_name"] != "":
        back_callback_data = "all:"

    builder.add(types.InlineKeyboardButton(text="◀️ Назад", callback_data=back_callback_data))
    return builder.adjust(1).as_markup()


def get_main_menu_keyboard() -> types.ReplyKeyboardMarkup:
    """Основное меню после регистрации"""
    return types.ReplyKeyboardMarkup(
        keyboard=[
            [
                types.KeyboardButton(text=BTN_KNOWLEDGE_FOR_BUSINESS),
                types.KeyboardButton(text=BTN_BUSINESS_SUPPORT),
            ],
            [
                types.KeyboardButton(text=BTN_BUSINESS_PARTIES),
                types.KeyboardButton(text=BTN_LOYALTY_SUPPORT),
            ],
            [
                types.KeyboardButton(text=BTN_TXT_SUPPORT),
                types.KeyboardButton(text=BTN_TXT_PROFILE),
            ],
        ],
        resize_keyboard=True,
    )


def get_prices_kbrd(data: list[dict]):
    builder = InlineKeyboardBuilder()
    free = None
    for price in data:
        tp = price["type"]
        vl = float(price["value"])
        if tp == "=" and vl == 0:
            free = price["money_id"]
        else:
            nm = "До" if tp == "<" else "Более" if tp == ">" else ""
            builder.row(types.InlineKeyboardButton(text=f"{nm} {price['value']} ₽", callback_data=f"price:{price['money_id']}"))

    if free is not None:
        builder.row(types.InlineKeyboardButton(text=f"Иные", callback_data=f"price:{free}"))

    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data=f"business:"))
    keyboard = builder.as_markup()
    return keyboard


def get_areas_kbrd(areas: list[dict], money_id: str):
    builder = InlineKeyboardBuilder()
    for area in areas:
        builder.row(types.InlineKeyboardButton(text=f"{area['title']}", callback_data=f"type:{area['area_id']}:{money_id}"))
    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data=f"fin:"))
    keyboard = builder.as_markup()
    return keyboard


def get_finances_search_kbrd(measures: list[dict], price_id):
    builder = InlineKeyboardBuilder()
    for measure in measures:
        builder.add(
            types.InlineKeyboardButton(
                text=f"{measure['measure_name']}",
                callback_data=f"measure:{measure['measure_id']}:{price_id}:{measure["area_id"]}:finances",
            )
        )
    builder.row(types.InlineKeyboardButton(text=f"◀️ Назад", callback_data=f"price:{price_id}"))
    return builder.adjust(1).as_markup()

def get_modules_search_kbrd(measures: list[dict], category_id, direction_id, root_category_id):
    builder = InlineKeyboardBuilder()
    for measure in measures:
        builder.row(
            types.InlineKeyboardButton(
                text=f"{measure['measure_name']}",
                callback_data=f"measure:{measure['measure_id']}:{category_id}:{direction_id}:{root_category_id}:modules",
            )
        )

    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data=f"dir:{direction_id}:{root_category_id}"))
    return builder.adjust(1).as_markup()


def get_back_kbrd(callback_data: str = None, text: str = "◀️ Назад"):
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text=text, callback_data=callback_data)]
        ],
        resize_keyboard=True,
    )
    return keyboard

def get_policy_keyboard():
    """Подтверждение политики конфиденциальности"""
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="✅ Ознакомлен и даю согласие", callback_data="policy:")]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    return keyboard


def get_inn_agreement_keyboard() -> types.ReplyKeyboardMarkup:
    """Подтверждение ИНН"""
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [
                types.InlineKeyboardButton(
                    text="✅ Все верно", callback_data="inn_agreement:agree"
                ),
                types.InlineKeyboardButton(
                    text="✏️ Изменить", callback_data="inn_agreement:decline"
                ),
            ]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    return keyboard


def create_telegram_link(userid: int) -> InlineKeyboardMarkup:
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="💬 Перейти к чату", url=f"tg://openmessage?user_id={userid}")]
        ],
        resize_keyboard=True,
    )
    return keyboard


def get_check_email_keyboard():
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="🚀 Я подтвердил почту", callback_data="email:")]
        ],
        resize_keyboard=True,
    )
    return keyboard


def construct_categories_keyboard(categories: list[dict], direction_id, category_id):
        builder = InlineKeyboardBuilder()
        def construct(categories):
            for category in categories:
                builder.row(
                    types.InlineKeyboardButton(
                        text=f"{category['category_name']}",
                        callback_data=f"searchcategory:{category['category_id']}:{direction_id}:{category_id}",
                    )
                )
                if category.get("children", None):
                    construct(category["children"])

        construct(categories)
        builder.row(types.InlineKeyboardButton(text=f"◀️ Назад", callback_data=f"mod:cat:{category_id}"))
        keyboard = builder.adjust(1).as_markup()
        return keyboard

def get_measure_kbrd(text, measure_data, is_paid, user_id, callback_data):

    action = 'buy' if is_paid else 'get'
    btn_text = "🛒 Приобрести (₽)" if is_paid else "📥 Получить"
    action_callback = f"{action}:measure:{measure_data['id']}"

    builder = InlineKeyboardBuilder()
    btn = types.InlineKeyboardButton(text=btn_text, callback_data=action_callback)
    
    if measure_data.get("additional_url", None):
        url: str = f'{os.getenv("BASE_URL")}requests/redirect?support_id={measure_data["id"]}&user_id={user_id}'
        text = text.replace("{{url}}", url)
        if float(measure_data["price"]) == 0.00 and measure_data["finances"]:
            btn = types.InlineKeyboardButton(text=btn_text, url=url)
    else:
        text = text.replace("{{url}}", "")

    builder.row(btn)
    builder.row(types.InlineKeyboardButton(text="◀️ Вернуться назад", callback_data=callback_data))
    keyboard = builder.as_markup()

    return keyboard, text


def get_payment_kbrd(measure_id):
    builder = InlineKeyboardBuilder()
    builder.row(
        types.InlineKeyboardButton(
            text="💳 Банковская карта", 
            callback_data=f"paymethod:card:{measure_id}"
        ),
        types.InlineKeyboardButton(
            text="📝 Счёт-оферта", 
            callback_data=f"paymethod:invoice:{measure_id}"
        )
    )
    keyboard = builder.adjust(1).as_markup()
    return keyboard

def get_card_payment_kbrd(payment, measure_id):
    markup = InlineKeyboardBuilder()
    markup.add(types.InlineKeyboardButton(text="💳 Оплатить", url=payment.confirmation.confirmation_url))
    markup.add(types.InlineKeyboardButton(text="◀️ Назад", callback_data=f"buy:measure:{measure_id}:pay"))
    return markup.adjust(1).as_markup()


def get_invoice_payment_kbrd(invoice_result, measure_id):
    markup = InlineKeyboardBuilder()
    markup.add(types.InlineKeyboardButton(
        text="📄 Оплатить через СБП", 
        url=invoice_result['payment_url'])
    )
    markup.row(types.InlineKeyboardButton(
        text="◀️ Назад", 
        callback_data=f"buy:measure:{measure_id}:pay"))
    return markup.adjust(1).as_markup()