from logging import getLogger

from aiogram import types, Router, F
from aiogram.filters import StateFilter
from aiogram.types import (
    FSInputFile,
)

from common.utils import parse_measure_page_callback_data
from common.config import requestor_base_headers, requestor_base_url
from keyboards.keyboards import get_back_kbrd, get_included_categories_and_measures_kbrd, get_measure_kbrd

support_router = Router()
support_router.message.filter(StateFilter(None))
support_router.callback_query.filter(StateFilter(None))

logger = getLogger(__name__)


@support_router.callback_query(F.data == "all:")
async def cmd_measures(callback: types.CallbackQuery):

    response = await requestor_base_url.make(
        "get", 
        "supports/categories/", 
        headers=requestor_base_headers
    )
    if response["error"]:
        await callback.message.edit_text(
            "⚠️ " + response["message"], 
            reply_markup=get_back_kbrd(callback_data="business:", text="◀️ Вернуться назад"))
        return

    keyboard = await get_included_categories_and_measures_kbrd(response["data"])

    response_option = await requestor_base_url.make(
        "get", 
        "options/get", 
        headers=requestor_base_headers, 
        params={"option": "catalog_text"}
    )

    await callback.message.edit_text(
        response_option["message"], 
        reply_markup=keyboard, 
        parse_mode="HTML"
    )


@support_router.callback_query(F.data.startswith("cat:"))
async def process_category_selection(callback: types.CallbackQuery):

    data = callback.data.split(":")
    category_id = int(data[1])
    with_image = data[-1] == "i"

    category_data = await requestor_base_url.make(
        "get", 
        "supports/categories/", 
        headers=requestor_base_headers, 
        params={"category_id": category_id}
    )

    if category_data["error"]:
        await callback.message.edit_text(
            f"⚠️ Ошибка при получении категории! {category_data["message"]}", 
            reply_markup=get_back_kbrd(callback_data="all:", text="◀️ Назад на главную"),
            show_alert=True,
        )
        return


    keyboard = await get_included_categories_and_measures_kbrd(category_data["data"])
    text = f"📁 <b>Категория:\n  └{category_data['data']['category_name']}</b>\n"
    if category_data["data"]["category_descr"]:
        text += f"\n{category_data['data']['category_descr']}\n"

    if with_image:
        await callback.message.delete()
    
    callback_method = callback.message.answer if with_image else callback.message.edit_text
    
    await callback_method(
        text, 
        reply_markup=keyboard, 
        parse_mode="HTML"
    )


@support_router.callback_query(F.data.startswith("measure:"))
async def process_measure_selection(callback: types.CallbackQuery):

    data = callback.data.split(":")
    measure_id = int(data[1])
    
    measure_data = await requestor_base_url.make(
        "get", 
        "supports/get-support/", 
        headers=requestor_base_headers, 
        params={"id": measure_id}
    )

    if measure_data["error"]:
        await callback.message.edit_text(
            "⚠️ Ошибка при получении данных о мере поддержки! Попробуйте еще раз.",
            reply_markup=get_back_kbrd(callback_data="all:", text="◀️ Назад на главную"),
        )
        return

    callback_data = parse_measure_page_callback_data(measure_data["data"], data)

    await show_measure_info(
        callback=callback, 
        measure_data=measure_data["data"], 
        callback_data=callback_data
    )
    

async def show_measure_info(callback: types.CallbackQuery, measure_data: dict, callback_data: str):

    user_id = callback.from_user.id
    price = float(measure_data["price"])
    is_paid = price > 0.0

    text = (
        f"📋 {measure_data['name']}\n\n"
        f"{measure_data['descr']}\n\n"
        f"🏷 Категория:\n  └{measure_data['category']}"
    )
    
    if is_paid:
        text += f"\n\n💰 Стоимость: {measure_data['price']}₽"

    keyboard, text = get_measure_kbrd(text, measure_data, is_paid, user_id, callback_data)
    
    if measure_data.get("image_url"):
        image_file = FSInputFile(measure_data["image_url"])

        try:
            await callback.message.delete()
        except Exception as e:
            logger.warning(f"Не удалось удалить сообщение: {e}")
        await callback.message.answer_photo(
            photo=image_file, 
            caption=text, 
            reply_markup=keyboard, 
            parse_mode="HTML"
        )
        return
    
    try:
        await callback.message.edit_text(
            text=text, 
            reply_markup=keyboard, 
            parse_mode="HTML"
        )

    except Exception as e:
        logger.warning(f"Ошибка редактирования текста: {e}")
        await callback.message.delete()
        await callback.message.answer(
            text=text, 
            reply_markup=keyboard, 
            parse_mode="HTML"
        )
