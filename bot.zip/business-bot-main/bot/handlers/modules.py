from unicodedata import category
from aiogram import Router, F, types
from aiogram.filters import StateFilter
from aiogram.utils import keyboard
from aiogram.utils.keyboard import InlineKeyboardBuilder

from common.config import requestor_base_headers, requestor_base_url
from keyboards.keyboards import construct_categories_keyboard, get_back_kbrd, get_directions_kbrd, get_main_menu_keyboard, get_modules_search_kbrd
from requests_.utils import remove_emojis # type: ignore


modules_router = Router()
modules_router.message.filter(StateFilter(None))
modules_router.callback_query.filter(StateFilter(None))

@modules_router.callback_query(F.data.startswith("mod:"))
async def process_category_modules_selection(callback: types.CallbackQuery):

    username = str(callback.from_user.id)
    updated_headers = requestor_base_headers.copy()
    updated_headers["username"] = username
    
    data = callback.data.split(":")
    category_id = data[2]

    response = await requestor_base_url.make(
        "get", 
        "/filters/get-directions-filters", 
        headers=updated_headers
    )

    if response["error"]:
        await callback.message.edit_text(
            "⚠️ " + response["message"], 
            reply_markup=get_back_kbrd(callback_data="all:", text="◀️ Вернуться назад"))
        return

    keyboard = get_directions_kbrd(response["data"], category_id)
    await callback.message.edit_text(
        "🔎 Какое направление из перечисленных Вас интересует? ", 
        reply_markup=keyboard
    )


@modules_router.callback_query(F.data.startswith("dir:"))
async def process_direction_modules_selection(callback: types.CallbackQuery):
    data = callback.data.split(":")
    direction_id = data[1]
    category_id = data[2]

    response = await requestor_base_url.make(
        "get", 
        "/supports/categories/", 
        headers=requestor_base_headers, 
        params={"category_id": category_id}
    )

    if response["error"]:
        await callback.message.edit_text(
            "⚠️ " + response["message"], 
            reply_markup=get_back_kbrd(callback_data=f"mod:cat:{category_id}", text="◀️ Вернуться назад"))
        return
    
    keyboard = construct_categories_keyboard(response["data"]["children"], direction_id, category_id)
    await callback.message.edit_text(
        "🔎 Хорошо, а теперь давайте выберем категорию: ", 
        reply_markup=keyboard
    )


@modules_router.callback_query(F.data.startswith("searchcategory:"))
async def process_direction_modules_selection(callback: types.CallbackQuery):
    
    data = callback.data.split(":")
    with_image = data[-1] == "i"
    if with_image:
        await callback.message.delete()

    category_id = data[1]
    direction_id = data[2]
    root_category_id = data[3]
    await get_modules_result(direction_id, category_id, root_category_id, callback, with_image)


async def get_modules_result(direction_id: str, category_id: str, root_category_id: str, callback: types.CallbackQuery, with_image: bool):

    callback_method = callback.message.answer if with_image else callback.message.edit_text

    response = await requestor_base_url.make(
        "get",
        "/filters/get-measures-dirandcat",
        headers=requestor_base_headers,
        params={"category_id": category_id, "direction_id": direction_id},
    )

    if response["error"]:
        await callback_method(
            f"⚠️ {response['message']}",
            reply_markup=get_back_kbrd(callback_data=f"dir:{direction_id}:{root_category_id}", text="◀️ Вернуться назад"),
        )
        return
    
    measures = response["data"]
    keyboard = get_modules_search_kbrd(measures, category_id, direction_id, root_category_id)
    direction = measures[0].get("direction_name", "не найдено")
    category = remove_emojis(measures[0].get("category_name", "не найдено"))

    await callback_method(
        f"🔮 Спасибо за ваши ответы!\n\n"+
        f"🔎 Вот что мне удалось найти по вашим предпочтениям:\n\n"+
        f"💼 Направление: {direction}\n"+
        f"🛒 Категория: {remove_emojis(category)}\n",
        reply_markup=keyboard,
    )    
