import datetime
from logging import getLogger

from aiogram import F, Bot, types, Router

from keyboards.keyboards import get_card_payment_kbrd, get_invoice_payment_kbrd, get_payment_kbrd
from common.config import requestor_base_headers, requestor_base_url
from .payment import create_payment, create_invoice

actions_router = Router()

logger = getLogger(__name__)


@actions_router.callback_query(F.data.startswith("get:measure:"))
async def process_get_measure(callback: types.CallbackQuery, bot: Bot):
    """Обработчик запроса на получение меры поддержки"""
    try:
        measure_id = int(callback.data.split(":")[2])
        userid = callback.from_user.id
        
        measure_data = await requestor_base_url.make(
            "get", 
            "supports/get-support/", 
            headers=requestor_base_headers, 
            params={"id": measure_id}
        )

        body = {
            "username": userid,
            "support_id": measure_data.get("data", {}).get("id"),
            "title": "Получение меры поддержки",
        }

        result = await requestor_base_url.make(
            "post", "supports/take-support/", 
            headers=requestor_base_headers, 
            body=body
        )

        if result["error"]:
            await callback.answer(
                f"⚠️ {result['message']}", 
                show_alert=True)
            return

        gratitude = result.get("gratitude", "")
        await callback.message.answer(
            f"✅ Ваша заявка на получение меры поддержки: «{measure_data['data']['title']}» "+
            f"успешно отправлена! {f'\n\ngratitude' if gratitude else ''}\n\n"+
            f"🆔 Номер обращения {result['data']['request_id']:0>8}",
            show_alert=True,
        )

        response_option = await requestor_base_url.make(
            "get", 
            "options/get", 
            headers=requestor_base_headers, 
            params={"option": "bot_chat_id"}
        )

        option_value = response_option["message"]
        msg = result["message"]

        try:
            await bot.send_message(
                chat_id=option_value,
                text=\
                f"🔔 Приобретение меры поддержки!\n"+
                f"🆔 Номер обращения {result['data']['request_id']:0>8}\n\n{msg}",
            )
        except Exception as e:
            logger.error(e)

    except Exception as e:
        logger.error(f"Ошибка при обработке запроса на получение меры: {e}")
        await callback.answer(
            f"⚠️ Произошла непредвиденная ошибка. {e}", 
            show_alert=True
        )


@actions_router.callback_query(F.data.startswith("buy:measure:"))
async def handle_purchase(callback: types.CallbackQuery):
    
    data = callback.data.split(":")
    measure_id = data[2]
    

    measure = await requestor_base_url.make(
        "get", 
        "supports/get-support/", 
        headers=requestor_base_headers, 
        params={"id": measure_id}
    )

    if measure["error"]:
        await callback.answer(
            "⚠️ Произошла ошибка при получении меры поддержки! Пожалуйста, попробуйте позже.",
            show_alert=True,
        )
        return

    username = str(callback.from_user.id)
    updated_headers = requestor_base_headers.copy()
    updated_headers["username"] = username

    response = await requestor_base_url.make(
        "get", 
        "users/profile", 
        headers=updated_headers
    )

    if response["error"]:
        await callback.answer(
            "⚠️ Произошла ошибка при проверке пользователя! Пожалуйста, попробуйте позже.",
            show_alert=True,
        )
        return

    user = response["data"]
    if not user["email_verified"]:
        verify = await requestor_base_url.make(
            "post", 
            "users/send-verify/", 
            headers=requestor_base_headers
        )

        if verify["error"]:
            await callback.answer(
                f"⚠️ Почта пользователя не подтверждена и произошла ошибка при отправке письма на почту {user['email']}!"+
                f"Пожалуйста, попробуйте позже или свяжитесь со службой поддержки.",
                show_alert=True,
            )
            return
        
        await callback.answer(
            f"⚠️ Почта пользователя не подтверждена! Пожалуйста, перейдите по ссылке в письме, "+
            f"которое было отправлено Вам на почту {user['email']}.",
            show_alert=True,
        )
        return

    body = {
        "username": username,
        "support_id": measure_id,
        "title": "Приобретение меры поддержки",
    }

    result = await requestor_base_url.make(
        "post", 
        "supports/take-support/", 
        headers=requestor_base_headers, 
        body=body
    )

    if result["error"]:
        await callback.answer(
            f"⚠️ {result}", 
            show_alert=True
        )
        return

    keyboard = get_payment_kbrd(measure_id)
    callback_method = callback.message.edit_text if data[-1] == "pay" else callback.message.reply

    await callback_method(
        f"<b><i>💰 Оплата меры поддержки:</i></b>\n\n"+
        f"📚 Название: {measure['data']['name']}\n"+
        f"🧮 Сумма: {measure['data']['price']}₽\n\n"+
        f"⤵️ Выберите способ оплаты:", 
        reply_markup=keyboard, 
        parse_mode="HTML"
    )


@actions_router.callback_query(F.data.startswith("paymethod:card"))
async def handle_payment_method(callback: types.CallbackQuery, bot: Bot):

    data = callback.data.split(":")
    bot_username = (await bot.get_me()).username
    method = data[1]
    measure_id = data[2]
    
    measure = await requestor_base_url.make(
        "get", 
        "supports/get-support/", 
        headers=requestor_base_headers, 
        params={"id": measure_id}
    )
    
    try:
        payment = await create_payment(
            measure, 
            str(callback.from_user.id), 
            bot_username,
            payment_method=method
        )

    except Exception as e:
        logger.warning(f"Ошибка при создании платежа: {e}")
        await callback.answer(
            "⚠️ Ошибка при создании платежа! Попробуйте позже!", 
            show_alert=True, 
        )
        return
    
    keyboard = get_card_payment_kbrd(payment, measure_id)

    await callback.message.edit_text(
        f"<b><i>💰 Оплата меры поддержки:</i></b>\n\n"+
        f"📚 Название: {measure['data']['name']}\n"+
        f"🧮 Сумма: {measure['data']['price']}₽\n\n"+
        "⤵️ Нажмите кнопку ниже для перехода к оплате...",
        reply_markup=keyboard, 
        parse_mode="HTML"
    )


@actions_router.callback_query(F.data.startswith("paymethod:invoice:"))
async def handle_invoice_payment(callback: types.CallbackQuery, bot: Bot):
    
    data = callback.data.split(":")
    measure_id = data[1]
    
    username = str(callback.from_user.id)
    updated_headers = requestor_base_headers.copy()
    updated_headers["username"] = username

    response = await requestor_base_url.make(
        "get", 
        "users/profile", 
        headers=requestor_base_headers
    )
    
    if response["error"]:
        await callback.answer(
            "⚠️ Ошибка получения данных пользователя", 
            show_alert=True
        )
        return
    
    measure = await requestor_base_url.make(
        "get", 
        "supports/get-support/", 
        headers=requestor_base_url, 
        params={"id": measure_id}
    )

    order_data = {
        "order_id": f"support_{measure_id}_{username}",
        "total_amount": measure['data']['price'],
        "description": f"Оплата меры поддержки: {measure['data']['name']}",
    }

    try:
        invoice_result = await create_invoice(order_data, username, (await bot.get_me()).username)
        if not invoice_result['success']:
            raise Exception(invoice_result['message'])

    except Exception as e:
        logger.warning(f"Ошибка при создании платежа: {e}")
        await callback.answer(
            "⚠️ Ошибка при создании платежа! Попробуйте позже!", 
            show_alert=True, 
        )
        return

    keyboard = get_invoice_payment_kbrd(invoice_result, measure_id)

    try:
        await callback.message.edit_text(
            f"🔗 Ссылка для оплаты через СБП готова\n"
            f"Сумма: {measure['data']['price']}₽\n"
            f"Срок действия: {(datetime.now() + datetime.timedelta(days=3)).strftime('%d.%m.%Y %H:%M')}",
            reply_markup=keyboard
        )
    except Exception as e:
        logger.error(f"Ошибка редактирования сообщения: {e}")
        await callback.message.answer(
            text=f"🔗 Ссылка для оплаты: {invoice_result['payment_url']}",
            reply_markup=keyboard
        )
    