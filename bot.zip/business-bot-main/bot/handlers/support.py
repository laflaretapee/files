import os
import asyncio

from logging import getLogger

from aiogram import Bot, types, Router, F
from aiogram.filters import Command, StateFilter, or_f
from aiogram.fsm.context import FSMContext

from common.states import Help
from common.config import (
    BTN_TXT_CANCEL, 
    BTN_TXT_SUPPORT, 
    CMD_CANCEL, 
    CMD_SUPPORT, 
    requestor_base_url, 
    requestor_base_headers
)
from keyboards.keyboards import (
    get_cancel_kbrd,
    get_main_menu_keyboard,
)


router_choose = Router()
logger = getLogger(__name__)

@router_choose.message(StateFilter("*"), or_f(F.text == BTN_TXT_CANCEL, Command(CMD_CANCEL)))
async def cancel(message: types.Message, state: FSMContext, bot: Bot):
    if state:
        await message.answer(
            "⚠️ Операция была отменена!", reply_markup=get_main_menu_keyboard()
        )
        await state.clear()


@router_choose.message(StateFilter(None), or_f(F.text == BTN_TXT_SUPPORT, Command(CMD_SUPPORT)))
async def make_help_request(message: types.Message, state: FSMContext):
    await message.reply("💬 Напишите сообщение для службы поддержки:", reply_markup=get_cancel_kbrd())
    await state.set_state(Help.message)


@router_choose.message(StateFilter(Help.message))
async def process_help_request(message: types.Message, state: FSMContext, bot: Bot):

    username = str(message.from_user.id)
    msg = message.text

    body = {
        "username": username,
        "message": message.text,
    }

    response = await requestor_base_url.make("post", "requests/help/", headers=requestor_base_headers, body=body)

    await state.clear()
    if response["error"]:
        await message.answer(
            f"⚠️ {response['message']}\n"+
            f"🆔 Номер обращения: {response['data']['request_id']:0>8}",
            reply_markup=get_main_menu_keyboard(),
        )
        return

    full_name = response["data"]["full_name"]
    request_id = response["data"]["request_id"]

    try:
        response_option = await requestor_base_url.make(
            "get", "options/get", headers=requestor_base_headers, params={"option": "bot_chat_id"}
        )
        option_value = response_option["message"]

        await bot.send_message(
            chat_id=option_value,
            text=\
            f"🔔 Обращение в службу поддержки!\n"+
            f"🆔 Номер обращения {request_id:0>8}\n👤"+
            f"Клиент: <a href='tg://user?id={username}'>{full_name}</a>\n\n"+
            f"«<b><i>{msg}</i></b>»",
        )
    except Exception as e:
        logger.error(e)

    await message.answer(
        f"✅ Ваша заявка успешно отправлена!\n"+
        f"🆔 Номер обращения: {request_id:0>8}",
        reply_markup=get_main_menu_keyboard(),
    )
    await asyncio.sleep(1)
    await state.clear()
