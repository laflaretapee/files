import os

from aiogram import Bot, types, Router, F
from aiogram.filters import Command, CommandObject, CommandStart, StateFilter, or_f
from aiogram.fsm.context import FSMContext

from common.utils import get_profile_text
from handlers.register import policy_handler
from keyboards.keyboards import (
    get_business_choice_kbrd, 
    get_included_categories_and_measures_kbrd, 
    get_main_menu_keyboard, 
)

from common.states import Register
from common.config import (
    BTN_BUSINESS_PARTIES,
    BTN_BUSINESS_SUPPORT,
    BTN_KNOWLEDGE_FOR_BUSINESS,
    BTN_LOYALTY_SUPPORT,
    CMD_SUPPORT,
    CMD_PROFILE,
    BTN_TXT_PROFILE,
    requestor_base_headers,
    requestor_base_url
)

common_router = Router()

@common_router.message(CommandStart(), StateFilter(None))
async def handle_message_command(message: types.Message, command: CommandObject, state: FSMContext, bot: Bot):
    """Орабатывает комманду /start: проверяет правильность 
    ссылки или QR, выводит стартовый текст для бота
    """
    
    username = str(message.from_user.id)
    updated_headers = requestor_base_headers.copy()
    updated_headers["username"] = username
    response_profile = await requestor_base_url.make("get", "users/profile", headers=updated_headers)

    if response_profile["error"]:
        args = command.args
        response_start = await requestor_base_url.make(
            "get", "options/get", headers=updated_headers, params={"option": "bot_url"}
        )
        if response_start["error"]:
            await message.answer(
                f"⚠️ Произошла ошибка при проверке ссылки! "+
                f"{response_start["message"]}"
            )
            return
        
        if args != response_start["message"]:
            await message.answer(
                "⚠️ Для получения доступа к боту, "+
                "Вам необходимо пройти по ссылке или QR-коду!"
            )
            return

    info = await bot.get_me()
    bot_name = info.first_name
    response_option = await requestor_base_url.make(
        "get", "options/get", headers=updated_headers, params={"option": "start_text"}
    )
    option_value = response_option["message"]
    msg = option_value.replace("{{bot}}", bot_name)

    await state.update_data(username=str(username))
    await message.answer(msg, reply_markup=types.ReplyKeyboardRemove())
    await command_start_handler(message, state, bot, response_profile)


async def command_start_handler(message: types.Message, state: FSMContext, bot: Bot, response: dict):
    """Функция проверяет регистрацию пользователя"""
    if not response["error"]:
        await message.answer("✅ Вы уже зарегистрированы!")
        await show_main_menu(message, bot)
        await state.clear()
        return
    
    await state.set_state(Register.policy)
    await policy_handler(message)


async def show_main_menu(message: types.Message, bot: Bot):
    """Функция, отвечающая за отображение главного меню. Она выводит 
    текст из Option и запрашивает клавиатуру для главного меню
    """
    
    response_option = await requestor_base_url.make(
        "get", "options/get", 
        headers=requestor_base_headers, 
        params={"option": "menu_text"}
    )

    option_value = response_option["message"]
    keyboard = get_main_menu_keyboard()
    info = await bot.get_me()
    bot_name = info.first_name

    await message.answer(
        option_value.replace("{{bot}}", bot_name),
        reply_markup=keyboard,
        parse_mode="HTML",
    )


@common_router.message(StateFilter(None), or_f(F.text == BTN_TXT_PROFILE, Command(CMD_PROFILE)))
async def prof_hand(message: types.Message):
    """handler для вывода данных о профиле пользователя"""
    
    username = str(message.from_user.id)
    updated_headers = requestor_base_headers.copy()
    updated_headers["username"] = username
    response = await requestor_base_url.make("get", "users/profile", headers=updated_headers)

    if response["error"]:
        await message.answer("⚠️ " + response["message"])
        return

    user = response["data"]
    profile_text = get_profile_text(user)
    await message.answer(text=profile_text, parse_mode="HTML", reply_markup=get_main_menu_keyboard())


@common_router.message(StateFilter(None), F.text == BTN_LOYALTY_SUPPORT)
async def process_loyalty_choice(message: types.Message):
    query = {"option": "loyalty_id"}
    response = await requestor_base_url.make("get", "options/get/", headers=requestor_base_headers, params=query)
    if response["error"]:
        await message.reply("⚠️ " + response["message"])
        return
    
    response = await requestor_base_url.make(
        "get", 
        "supports/categories/", 
        headers=requestor_base_headers, 
        params={"category_id": int(response["message"])}
    )

    if response["error"]:
        await message.reply("⚠️ " + response["message"])
        return
    
    keyboard = await get_included_categories_and_measures_kbrd(response["data"])
    await message.reply("💫 Доступные для Вас программы лояльности:", reply_markup=keyboard)


@common_router.message(StateFilter(None), F.text == BTN_BUSINESS_PARTIES)
async def process_loyalty_choice(message: types.Message):
    query = {"option": "parties_id"}
    response = await requestor_base_url.make("get", "options/get/", headers=requestor_base_headers, params=query)
    if response["error"]:
        await message.reply("⚠️ " + response["message"])
        return
    
    response = await requestor_base_url.make(
        "get", 
        "supports/categories/", 
        headers=requestor_base_headers, 
        params={"category_id": int(response["message"])}
    )

    if response["error"]:
        await message.reply("⚠️ " + response["message"])
        return
    
    keyboard = await get_included_categories_and_measures_kbrd(response["data"])
    await message.reply("🎊 Актуальные на данный момент мероприятия для бизнеса:", reply_markup=keyboard)


@common_router.message(StateFilter(None), F.text == BTN_KNOWLEDGE_FOR_BUSINESS)
async def process_loyalty_choice(message: types.Message):
    query = {"option": "knowledge_id"}
    response = await requestor_base_url.make("get", "options/get/", headers=requestor_base_headers, params=query)
    if response["error"]:
        await message.reply("⚠️ " + response["message"])
        return
    
    response = await requestor_base_url.make(
        "get", 
        "supports/categories/", 
        headers=requestor_base_headers, 
        params={"category_id": int(response["message"])}
    )

    if response["error"]:
        await message.reply("⚠️ " + response["message"])
        return
    
    keyboard = await get_included_categories_and_measures_kbrd(response["data"])
    await message.reply("🗞️ Важные сведения и знания для бизнеса:", reply_markup=keyboard)


@common_router.message(StateFilter(None), F.text == BTN_BUSINESS_SUPPORT)
@common_router.callback_query(StateFilter(None), F.data.startswith("business:"))
async def process_business_support_choice(update: types.Update, state: FSMContext):
    message_method = update.reply if isinstance(update, types.Message) else update.message.edit_text
    await message_method("🔍 Выберите, какие меры поддержки Вас интересуют:", reply_markup=get_business_choice_kbrd())


@common_router.callback_query(StateFilter(None))
async def catch_update(callback: types.CallbackQuery, state: FSMContext, bot: Bot):
    """служебный handler, который отлавливает необработанные нажатия на inline кнопки"""
    await callback.message.delete()


@common_router.message(StateFilter(None))
async def echo(message: types.Message):
    """служебный handler, который отлавливает необработанные сообщения"""

    await message.reply(
        text=f"🤔 Извините, но я не знаю такой команды :(\n💡 Если у Вас имеются вопросы, можете обратиться в службу поддержки: /{CMD_SUPPORT}"
    )
