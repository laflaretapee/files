from email import message
from aiogram import Router, F, types
from aiogram.filters import StateFilter, or_f

from common.config import requestor_base_headers, requestor_base_url
from keyboards.keyboards import (
    get_areas_kbrd, 
    get_back_kbrd, 
    get_finances_search_kbrd, 
    get_prices_kbrd
)

finances_router = Router()
finances_router.message.filter(StateFilter(None))
finances_router.callback_query.filter(StateFilter(None))

@finances_router.callback_query(F.data.startswith("fin:"))
async def choose_finances(callback: types.CallbackQuery):
    """hadler, выводящий список стоимостей мер поддержки в виде 
    inline-кнопок и предлагающий пользователю выбрать одну из них"""

    username = str(callback.from_user.id)
    updated_headers = requestor_base_headers.copy()
    updated_headers["username"] = username

    response = await requestor_base_url.make("get", "/filters/get-money-filters", headers=updated_headers)

    if response["error"]:
        await callback.message.edit_text(
            "⚠️ " + response["message"], 
            reply_markup=get_back_kbrd(callback_data="business:", text="◀️ Вернуться назад"))
        return
    
    keyboard = get_prices_kbrd(response["data"])
    await callback.message.edit_text(
        "🔎 Давайте для начала определимся с суммой. "
        "Какая сумма поддержки Вам интересна? ", 
        reply_markup=keyboard
    )


@finances_router.callback_query(F.data.startswith("price:"))
async def choose_type(callback: types.CallbackQuery):
    """handler, отображающий все сферы мер поддержки 
    при их поиске в финансовых мерах поддержки
    """
    
    areas = await requestor_base_url.make("get", "supports/areas", headers=requestor_base_headers)
    if areas["error"]:
        await callback.message.edit_text(
            "⚠️ Не удалось получить список сфер! Пожалуйста, попробуйте позже!", 
            reply_markup=get_back_kbrd(callback_data="business:", text="◀️ Вернуться назад")
        )
        return

    data = callback.data.split(":")
    money_id = data[1]
    keyboard = get_areas_kbrd(areas["data"], money_id)

    await callback.message.edit_text(
        "🔎 Отлично! Теперь давайте определимся со сферой поддержки. Выберите сферу:", 
        reply_markup=keyboard
    )


@finances_router.callback_query(or_f(F.data.startswith("type:")))
async def get_measures_after_search(callback: types.CallbackQuery):
    """handler, отображающий найденные меры поддержки 
    при их поиске в финансовых мерах поддержки"""

    data = callback.data.split(":")
    with_image = data[-1] == "i"
    if with_image:
        await callback.message.delete()

    data = callback.data.split(":")
    area_id = data[1]
    price_id = data[2]
    await get_search_result(area_id, price_id, callback, with_image)


async def get_search_result(area_id, price_id, callback, with_image: bool):

    callback_method = callback.message.answer if with_image else callback.message.edit_text

    measures = await requestor_base_url.make(
        "get",
        "supports/get-supports-by-area/",
        headers=requestor_base_headers,
        params={"area_id": area_id, "price_id": price_id},
    )

    if measures["error"]:
        await callback_method(
            f"⚠️ Возникла ошибка при попытке поиска необходимых мер поддержки! {measures['message']}", 
            reply_markup=get_back_kbrd(callback_data=f"price:{price_id}", text="◀️ Вернуться назад")
        )
        return
        
    keyboard = get_finances_search_kbrd(measures["data"], price_id)
    money_category_name = measures.get('money_name', 'не найдено')
    area_category_name = measures.get('area_name', 'не найдено')

    await callback_method(
        f"🔮 Спасибо за ваши ответы!\n\n"+
        f"🔎 Вот что мне удалось найти по вашим предпочтениям:\n\n"+
        f"💰 Сумма поддержки: {money_category_name}\n"+
        f"▶️ Сфера поддержки: {area_category_name}\n",  
        reply_markup=keyboard
    )
