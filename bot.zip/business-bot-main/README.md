# Развёртывание проекта

## Виртуальное окружение
```console
# Создание
python -m venv .venv

# Активация
.venv\Scripts\activate
```

## Зависимости

```console
# Установка пакетов
pip install -r requirements.txt
```

## Миграции

```console
# Переход в директорию с manage.py
cd app

# Создание миграций
python manage.py makemigrations

# Применение миграций
python manage.py maigrate
```

## Подключение PostgreSQL

Скачиваем с [офиц сайта](https://www.postgresql.org/download/). 
Дальше создаём роль `mpbot` с паролем `qweasdzxc` и добавляем все права.
Дальше создаём БД и называем её mpbot_db и в качестве владельца выбираем mpbot.

## База данных (Заполнение БД фикстурами)

```console
---------------------
# Приложение supports
---------------------

# Сначала создаём категории
python manage.py loaddata fixtures\supports\categories.json > supports.supportmeasurecaregory
# Потом заполняем меры поддержки
python manage.py loaddata fixtures\supports\supports.json > supports.supportmeasure

---------------------
# Приложение modules
---------------------
python manage.py loaddata fixtures\modules\modules.json > modules.module
```
