import os

from asgiref.sync import sync_to_async

from yookassa import Configuration, Payment

from Payment.models import YookassaPayment # type: ignore


Configuration.account_id = os.getenv('YOOKASSA_SHOP_ID')
Configuration.secret_key = os.getenv('YOOKASSA_SECRET_KEY')

async def create_payment(measure, user_id, bot_username):
    
    # Создаем платеж
    payment = Payment.create({
        "amount": {
            "value": f"{float(measure['data']['price']):.2f}",
            "currency": "RUB"
        },
        "confirmation": {
            "type": "redirect",
            "return_url": f"https://t.me/{bot_username}"
        },
        "description": f"Покупка: {measure['data']['name']}",
        "metadata": {
            "user_id": user_id,
            "measure_id": measure["data"]["id"],
            "bot_username": bot_username
        }
    })

    # Оберните создание объекта в синхронный контекст
    await sync_to_async(YookassaPayment.objects.create)(
        payment_id=payment.id,
        user_id=user_id,
        measure_id=measure["data"]["id"],
        amount=float(measure['data']['price']),
        currency='RUB',
        description=f"Покупка: {measure['data']['name']}",
        status=payment.status
    )

    return payment