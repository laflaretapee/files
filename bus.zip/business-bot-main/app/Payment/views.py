import os
import json
import logging
import asyncio

from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from aiogram import Bot

from .models import YookassaPayment

logger = logging.getLogger(__name__)

async def send_telegram_notification(user_id, message, bot_token):
    """Отправляет уведомление пользователю в Telegram"""
    try:
        bot = Bot(token=bot_token)
        await bot.send_message(
            chat_id=user_id,
            text=message,
            parse_mode="HTML"
        )
        await bot.session.close()  # Важно закрыть сессию
        return True
    except Exception as e:
        logger.error(f"Ошибка при отправке уведомления в Telegram: {e}")
        return False

@csrf_exempt
def yookassa_webhook(request):
    if request.method == 'POST':
        try:
            event_data = json.loads(request.body)
            payment_data = event_data.get('object', {})
            payment_id = payment_data.get('id')
            status = payment_data.get('status')
            
            # Получаем платеж из БД
            try:
                payment = YookassaPayment.objects.get(payment_id=payment_id)
                
                # Обновляем статус платежа
                payment.status = status
                payment.save()
                
                # Получаем токен бота из .env
                bot_token = os.getenv("TELEGRAM_TOKEN")
                user_id = payment.user_id  # Предполагается, что в модели есть поле user_id
                
                if status == 'succeeded':
                    message = f"✅ <b>Оплата успешно завершена!</b>\n\n" \
                              f"Идентификатор платежа: {payment_id}\n" \
                              f"Сумма: {payment_data.get('amount', {}).get('value')} {payment_data.get('amount', {}).get('currency')}"
                
                elif status == 'canceled':
                    message = f"❌ <b>Платеж отменен</b>\n\n" \
                              f"Идентификатор платежа: {payment_id}\n" \
                              f"Причина: {payment_data.get('cancellation_details', {}).get('reason', 'Неизвестно')}"
                
                elif status == 'pending':
                    message = f"⏳ <b>Платеж в обработке</b>\n\n" \
                              f"Идентификатор платежа: {payment_id}\n" \
                              f"Пожалуйста, подождите завершения транзакции."
                else:
                    return HttpResponse(status=200)
                
                # Запускаем асинхронную функцию в синхронном коде
                asyncio.run(send_telegram_notification(user_id, message, bot_token))
                
                logger.info(f"Обработан вебхук для платежа {payment_id}, статус: {status}")
                return HttpResponse(status=200)
            
            except YookassaPayment.DoesNotExist:
                logger.warning(f"Платеж с ID {payment_id} не найден в базе данных")
                return HttpResponse(status=200)
                
        except Exception as e:
            logger.error(f"Ошибка при обработке вебхука от Юкассы: {e}")
            return HttpResponse(status=400)
    
    return HttpResponse(status=400)