import json
import logging
import os
import re

from asgiref.sync import sync_to_async

from django.http import HttpRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt

from users.decorators import only_post
from users.models import TelegramUser

from requests_.models import SupportRequest, Question
from requests_.utils import validate_telegram_token


@csrf_exempt
@sync_to_async
@validate_telegram_token
@only_post
def make_help_view(request: HttpRequest):
    """
    Представление для создания заявки в службу поддержки от пользователя.

    В заголовке запроса передаём токен бота (token: TELEGRAM_TOKEN). В теле запроса передаём
    telegram id пользователя (username: telegram_id) и сообщение (message: message).

    Возвращает JSON ответ где под ключом "error" указывается True, если произошла ошибка,
    иначе False. Под ключом "message" указывается текст результата запроса.
    """

    username = request.POST.get("username")
    message = request.POST.get("message")

    if not all([username, message]):
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"},
            status=400,
        )

    try:
        user = TelegramUser.objects.get(username=username)
        request = SupportRequest.objects.create(
            user=user, title="Заявка в службу поддержки", message=message
        )
        return JsonResponse(
            {
                "error": False,
                "message": "Заявка отправлена в службу поддержки",
                "data": {
                    "request_id": request.id,
                    "full_name": user.full_name,
                }
            },
            status=202,
        )
    except Exception as e:
        return JsonResponse(
            {"error": True, "message": "Ошибка при создании заявки. " + str(e)},
            status=500,
        )


@validate_telegram_token
@csrf_exempt
@sync_to_async
def get_questions_view(request: HttpRequest):
    """
    Получить список вопросов для пользователя, в заголовке передаём токен и username
    """
    username = request.headers.get("username")
    if not username:
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"},
            status=400,
        )

    try:
        questions = Question.objects.all()
        data = list(
            [
                {
                    "question_text": obj.question,
                    "question_id": obj.id,
                    "question_order": obj.order,
                }
                for obj in questions
            ],
        )
        data.sort(key=lambda obj: obj["question_order"])

        if questions.exists():
            return JsonResponse(
                {
                    "error": False,
                    "message": "Вопросы успешно получены",
                    "data": data,
                },
                status=200,
            )
        raise Question.DoesNotExist("questions set is empty")

    except Question.DoesNotExist as e:
        return JsonResponse(
            {"error": True, "message": "На данный момент администрация не добавила вопросов"},
            status=404,
        )
    except Exception as e:
        return JsonResponse(
            {
                "error": True,
                "message": "Ошибка при получении списка вопросов. " + str(e),
            },
            status=500,
        )


@sync_to_async
@validate_telegram_token
@only_post
@csrf_exempt
def send_answers_view(request):
    """
    Отправляет уведомление персоналу в виде ответов на вопросы.
    Передаём токен, username и список вопросов.
    """

    username = request.POST.get("username")
    answers = request.POST.get("answers").replace('\'', "\"")
    answers_dict = json.loads(answers)

    if not all([username, answers]):
        return JsonResponse(
            {"error": True, "message": "Переданы не все данные"},
            status=400,
        )

    message = "\n\n".join(
        f"- {answer['question']}\n- {answer['answer']}"  # Исправлены кавычки
        for answer in answers_dict
    )
    
    try:
        user = TelegramUser.objects.get(username=username)
        request = SupportRequest.objects.create(
            user=user, title="Подбор мер поддержки", message=message
        )

        return JsonResponse(
            {
                "error": False,
                "message": "Заявка отправлена успешно создана!",
                "data": {
                    "request_id": request.id,
                    "full_name": user.full_name,
                    "message": message,
                }
            },
            status=202,
        )
    except Exception as e:
        return JsonResponse(
            {
                "error": True,
                "message": "Ошибка при создании заявки! " + str(e),
            },
            status=500,
        )