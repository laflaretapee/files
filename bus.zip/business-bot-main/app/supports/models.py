from tkinter import CASCADE
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models



class SupportMeasureCategory(models.Model):
    """
    Категория мер поддержки. Содержит название категории.
    """
    parent = models.ForeignKey(verbose_name="Родительская категория", to="self", blank=True, null=True, related_name="children", on_delete=models.CASCADE)
    name = models.CharField(
        verbose_name="Название категории", max_length=128, unique=True
    )
    description = models.TextField(verbose_name="Описание категории", blank=True)

    @classmethod
    def get_default_category(cls):
        obj, _ = SupportMeasureCategory.objects.get_or_create(name="Без категории")
        return obj

    def __str__(self):
        return self.name

    class Meta:
        db_table = "support_measure_categories"
        verbose_name = "Категория"
        verbose_name_plural = "Категории"


class SupportMeasure(models.Model):
    """
    Мера поддержки. Каждая мера поддержки связана с определенной категорией.
    Содержит название, категорию, описание, минимальный уровень надежности компании
    и признак платности меры.
    """

    image = models.ImageField(
        verbose_name="Изображение", 
        blank=True, 
        null=True, 
        upload_to="supports/"
    )
    gratitude = models.TextField(verbose_name="Благодарность за покупку", blank=True, null=True)
    name = models.CharField(
        verbose_name="Название меры",
        max_length=128, 
        unique=True
    )
    category = models.ForeignKey(
        to=SupportMeasureCategory,
        verbose_name="Категория",
        on_delete=models.SET_DEFAULT,
        default=SupportMeasureCategory.get_default_category,
        blank=True,
    )
    description = models.TextField(
        verbose_name="Описание меры"
    )
    min_trust = models.DecimalField(
        verbose_name="Минимальный уровень надежности",
        max_digits=6,
        decimal_places=4,
        default=0,
    )
    price = models.DecimalField(
        verbose_name="Стоимость",
        max_digits=10,
        decimal_places=2,
        default=0.00,
        validators=[MinValueValidator(0.00)],
        help_text="Цена для платных мер поддержки"
    )

    def save(self, *args, **kwargs):
        if float(self.price) < 0:
            self.price = 0.00
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "support_measures"
        verbose_name = "Мера поддержки"
        verbose_name_plural = "Меры поддержки"