from asgiref.sync import sync_to_async

from django.shortcuts import render
from django.http import HttpRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt

from requests_.utils import validate_telegram_token

from options.models import Option


@csrf_exempt
@sync_to_async
@validate_telegram_token
def get_option_view(request: HttpRequest):
    """
    Представление для получения значения опции по её названию
    """
    category = request.GET.get("option", "Пусто")
    if not category:
        return JsonResponse({"error": True, "message": "Пусто"},status=403)
    try:
        option = Option.objects.get(category=category)
        return JsonResponse({"error": False, "message": option.value}, status=200)
    except Option.DoesNotExist:
        return JsonResponse({"error": True, "message": "Пусто"}, status=404)
    except Exception as e:
        return JsonResponse({"error": True, "message": str(e)}, status=500)



def custom404_view(request: HttpRequest, exception: Exception):
    return render(request, "404.html", status=404)