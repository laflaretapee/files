from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager


class CustomUserManager(UserManager):
    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(username, password=password, **extra_fields)

    def _create_user(self, username, password=None, **extra_fields):
        if not username:
            raise ValueError('The Username field must be set')
        user = self.model(username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user


class TelegramUser(AbstractUser):
    """
    Модель телеграм пользователя. При регистрации заполняются только full_name, phone и email.
    После подтверждения почты она становится активной и заполняются инн, категория вместе с надежностью.
    """

    first_name = None
    last_name = None
    
    objects = CustomUserManager()

    REQUIRED_FIELDS = ["full_name", "phone"]

    title = models.CharField(verbose_name="Название компании", max_length=256, blank=True, null=True)
    connection = models.CharField(verbose_name="Приоритетный способ связи", max_length=256, blank=True, null=True)
    role = models.CharField(verbose_name="Должность", max_length=128, blank=True, null=True)
    inn = models.CharField(verbose_name="ИНН", max_length=128, blank=True, null=True)
    full_name= models.CharField(verbose_name="ФИО", max_length=128, blank=True, null=True)
    phone = models.CharField(verbose_name="Телефон", max_length=128, blank=True, null=True)
    email = models.EmailField(verbose_name="Email", max_length=254, blank=True, null=True)
    category = models.CharField(verbose_name="Категория", max_length=128, blank=True, null=True)
    email_verified = models.BooleanField(default=False, verbose_name="Почта")

    def __str__(self):
        fio = self.full_name.split()
        if len(fio) >= 3:
            initials = f"{fio[0]} {fio[1][0]}. {fio[2][0]}."
        elif len(fio) == 2:
            initials = f"{fio[0]} {fio[1][0]}."
        elif len(fio) == 1:
            initials = f"{fio[0]}"
        else:
            initials = "Без имени"
        
        inn = self.inn if self.inn else "не указан"
        return f"{initials} [ИНН: {inn}]"
    
    def save(self, *args, **kwargs):
        if (self.is_staff or self.is_superuser) and not self.password:
            return
        super().save(*args, **kwargs)

    class Meta:
        db_table= "tg_users"
        verbose_name= "Пользователь"
        verbose_name_plural = "Пользователи"
