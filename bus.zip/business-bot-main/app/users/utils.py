import aiohttp


class AsyncHttpRequestor:
    """Класс для осуществления асинхронных HTTP-запросов"""

    def __init__(self, url):
        """
        При создании объекта нужно передать базовый URL домена
        """
        self.url = url
        self.method = None

    async def __resolve_method(self, method, session):
        """
        Проверка того, какой метод должен быть использован
        """
        if method not in ["get", "post"]:
            raise ValueError("Invalid method name")
        match method:
            case "post":
                self.method = session.post
            case "get":
                self.method = session.get

    async def make(self, method, action, *, body=None, headers=None, params=None):
        """
        Функция непосредственно осуществляющая запросы.

        method - метод запроса 'post' или 'get'
        action - непосредственно часть url от базового домена по которой осуществляется запрос
        body - тело запроса
        headers - заголовки
        params - query параметры
        """
        try:
            async with aiohttp.ClientSession() as session:
                await self.__resolve_method(method, session)
                async with self.method(url=(self.url+action), data=body, headers=headers, params=params) as response:
                    resp = await response.json()
                    if not resp.get("ok", True):
                        raise Exception("Ошибка отправки запроса")
                    return resp
        except Exception as e:
            return {"error": True, "message": str(e)}
