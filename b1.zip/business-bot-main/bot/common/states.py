from aiogram.fsm.state import State, StatesGroup

class Register(StatesGroup):
    menu = State()
    policy = State()
    full_name = State()
    phone = State()
    email = State()
    inn = State()
    role = State()
    connection = State()
    waiting_agreement = State()
    waiting_email = State()

class Help(StatesGroup):
    message = State()

class Questions(StatesGroup):
    question = State()

class Regulators(StatesGroup):
    price = State()
    types = State()