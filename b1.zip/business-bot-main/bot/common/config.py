from aiogram.types import BotCommand


# BTN_TXT_MENU    = "📱 Меню"
BTN_TXT_CATALOG = "📃 Каталог"
BTN_TXT_PROFILE = "🧑‍🦰 Профиль"
BTN_TXT_FINANCE = "💰 Финансирование бизнеса"
BTN_TXT_SUPPORT = "ℹ️ Поддержка"
BTN_TXT_CANCEL = "❌ Отменить"

CMD_START = "start"
# CMD_MENU = "menu"
CMD_CATALOG = "catalog"
CMD_PROFILE = "profile"
CMD_FINANCE = "finance"
CMD_SUPPORT = "support"
CMD_CANCEL = "cancel"

SLT_CONN = {
    "whatsapp": "WhatsApp",
    "telegram": "Telegram",
    "email": "Email",
    "all": "Все виды связи",
}


BOT_COMMANDS = [
    BotCommand(command=CMD_START, description="Запустить Бота"),
    # BotCommand(command=CMD_MENU, description="Открыть главное меню"),
    BotCommand(command=CMD_CATALOG, description="Открыть каталог предложений"),
    BotCommand(command=CMD_FINANCE, description="Подобрать меру поддержки по финансированию бизнеса"),
    BotCommand(command=CMD_PROFILE, description="Посмотреть профиль"),
    BotCommand(command=CMD_SUPPORT, description="Помощь и поддержка"),
    BotCommand(command=CMD_CANCEL, description="Отменить операцию"),
]