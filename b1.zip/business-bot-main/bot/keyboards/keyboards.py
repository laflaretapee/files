from aiogram import types
from aiogram.types import InlineKeyboardMarkup

from common.config import BTN_TXT_FINANCE, BTN_TXT_CATALOG, BTN_TXT_PROFILE, BTN_TXT_SUPPORT, BTN_TXT_CANCEL, SLT_CONN


def get_cancel_kbrd():
    return types.ReplyKeyboardMarkup(
        keyboard=[
            [
                types.KeyboardButton(text=BTN_TXT_CANCEL),
            ],
        ],
        resize_keyboard=True,
    )



def get_connections():
    return types.InlineKeyboardMarkup(
        inline_keyboard=[
        [
            types.InlineKeyboardButton(
                text="📲 " + SLT_CONN["telegram"],
                callback_data="connect:telegram"
            ),
        ],
        [
            types.InlineKeyboardButton(
                text="📲 " + SLT_CONN["whatsapp"],
                callback_data="connect:whatsapp"
            ),
        ],
        [
            types.InlineKeyboardButton(
                text="📲 " + SLT_CONN["email"],
                callback_data="connect:email"
            ),
        ],
        [
            types.InlineKeyboardButton(
                text="⏺ " + SLT_CONN["all"],
                callback_data="connect:all"
            ),
        ],
    ],
    resize_keyboard=True,
    one_time_keyboard=True,
    )


def get_phone_keyboard() -> types.ReplyKeyboardMarkup:
    """Клавиатура для отправки контакта"""
    return types.ReplyKeyboardMarkup(
        keyboard=[
            [types.KeyboardButton(text="☎️ Отправить", request_contact=True)]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def get_main_menu_keyboard() -> types.ReplyKeyboardMarkup:
    """Основное меню после регистрации"""
    return types.ReplyKeyboardMarkup(
        keyboard=[
            [
                types.KeyboardButton(text=BTN_TXT_CATALOG),
                types.KeyboardButton(text=BTN_TXT_FINANCE),
            ],
            [
                types.KeyboardButton(text=BTN_TXT_SUPPORT),
                types.KeyboardButton(text=BTN_TXT_PROFILE),
            ],
        ],
        resize_keyboard=True,
    )


def get_support_keyboard():
    """Поддержка"""
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="💬 Служба поддержки", callback_data="support:service")],
            [types.InlineKeyboardButton(text="🔎 Подобрать меры поддержки", callback_data="support:measures")]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
        )
    return keyboard

def get_policy_keyboard():
    """Подтверждение политики конфиденциальности"""
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="✅ Ознакомлен", callback_data="policy:")]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    return keyboard


def get_inn_agreement_keyboard() -> types.ReplyKeyboardMarkup:
    """Подтверждение ИНН"""
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [
                types.InlineKeyboardButton(
                    text="✅ Все верно", callback_data="inn_agreement:agree"
                ),
                types.InlineKeyboardButton(
                    text="✏️ Изменить", callback_data="inn_agreement:decline"
                ),
            ]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    return keyboard


def create_telegram_link(userid: int) -> InlineKeyboardMarkup:
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="💬 Перейти к чату", url=f"tg://openmessage?user_id={userid}")]
        ],
        resize_keyboard=True,
    )
    return keyboard


def get_prices():
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="💸 До 500 тыс. ₽", callback_data="price:500")],
            [types.InlineKeyboardButton(text="💸 До 1 млн. ₽", callback_data="price:1000")],
            [types.InlineKeyboardButton(text="💸 До 2.5 млн. ₽", callback_data="price:2500")],
            [types.InlineKeyboardButton(text="💸 До 5 млн. ₽", callback_data="price:5000")],
            [types.InlineKeyboardButton(text="💸 Больше 5 млн. ₽", callback_data="price:10000")],
        ],
        resize_keyboard=True,
    )
    return keyboard


def get_check_email_keyboard():
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="🚀 Проверить подтверждение", callback_data="email:")]
        ],
        resize_keyboard=True,
    )
    return keyboard