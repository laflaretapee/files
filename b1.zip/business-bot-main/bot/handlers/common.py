import os

from aiogram import Bot, types, Router, F
from aiogram.filters import Command, CommandObject, CommandStart, StateFilter, or_f
from aiogram.fsm.context import FSMContext
from aiogram.utils import keyboard

from handlers.register import policy_handler
from keyboards.keyboards import get_main_menu_keyboard, get_prices, get_support_keyboard

from common.states import Register, Regulators
from common.config import (
    BTN_TXT_FINANCE,
    BTN_TXT_SUPPORT,
    CMD_FINANCE,
    CMD_SUPPORT,
    CMD_PROFILE,
    BTN_TXT_PROFILE,
)

from users.utils import AsyncHttpRequestor  # type: ignore


common_router = Router()
common_router.message.filter(StateFilter(None))
common_router.callback_query.filter(StateFilter(None))

obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
headers = {"token": os.getenv("TELEGRAM_TOKEN")}


@common_router.message(CommandStart(), StateFilter(None))
async def handle_message_command(
    message: types.Message, command: CommandObject, state: FSMContext, bot: Bot
):

    username = str(message.from_user.id)
    await state.update_data(username=str(username))
    headers["username"] = username
    response_profile = await obj.make("get", "users/profile", headers=headers)

    if response_profile["error"]:
        args = command.args
        response_start = await obj.make(
            "get", "options/get", headers=headers, params={"option": "bot_url"}
        )
        if response_start["error"]:
            await message.answer(
                "⚠️ Произошла ошибка при проверке ссылки! Попробуйте позже!"
                + response_start["message"]
            )
            return
        if args != response_start["message"]:
            await message.answer(
                "⚠️ Для получения доступа к боту, Вам необходимо пройти по ссылке или QR-коду!"
            )
            return

    info = await bot.get_me()
    bot_name = info.first_name

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "start_text"}
    )
    option_value = response_option["message"]

    msg = option_value.replace("{{bot}}", bot_name)

    await message.answer(msg, reply_markup=types.ReplyKeyboardRemove())
    await command_start_handler(message, state, bot, response_profile)


async def command_start_handler(
    message: types.Message, state: FSMContext, bot: Bot, response=None
):
    if not response["error"]:
        await message.answer("✅ Вы уже зарегистрированы!")
        await show_main_menu(message, bot)
        await state.clear()
        return
    await state.set_state(Register.policy)
    await policy_handler(message)


async def show_main_menu(message: types.Message, bot: Bot):

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "menu_text"}
    )
    option_value = response_option["message"]

    keyboard = get_main_menu_keyboard()
    info = await bot.get_me()
    bot_name = info.first_name

    await message.answer(
        option_value.replace("{{bot}}", bot_name),
        reply_markup=keyboard,
        parse_mode="HTML",
    )


@common_router.message(StateFilter(None), or_f(F.text == BTN_TXT_SUPPORT, Command(CMD_SUPPORT)))
async def show_support_menu(message: types.Message, bot):

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "support_text"}
    )
    option_value = response_option["message"]
    info = await bot.get_me()
    bot_name = info.first_name
    keyboard = get_support_keyboard()

    await message.answer(
        text=option_value.replace("{{bot}}", bot_name),
        reply_markup=keyboard,
        parse_mode="HTML",
    )


@common_router.message(
    StateFilter(None), or_f(F.text == BTN_TXT_PROFILE, Command(CMD_PROFILE))
)
async def prof_hand(message: types.Message):

    username = str(message.from_user.id)
    headers["username"] = username
    response = await obj.make("get", "users/profile", headers=headers)

    if response["error"]:
        await message.answer("⚠️ " + response["message"])
        return

    user = response["data"]

    profile_text = (\
        f"👤 <u><b>Профиль пользователя:</b></u>\n\n"\
        
        "⚙️ <b>Основная информация:</b>\n\n"\
        
        f"🆔 ID: {user['username'] or '❌ Не указано'}\n"\
        f"📝 ФИО: {user['full_name'] or '❌ Не указано'}\n"\
        f"👔 Должность: {user['role'] or '❌ Не указано'}\n\n"\
        
        "☎️ <b>Связь:</b>\n\n"\
        
        f"🔗 Способ связи: {user['connection'] or '❌ Не указано'}\n"\
        f"📱 Телефон: +{user['phone'] or '❌ Не указано'}\n"\
        f"📧 Email: {user['email'] or '❌ Не указано'}\n"\
        f"✉️ Подтверждён: {'✅ Да' if user['email_verified'] else '❌ Нет'}\n\n"\
        
        "🏢 <b>Компания:</b>\n\n"\
        
        f"🏷 Название: {user['company']['title'] or '❌ Не указано'}\n"\
        f"▶️ ИНН: {user['company']['inn'] or '❌ Не указано'}\n"\
        f"🗺️ Адрес: {user['company']['address'] or '❌ Не указано'}\n"\
        f"📊 Категория: {user['company']['category'] or '❌ Не указано'}\n\n"\
        "⚠️ Не забывайте, что вы всегда можете обратиться в службу поддержки и изменить свои данные, если возникла ошибка!")

    await message.answer(text=profile_text, parse_mode="HTML")


@common_router.message(StateFilter(None), or_f(F.text == BTN_TXT_FINANCE, Command(CMD_FINANCE)))
async def choose_finances(message: types.Message, state: FSMContext):
    await message.answer("💰 Выберите сумму: ", reply_markup=get_prices())
    await state.set_state(Regulators.price)

@common_router.callback_query(StateFilter(None))
async def catch_update(callback: types.CallbackQuery, state: FSMContext, bot: Bot):
    await callback.message.delete()
    
@common_router.message(StateFilter(None))
async def echo(message: types.Message):
    await message.reply(
        text=f"🤔 Извините, но я не знаю такой команды :(\n💡 Если у Вас имеются вопросы, введите команду: /{CMD_SUPPORT}"
    )
