import os

from aiogram import Bot, Router, F, types
from aiogram.filters import StateFilter, or_f
from aiogram.fsm.context import FSMContext
from aiogram.utils.keyboard import InlineKeyboardBuilder

from users.utils import AsyncHttpRequestor # type: ignore

from common.states import Regulators


finances_router = Router()

obj = AsyncHttpRequestor(os.getenv("BASE_URL"))
headers = {"token": os.getenv("TELEGRAM_TOKEN")}


@finances_router.callback_query(StateFilter(Regulators.price), F.data.startswith("price:"))
async def choose_type(callback: types.CallbackQuery, state: FSMContext):
    
    price = callback.data.split(":")[1]
    await state.update_data(price=price)

    categories = await obj.make("get", "supports/categories", headers=headers)
    if categories["error"]:
        await callback.answer("⚠️ Не удалось получить список категорий! Пожалуйста, попробуйте позже!")
        await callback.message.delete()
        await state.clear()
        return

    def has_measures(category):
        if category.get('measures') and len(category['measures']) > 0:
            return True
        for child in category.get('children', []):
            if has_measures(child):
                return True
        return False

    def collect_categories_with_measures(categories_list):
        result = []
        for category in categories_list:
            if category.get('measures') and len(category['measures']) > 0:
                result.append(category)
            for child in category.get('children', []):
                if has_measures(child):
                    result.append(child)
        return result

    filtered_categories = collect_categories_with_measures(categories['data'])

    if not filtered_categories:
        await callback.message.answer("⚠️ На данный момент нет доступных категорий с мерами поддержки.")
        await callback.message.delete()
        await state.clear()
        return

    keyboard = types.InlineKeyboardMarkup(inline_keyboard=[
        [types.InlineKeyboardButton(text=cat['category_name'], callback_data=f"type:{cat['category_id']}")]
        for cat in filtered_categories
    ])

    await callback.message.edit_text("▶️ Выберите сферу:", reply_markup=keyboard)
    await state.set_state(Regulators.types)


@finances_router.callback_query(StateFilter(Regulators.types), F.data.startswith("type:"))
async def measures_view(callback: types.CallbackQuery, state: FSMContext):
    user_data = await state.get_data()
    price = user_data.get('price')

    category_id = callback.data.split(":")[1]
    measures = await obj.make(
        "get",
        "supports/get-supports-by-category/",
        headers=headers,
        params={"id": category_id},
    )

    builder = InlineKeyboardBuilder()

    if not measures["error"]:
        filtered_measures = measures["data"]
        if price:
            price_threshold = float(price) * 1000
            filtered_measures = [
                measure for measure in measures["data"] 
                if measure.get('price', None) and 
                   (float(measure["price"]) <= price_threshold or price_threshold == 10000 and float(measure["price"]) > 5000000)
            ]

        for measure in filtered_measures:
            measure_price = float(measure.get("price", 0.0)) * 1000
            builder.add(
                types.InlineKeyboardButton(
                    text=f"{measure['measure_name']} {f'(Бесплатно)' if measure_price == 0.0 else f'({measure_price} ₽)'}",
                    callback_data=f"measure_{measure['measure_id']}_fin",
                )
            )

        if not filtered_measures:
            await callback.answer(
                "⚠️ Нет мер поддержки, соответствующих выбранному фильтру.",
                show_alert=True
            )
            await state.clear()
            return

        await callback.message.edit_text(
            "▶️ Выберите меру поддержки:", 
            reply_markup=builder.adjust(1).as_markup()
        )
    else:
        await callback.answer("⚠️ Не удалось получить список мер поддержки!")
    await state.clear()