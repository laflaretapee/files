import asyncio
import os
import logging
from tabnanny import check

from aiogram import Bot, types, Router, F
from aiogram.types import Message, ReplyKeyboardRemove, Update
from aiogram.filters import StateFilter, or_f
from aiogram.fsm.context import FSMContext

from dadata import Dadata

from common.filters import ChatTypeFilter
from common.states import Register
from common.config import SLT_CONN

from users.utils import AsyncHttpRequestor  # type: ignore

from keyboards.keyboards import (
    get_check_email_keyboard,
    get_connections,
    get_inn_agreement_keyboard,
    get_main_menu_keyboard,
    get_phone_keyboard,
    get_policy_keyboard,
)

dadata = Dadata(os.getenv("DADATA_TOKEN"))

router_register = Router()
router_register.message.filter(ChatTypeFilter(['private']))
router_register.callback_query.filter(ChatTypeFilter(['private']))

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

obj = AsyncHttpRequestor(os.getenv("BASE_URL"))

headers = {
    "token": os.getenv("TELEGRAM_TOKEN"),
}


@router_register.callback_query(StateFilter(Register.policy), F.data == "policy:")
async def process_full_name(callback: types.CallbackQuery, state: FSMContext):

    await callback.message.edit_text(
        f"✅ Я ознакомлен с политикой конфиденциальности и даю согласие на обработку персональных данных!",
        reply_keyboard_markup=ReplyKeyboardRemove(),
    )
    logger.debug(f"[{callback.from_user.id}] Ознакомился с политикой...")
    await callback.message.answer(
        "👌 Хорошо, давайте познакомимся! Введите Ваше ФИО:",
        reply_markup=types.ReplyKeyboardRemove(),
    )
    await state.set_state(Register.full_name)


@router_register.message(StateFilter(Register.policy))
async def policy_handler(message: types.Message):

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "policy_url"}
    )
    option_value = response_option["message"]
    logger.debug(f"[{message.from_user.id}] Ссылка на политику: {option_value}")

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "personal_data_handling_url"}
    )
    personal_data_handling = response_option["message"]
    logger.debug(f"[{message.from_user.id}] Ссылка на политику: {personal_data_handling}")

    await message.reply(
        "👤 Регистрация пользователя...", reply_markup=ReplyKeyboardRemove()
    )
    await message.answer(
        f"⚠️ Перед началом регистрации, пожалуйста, ознакомьтесь с нашей <a href='{option_value}'>политикой конфиденциальности</a> и дайте согласие на <a href='{personal_data_handling}'>обработку персональных данных!</a>",
        reply_markup=get_policy_keyboard(),
        parse_mode="HTML",
    )


@router_register.message(StateFilter(Register.full_name), F.text)
async def process_full_name(message: types.Message, state: FSMContext):
    full_name: str | None = message.text
    logger.debug(f"[{message.from_user.id}] ФИО: {full_name}")
    if (full_name.split(" ")).__len__() != 3:
        logger.info(f"[{message.from_user.id}] Некорректное ФИО!")
        await message.answer("⚠️ Пожалуйста, введите корректное ФИО:")
        return
    await state.update_data(full_name=full_name)
    keyboard = get_phone_keyboard()
    await message.answer(
        "📱 Теперь поделитесь своим номером телефона:",
        reply_markup=keyboard,
    )
    await state.set_state(Register.phone)


async def format_phone_number(phone):
    if not phone:
        return None
    digits_only = "".join(char for char in phone if char.isdigit())
    if len(digits_only) < 10:
        return None
    if len(digits_only) == 10:
        return "7" + digits_only
    elif len(digits_only) == 11:
        if digits_only.startswith("8"):
            return "7" + digits_only[1:]
        elif digits_only.startswith("7"):
            return digits_only
        else:
            return digits_only
    else:
        return digits_only


@router_register.message(StateFilter(Register.phone), or_f(F.text, F.contact))
async def process_phone(message: types.Message, state: FSMContext):
    if message.contact is not None:
        phone = message.contact.phone_number
        phone = await format_phone_number(phone)
    else:
        phone = await format_phone_number(message.text.strip())

        if not phone or not (phone.startswith("7")):
            keyboard = get_phone_keyboard()
            logger.info(f"[{message.from_user.id}] Некорректный номер телефона!")
            await message.answer(
                "⚠️ Пожалуйста, введите корректный номер телефона:",
                reply_markup=keyboard,
            )
            return

    headers = {
        "token": os.getenv("TELEGRAM_TOKEN"),
    }
    logger.debug(f"[{message.from_user.id}] Номер телефона: {phone}")
    await state.update_data(phone=phone)
    body = await state.get_data()

    response = await obj.make("post", "users/create/", headers=headers, body=body)
    if response["error"]:
        logger.info(
            f"[{message.from_user.id}] Ошибка в регистрации! {response['message']}"
        )
        await message.answer("⚠️" + response["message"])
        return

    await message.answer(
        "🗒️ Отлично, теперь напишите ИНН компании:", reply_markup=ReplyKeyboardRemove()
    )
    await state.set_state(Register.inn)


@router_register.message(StateFilter(Register.inn), F.text)
async def process_inn(message: types.Message, state: FSMContext):
    inn = message.text.strip()
    logger.debug(f"[{message.from_user.id}] ИНН: {inn}!")
    if not inn.isdigit() or len(inn) not in [10, 12]:
        logger.info(f"[{message.from_user.id}] Некорректный ИНН!")
        await message.answer("⚠️ Пожалуйста, введите корректный ИНН (10/12 цифр)")
        return

    await state.update_data(inn=inn)
    suggestions = dadata.find_by_id(name="party", query=inn)
    cmp = None
    for sug in suggestions:
        if sug["data"]["state"]["status"] == "ACTIVE":
            cmp = sug
            break

    if cmp is None:
        logger.info(f"[{message.from_user.id}] Нет активных компаний по ИНН!")
        await message.answer(
            "⚠️ По указанному ИНН нет активных компаний, попробуйте ещё раз:"
        )
        return

    inn = cmp["data"]["inn"]
    title = cmp["value"]
    type_ = cmp["data"]["opf"]["full"]
    region = cmp["data"]["address"]["data"]["region_with_type"]
    address = cmp["data"]["address"]["unrestricted_value"]

    logger.debug(
        f"[{message.from_user.id}] Найдена компания: {title}; Регион: {region}; Тип: {type_}; ИНН: {inn}"
    )

    await message.answer(
        text=f"⚠️ Информация по данному ИНН:\n\n"
        + f"▶️ ИНН: {inn}\n"
        + f"▶️ Название: {title}\n"
        + f"▶️ Тип: {type_}\n"
        + f"▶️ Регион: {region}\n\n"
        + "❓ Приведённые данные верны?",
        reply_markup=get_inn_agreement_keyboard(),
    )

    await state.update_data(title=title)
    await state.update_data(type=type_)
    await state.update_data(region=region)
    await state.update_data(address=address)
    await state.set_state(Register.waiting_agreement)


@router_register.callback_query(
    StateFilter(Register.waiting_agreement), F.data.startswith("inn_agreement:")
)
async def process_agreement(callback: types.CallbackQuery, state: FSMContext):
    data = callback.data.split(":")
    if data[1] == "decline":
        logger.debug(f"[{callback.from_user.id}] Изменение ИНН...")
        await callback.message.edit_text(
            "🗒️ Хорошо, напишите ИНН компании ещё раз:",
            reply_keyboard_markup=ReplyKeyboardRemove(),
        )
        await state.set_state(Register.inn)
        return
    logger.debug(f"[{callback.from_user.id}] ИНН принят!")
    await callback.message.edit_text(
        "🗒️ ИНН подтверждён!", reply_keyboard_markup=ReplyKeyboardRemove()
    )

    await callback.message.answer("👔 Напишите должность, которую Вы занимаете:")
    await state.set_state(Register.role)


@router_register.message(StateFilter(Register.role), F.text)
async def process_role(message: types.Message, state: FSMContext):
    role = message.text
    logger.info(f"[{message.from_user.id}] Введена должность: {role}")
    if len(role) > 32:
        logger.info(f"[{message.from_user.id}] Слишком длинное наименование должности!")
        await message.answer(
            "⚠️ Слишком длинное наименование (>=32 симв.). Попробуйте ещё раз:"
        )
        return

    await state.update_data(role=role)
    await message.answer(
        "ℹ️ Как Вам будет удобно получать информацию?", reply_markup=get_connections()
    )
    await state.set_state(Register.connection)


@router_register.callback_query(
    StateFilter(Register.connection), F.data.startswith("connect:")
)
async def process_connection(callback: types.CallbackQuery, state: FSMContext):
    connect = callback.data.split(":")[1]
    logger.debug(
        f"[{callback.from_user.id}] Приоритетный способ связи: {SLT_CONN[connect]}"
    )
    await state.update_data(connection=SLT_CONN[connect])
    await callback.message.edit_text(
        f"📲 {SLT_CONN[connect]}", reply_keyboard_markup=ReplyKeyboardRemove()
    )

    await callback.message.answer("✉️ Последний шаг, поделитесь Вашим E-mail адресом:")
    await state.set_state(Register.email)


@router_register.message(StateFilter(Register.email), F.text)
async def process_email(message: types.Message, state: FSMContext, bot: Bot):
    email = message.text.strip().lower()
    logger.info(f"[{message.from_user.id}] Введен Email: {email}")
    if "@" not in email or "." not in email:
        logger.info(
            f"[{message.from_user.id}] Ошибка в Email, отсутствует символ '@' или '.'!"
        )
        await message.answer("⚠️ Пожалуйста, введите корректный Email адрес:")
        return
    await state.update_data(email=email)

    headers = {
        "token": os.getenv("TELEGRAM_TOKEN"),
    }
    body = await state.get_data()
    response = await obj.make("post", "users/create/", headers=headers, body=body)
    if response["error"]:
        logger.info(f"[{message.from_user.id}] Ошибка в Email! {response['message']}")
        await message.answer("⚠️ " + response["message"] + " Давайте попробуем ещё раз!")
        return

    user = response["data"]
    logger.debug(f"[{message.from_user.id}] Подтверждение почты...")
    await message.answer(
       "⚠️ Всё готово! Подтвердите свой аккаунт, перейдя по ссылке из письма!",
       reply_markup=get_check_email_keyboard(),
    )
    await state.set_state(Register.waiting_email)

@router_register.callback_query(StateFilter(Register.waiting_email), F.data.startswith("email:"))
async def process_agreement(callback: types.CallbackQuery, state: FSMContext, bot: Bot):

    await callback.message.edit_text("⏰ Секунду! Проверяем подтверждение...")
    await asyncio.sleep(1)

    username = str(callback.from_user.id)
    headers["username"] = username
    response_profile = await obj.make("get", "users/profile", headers=headers)

    if response_profile["error"]:
        await callback.answer(
            "⚠️ Произошла ошибка при проверке почты! Попробуйте позже!"
            + response_profile["message"],
            show_alert=True
        )
        return
    
    if response_profile.get("data",False):
        if not response_profile["data"].get("email_verified", False):
            data = await state.get_data()
            await callback.message.edit_text(f"⚠️ Почта не подтверждена! Необходимо перейти по ссылке из письма на почту: {data["email"]}")
            return
        
    await callback.message.edit_text(f"✅ Почта успешно подтверждена! Вы завершили регистрацию!")
    await state.clear()

    response_option = await obj.make(
        "get", "options/get", headers=headers, params={"option": "menu_text"}
    )
    option_value = response_option["message"]
    logger.debug(f"[{callback.from_user.id}] Получен текст меню: \n{option_value}")

    keyboard = get_main_menu_keyboard()
    info = await bot.get_me()
    bot_name = info.first_name

    await callback.message.answer(
        option_value.replace("{{bot}}", bot_name),
        reply_markup=keyboard,
        parse_mode="HTML",
    )
    

@router_register.message(StateFilter(None))
@router_register.callback_query(StateFilter(None))
async def catch_update(update: Update, state: FSMContext, bot: Bot):
    await state.set_state(Register.policy)
    username = str(update.from_user.id)
    await state.update_data(username=str(username))
    message = update if isinstance(update, Message) else update.message
    await policy_handler(message)
