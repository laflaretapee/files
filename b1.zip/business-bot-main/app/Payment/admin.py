from django.contrib import admin

from Payment.models import YookassaPayment

@admin.register(YookassaPayment)
class YookassaPaymentAdmin(admin.ModelAdmin):
    list_display = ('payment_id', 'user_id', 'amount', 'status', 'created_at')
    list_filter = ('status', 'currency')
    search_fields = ('payment_id', 'user_id', 'measure_id')
    readonly_fields = ('payment_id', 'created_at', 'updated_at')