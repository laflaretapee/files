import logging
from pyexpat import model

from asgiref.sync import async_to_sync

from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager

from users.bx24 import bx24_create_or_update_company, bx24_create_or_update_contact  # type: ignore


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class CustomUserManager(UserManager):
    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self._create_user(username, password=password, **extra_fields)

    def _create_user(self, username, password=None, **extra_fields):
        if not username:
            raise ValueError("The Username field must be set")
        user = self.model(username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user


class Company(models.Model):
    """
    Модель компании
    """

    inn = models.CharField(verbose_name="ИНН", max_length=128, unique=True)
    title = models.CharField(verbose_name="Название компании", max_length=256)
    category = models.CharField(verbose_name="Категория", max_length=128)
    created_at = models.DateTimeField(verbose_name="Дата добавления", auto_now_add=True)

    address = models.CharField(
        verbose_name="Адрес", max_length=256, blank=True, null=True
    )

    trust = models.DecimalField(
        verbose_name="Уровень надежности",
        max_digits=5,
        decimal_places=2,
        default=100.00,
        validators=[
            MaxValueValidator(100.00),
            MinValueValidator(0.00)
        ]
    )

    bx24_company_id = models.CharField(
        verbose_name="ID компании [BX24]",
        max_length=128,
        blank=True,
        null=True,
        help_text="ID компании, к которой привязан клиент в Bitrix 24",
    )

    def get_full_information(self):
        data = {
            "inn": self.inn,
            "title": self.title,
            "category": self.category,
            "address": self.address,
            "bx24_company_id": self.bx24_company_id,
        }
        return data

    def bx24_save(self):
        company_id = -1
        if not all((self.inn, self.title, self.category)):
            return company_id
        try:
            logger.debug(f"\n[ИНН: {self.inn}] Отправка данных в Битрикс24...")
            company_id = async_to_sync(bx24_create_or_update_company)(
                self.get_full_information()
            )
            self.bx24_company_id = company_id
            if company_id is None or company_id == -1:
                logger.warning(f"[ИНН: {self.inn}] Непредвиденный идентификатор!")
        except Exception as e:
            logger.error(
                f"[ИНН: {self.inn}] Ошибка при создании компании в Битрикс24! {e}"
            )
        super().save()
        return company_id

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        company_id = self.bx24_save()
        logger.debug(f"[ИНН: {self.inn}] Полученный ID компании: {company_id}")
        

    def __str__(self):
        return f"[ИНН: {self.inn}] {self.title}"

    class Meta:
        db_table = "companies"
        verbose_name = "Компания"
        verbose_name_plural = "Компании"


class TelegramUser(AbstractUser):
    """
    Модель телеграм пользователя. При регистрации заполняются только full_name, phone и email.
    После подтверждения почты она становится активной и заполняются инн, категория вместе с надежностью.
    """

    first_name = None
    last_name = None

    objects = CustomUserManager()

    REQUIRED_FIELDS = ["full_name", "phone"]

    connection = models.CharField(
        verbose_name="Приоритетный способ связи", max_length=256, blank=True, null=True
    )
    role = models.CharField(
        verbose_name="Должность", max_length=128, blank=True, null=True
    )
    full_name = models.CharField(
        verbose_name="ФИО", max_length=128, blank=True, null=True, 
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Zа-яА-ЯёЁ\s\-]+$',
                message="ФИО может содержать только буквы, пробелы и дефисы."
            )
        ]
    )
    company = models.ForeignKey(
        Company,
        verbose_name="Компания",
        blank=True,
        null=True,
        on_delete=models.PROTECT,
    )
    phone = models.CharField(
        verbose_name="Телефон", max_length=128, blank=True, null=True
    )
    email = models.EmailField(
        verbose_name="Email", max_length=254, blank=True, null=True
    )
    email_verified = models.BooleanField(default=False, verbose_name="Почта")

    bx24_contact_id = models.CharField(
        verbose_name="ID контакта [BX24]",
        max_length=128,
        blank=True,
        null=True,
        help_text="ID контакта клиента в Bitrix 24",
    )

    def get_full_information(self):
        data = {
            "username": self.username,
            "full_name": self.full_name,
            "phone": self.phone,
            "company": self.company.get_full_information() if self.company else None,
            "role": self.role,
            "connection": self.connection,
            "email": self.email,
            "bx24_contact_id": self.bx24_contact_id,
            "email_verified": self.email_verified,
            "staff": self.is_staff,
        }
        return data

    def __str__(self):
        if not self.full_name or not len(self.full_name):
            return "Без имени"
        return f"{self.full_name}"

    def bx24_save(self):
        contact_id = -1
        if not all(
            (
                self.company,
                self.role,
                self.connection,
                self.email,
                self.username,
                self.full_name,
                self.phone,
            )
        ):
            return contact_id

        company_id = self.company.bx24_company_id
        if company_id is None or company_id == -1:
            return contact_id
        
        user_data = self.get_full_information()
        last_name, name, second_name = user_data["full_name"].split(" ")
        user_data.update(
            {
                "second_name": second_name,
                "name": name,
                "last_name": last_name,
                "bx24_company_id": company_id,
            }
        )

        try:
            logger.debug(
                f"\n[Телеграм ID: {self.username}] Отправка данных в Битрикс24..."
            )
            contact_id = async_to_sync(bx24_create_or_update_contact)(user_data)
            self.bx24_contact_id = contact_id
            if contact_id is None or contact_id == -1:
                logger.warning(
                    f"[Телеграм ID: {self.username}] Непредвиденный идентификатор!"
                )
        except Exception as e:
            logger.error(
                f"[Телеграм ID: {self.username}] Ошибка при создании компании в Битрикс24! {e}"
            )
        super().save()
        return contact_id

    def save(self, *args, **kwargs):
        if (self.is_staff or self.is_superuser) and not self.password:
            return
        super().save(*args, **kwargs)
        contact_id = self.bx24_save()
        logger.debug(
            f"[Телеграм ID: {self.username}] Полученный ID контакта: {contact_id}"
        )

    class Meta:
        db_table = "tg_users"
        verbose_name = "Контакт"
        verbose_name_plural = "Контакты"
