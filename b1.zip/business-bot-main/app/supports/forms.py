from django import forms
from django.core.exceptions import ValidationError
from supports.models import SupportMeasure

class SupportMeasureAdminForm(forms.ModelForm):
    """
    Модель формы для создания меры поддержки из админки.
    Добавлена обработка платных мер и цены.
    """

    # percent = forms.DecimalField(
    #     max_value=100,
    #     min_value=0,
    #     label="Минимальный уровень надежности",
    #     help_text="Введите минимальный уровень надежности в процентах (от 0 до 100).",
    #     decimal_places=2,
    # )
    
    price = forms.DecimalField(
        required=False,
        label="Стоимость",
        min_value=0.00,
        max_digits=10,
        decimal_places=2,
        help_text="Обязательно для платных мер. Введите сумму в рублях.",
        widget=forms.NumberInput(attrs={'step': '0.01'})
    )

    class Meta:
        model = SupportMeasure
        fields = "__all__"
        exclude = ['min_trust']

    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instance')
        if instance:
            initial = kwargs.get('initial', {})
            # initial['percent'] = float(instance.min_trust) * 100
            initial['price'] = instance.price
            kwargs['initial'] = initial
        super().__init__(*args, **kwargs)


    def save(self, commit=True):
        instance = super().save(commit=False)
        # instance.min_trust = self.cleaned_data['percent'] / 100
        if instance.price == 0.00 and instance.item:
            instance.item = ""
        if commit:
            instance.save()
        return instance
    